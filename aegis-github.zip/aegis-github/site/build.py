import json, re, base64
s = open("/tmp/claude-0/sp/site/template.html").read()
d = json.load(open('/tmp/claude-0/sp/scan.json')); F = d['findings']
demo = json.load(open('/tmp/claude-0/sp/demo.json'))
want = [('aadhaar_vault.py','encrypt','encrypt','Aadhaar number'),('infra/haproxy.cfg','tls','protocol',''),('legacy/reports.py','encrypt','encrypt',''),('esign/signer.py','sign','sign','Signed legal document'),('payments/upi.py','sign','sign','Financial data')]
fixes = {'infra/haproxy.cfg': 'TLS 1.3 with hybrid X25519MLKEM768 key exchange'}
top = []
for loc, op, opname, data in want:
    f = [x for x in F if loc in x['location'] and x['operation'] == op][0]; r = f['risk']
    hops = [{'text': h['text'], 'line': h['line']} for l in f['data_links'] for h in (l.get('path') or [])]
    top.append({'name': f['name'], 'op': opname, 'where': f"{f['location']}:{f['line']}", 'prio': r['priority'], 'cls': r['class'], 'data': data, 'p': round(r.get('p_exposure') or 0, 3),
                'fix': fixes.get(f['location'], f['recommendation']['summary']), 'story': r['story'].replace('; the chance', ', and the chance'), 'X': r['X'], 'Y': round(r['Y'], 1), 'hops': hops, 'evidence': f['evidence'], 'evidence_type': f['evidence_type']})
DEMO = {"files": demo["files"], "total": demo["total"], "classes": demo["classes"], "linked": demo["data_linked"], "list": demo["file_list"], "top": top}
imgs = json.load(open('/tmp/claude-0/sp/site/imgs.json'))
logo = {k: "data:image/png;base64," + base64.b64encode(open(f"/tmp/claude-0/sp/site/logo/{k}.png", "rb").read()).decode() for k in ["mark", "lockup"]}
out = s.replace("{{DEMO}}", json.dumps(DEMO))
for k, v in logo.items(): out = out.replace("{{LOGO_%s}}" % k, v)
# images once, assigned by script
for k in imgs: out = out.replace('src="{{IMG_%s}}"' % k, 'data-img="%s"' % k)
out = out.replace("  /* ================= router ================= */", "  const IMGS = " + json.dumps(imgs) + ";\n  document.querySelectorAll(\"img[data-img]\").forEach((im) => (im.src = IMGS[im.dataset.img]));\n\n  /* ================= router ================= */", 1)
left = re.findall(r"\{\{\w+\}\}", out); assert not left, left
open("/tmp/claude-0/sp/site/aegis-site.html", "w").write(out)
print(len(out) // 1024, "KB")
