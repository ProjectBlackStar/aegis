import re
REPO = "ProjectBlackStar/aegis"          # change if the repository lives elsewhere
PAGES = "https://projectblackstar.github.io/aegis/"
ZIP = f"https://github.com/{REPO}/archive/refs/heads/main.zip"
s = open("/tmp/claude-0/sp/site/aegis-site.html").read()
a = '''  document.querySelectorAll("[data-dl]").forEach((b) => b.addEventListener("click", () => say(`The ${b.dataset.dl} download goes live when the site is published.`)));'''
assert a in s
s = s.replace(a, f'''  const ZIP = "{ZIP}";
  document.querySelectorAll("[data-dl]").forEach((b) => b.addEventListener("click", () => {{ say(`Downloading Aegis for ${{b.dataset.dl}}. Unzip it, then open the Start Aegis file.`); location.href = ZIP; }}));''')
a = '<button type="button" data-go="get" data-faq="1">Questions</button></div>'
assert a in s
s = s.replace(a, f'<button type="button" data-go="get" data-faq="1">Questions</button><a class="gh" href="https://github.com/{REPO}" target="_blank" rel="noopener">Source on GitHub</a></div>')
s = s.replace(".foot .cols button:hover { color: var(--ink); }", ".foot .cols button:hover, .foot .gh:hover { color: var(--ink); }\n.foot .gh { display: block; padding: 6px 0; color: var(--ink-2); font: 400 15px/1.4 var(--body); text-decoration: none; }")
m = re.match(r"<title>Aegis</title>\n(<link rel=\"icon\"[^>]+>)", s); assert m
desc = "Aegis finds every encryption key in your systems, traces the data it protects, and gives the chance a quantum computer reads it while it still matters. Runs fully offline."
head = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Aegis · Quantum-risk discovery</title>
<meta name="description" content="{desc}">
<meta name="theme-color" content="#0A0A0B">
{m.group(1)}
<link rel="apple-touch-icon" href="icon/aegis-icon-192.png">
<meta property="og:type" content="website">
<meta property="og:title" content="Aegis · Quantum-risk discovery">
<meta property="og:description" content="{desc}">
<meta property="og:url" content="{PAGES}">
<meta property="og:image" content="{PAGES}og.png">
<meta name="twitter:card" content="summary_large_image">
<style>[hidden]{{display:none!important}} img{{max-width:100%}}</style>
'''
out = head + s[m.end():]
i = out.index('<div class="sky')
out = out[:i] + "</head>\n<body>\n" + out[i:] + "\n</body>\n</html>\n"
open("/home/claude/kaalq/site/dist/index.html", "w").write(out)
open("/home/claude/kaalq/site/dist/.nojekyll", "w").write("")
print("dist", len(out) // 1024, "KB")
