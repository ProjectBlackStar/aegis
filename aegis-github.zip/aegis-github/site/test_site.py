"""Clicks every control on every page of the Aegis site, at desktop and phone width, and reports anything that does nothing."""
import re, sys
from playwright.sync_api import sync_playwright

SRC = "/tmp/claude-0/sp/site/aegis-site.html"
LOCAL = open("/tmp/claude-0/sp/site/localfonts.css").read()
body = re.sub(r'<link rel="stylesheet" href="https://fonts.googleapis.com[^>]*>', "<style>" + LOCAL + "</style>", open(SRC).read())
body = re.sub(r'<link rel="preconnect"[^>]*>', "", body)
import os
FULL = os.environ.get("FULL")
if FULL:
    SRC = FULL
    body = re.sub(r'<link rel="stylesheet" href="https://fonts.googleapis.com[^>]*>', "<style>" + LOCAL + "</style>", open(SRC).read())
    body = re.sub(r'<link rel="preconnect"[^>]*>', "", body)
    open("/tmp/claude-0/sp/site/_test.html", "w").write(body)
else:
    open("/tmp/claude-0/sp/site/_test.html", "w").write('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"></head><body>' + body + "</body></html>")
URL = "file:///tmp/claude-0/sp/site/_test.html"
SHOTS = len(sys.argv) > 1
errs, bad, clicks = [], [], 0

def page_on(pg):
    return pg.evaluate("document.querySelector('.page.on')?.dataset.page")

with sync_playwright() as p:
    b = p.chromium.launch()
    for vw, vh, tag in [(1440, 900, "desk"), (390, 844, "phone")]:
        pg = b.new_page(viewport={"width": vw, "height": vh}, accept_downloads=True)
        zips = []
        pg.route("https://github.com/**", lambda r: (zips.append(r.request.url), r.fulfill(status=200, headers={"Content-Type": "application/zip", "Content-Disposition": "attachment; filename=aegis-main.zip"}, body=b"PK\x05\x06" + b"\x00" * 18)))
        pg.on("pageerror", lambda e: errs.append(f"{tag}: {e}"))
        pg.on("console", lambda m: errs.append(f"{tag}: {m.text}") if m.type == "error" else None)
        pg.goto(URL); pg.wait_for_timeout(1200)
        dup = pg.evaluate("(() => { const c = {}; document.querySelectorAll('[id]').forEach(e => c[e.id] = (c[e.id] || 0) + 1); return Object.keys(c).filter(k => c[k] > 1); })()")
        if dup: bad.append(f"{tag}: duplicate ids {dup}")
        if page_on(pg) != "home": bad.append(f"{tag}: did not start on home")
        # every page reachable from the menu, nav marks it, no sideways scroll, title set
        for name in ["product", "risk", "stats", "demo", "technology", "get", "home"]:
            if tag == "phone" and name != "get":
                pg.click("#menuBtn"); clicks += 1; pg.wait_for_timeout(200)
                if not pg.locator(".nav").is_visible(): bad.append("phone: menu did not open")
            sel = f'.nav [data-go="{name}"]' if name not in ("get", "home") else ('.get-btn' if name == "get" else '.top .mark')
            if tag == "phone" and name == "get": sel = '.top .mark'; pg.click(sel); pg.wait_for_timeout(300); sel = '.hero [data-go="demo"]'; name = "demo"
            pg.click(sel); clicks += 1; pg.wait_for_timeout(500)
            if page_on(pg) != name: bad.append(f"{tag}: nav to {name} shows {page_on(pg)}")
            if pg.evaluate("document.documentElement.scrollWidth > innerWidth + 1"): bad.append(f"{tag}: sideways scroll on {name}")
            if SHOTS:
                pg.screenshot(path=f"/tmp/claude-0/sp/site/s-{tag}-{name}.png", full_page=True)
        # every [data-go] button anywhere goes where it says
        for i in range(pg.locator("[data-go]").count()):
            pg.goto(URL + "#home"); pg.wait_for_timeout(150)
            el = pg.locator("[data-go]").nth(i)
            target = el.get_attribute("data-go")
            host = el.evaluate("e => e.closest('.page')?.dataset.page || ''")
            if host: pg.evaluate(f"location.hash = '#{host}'"); pg.wait_for_timeout(250)
            if not el.is_visible():
                continue
            el.scroll_into_view_if_needed(); el.click(); clicks += 1; pg.wait_for_timeout(250)
            if page_on(pg) != target: bad.append(f"{tag}: [{el.inner_text()[:30]!r}] on {host or 'chrome'} → {page_on(pg)} not {target}")
        if tag == "desk":
            # home: pointer moves the light
            pg.goto(URL + "#home"); pg.wait_for_timeout(500)
            pg.mouse.move(1300, 700); pg.wait_for_timeout(1500)
            a = pg.screenshot(clip={"x": 420, "y": 60, "width": 600, "height": 520})
            pg.mouse.move(150, 150); pg.wait_for_timeout(1500)
            b2 = pg.screenshot(clip={"x": 420, "y": 60, "width": 600, "height": 520})
            if a == b2: bad.append("eclipse: no change on pointer")
            print("webgl:", pg.evaluate("!!document.getElementById('eclipse').getContext('webgl')"))
            # product: scrolling swaps the screenshot
            pg.evaluate("location.hash='#product'"); pg.wait_for_timeout(500)
            seen = set()
            for y in range(0, 5200, 300):
                pg.evaluate(f"scrollTo(0,{y})"); pg.wait_for_timeout(120)
                seen.add(pg.evaluate("document.querySelector('#story .shot img.on')?.dataset.k"))
            if len(seen - {None}) < 5: bad.append(f"product: screenshots seen {seen}")
            # risk: bands, chart drag + keys, calculator
            pg.evaluate("location.hash='#risk'"); pg.wait_for_timeout(500)
            p0 = pg.inner_text("#cP")
            for bnd in ["optimistic", "pessimistic", "mid"]:
                pg.click(f'[data-band="{bnd}"]'); clicks += 1; pg.wait_for_timeout(150)
                if pg.get_attribute(f'[data-band="{bnd}"]', "aria-pressed") != "true": bad.append(f"band {bnd} not pressed")
            pg.click('[data-band="optimistic"]'); pg.wait_for_timeout(100)
            if pg.inner_text("#cP") == p0: bad.append("band change did not change %")
            pg.click('[data-band="mid"]')
            pg.locator("#curve").scroll_into_view_if_needed(); pg.wait_for_timeout(200); box = pg.locator("#curve").bounding_box()
            pg.mouse.click(box["x"] + box["width"] * 0.7, box["y"] + box["height"] * 0.5); clicks += 1; pg.wait_for_timeout(150)
            y1 = pg.inner_text("#cYear")
            pg.locator("#curve").focus(); pg.keyboard.press("ArrowRight"); pg.wait_for_timeout(100)
            if y1 == "2033" or pg.inner_text("#cYear") == y1: bad.append(f"curve: drag/key did nothing ({y1})")
            c0 = pg.inner_text("#calcP")
            if c0 not in ("99%", ">99%"): bad.append(f"calc default should be 99% for Aadhaar, got {c0}")
            pg.select_option("#dataType", index=6); clicks += 1; pg.wait_for_timeout(100)
            c1 = pg.inner_text("#calcP")
            pg.select_option("#algo", index=3); clicks += 1; pg.wait_for_timeout(100)
            c2 = pg.inner_text("#calcP")
            pg.evaluate("const r=document.getElementById('mig'); r.value=8; r.dispatchEvent(new Event('input'))"); clicks += 1; pg.wait_for_timeout(100)
            c3 = pg.inner_text("#calcP")
            print("calc:", c0, c1, c2, c3, "| curve", y1, "->", pg.inner_text("#cYear"), pg.inner_text("#cP"))
            if len({c0, c1, c2, c3}) < 3: bad.append(f"calculator barely changes: {c0} {c1} {c2} {c3}")
            # statistics deck
            pg.evaluate("location.hash='#stats'"); pg.wait_for_timeout(700)
            c0 = pg.inner_text("#deckCount")
            pg.click("#deckNext"); clicks += 1; pg.wait_for_timeout(300)
            if pg.inner_text("#deckCount") == c0: bad.append("deck next did nothing")
            pg.click("#deckPrev"); clicks += 1; pg.wait_for_timeout(300)
            if pg.inner_text("#deckCount") != c0: bad.append("deck prev did not return")
            pg.click("#deckFlip"); clicks += 1; pg.wait_for_timeout(300)
            if not pg.locator(".card.front-most.flipped").count(): bad.append("deck flip did not flip")
            if SHOTS: pg.screenshot(path="/tmp/claude-0/sp/site/s-desk-stats-flipped.png")
            pg.click("#deckFlip"); clicks += 1; pg.wait_for_timeout(300)
            if pg.locator(".card.front-most.flipped").count(): bad.append("deck flip did not flip back")
            pg.locator(".card.front-most").click(position={"x": 60, "y": 120}); clicks += 1; pg.wait_for_timeout(300)
            if not pg.locator(".card.front-most.flipped").count(): bad.append("clicking the front card did not flip it")
            pg.locator(".card.front-most").click(position={"x": 60, "y": 120}); pg.wait_for_timeout(200)
            for cat, n in [("threat", 4), ("deadline", 3), ("stake", 2), ("response", 3), ("all", 12)]:
                pg.click(f'[data-cat="{cat}"]'); clicks += 1; pg.wait_for_timeout(400)
                if pg.inner_text("#deckCount") != f"1 of {n}": bad.append(f"filter {cat}: {pg.inner_text('#deckCount')}")
                if pg.locator("#deckDots button").count() != n: bad.append(f"filter {cat}: dots")
            pg.locator("#deckDots button").nth(5).click(); clicks += 1; pg.wait_for_timeout(300)
            if pg.inner_text("#deckCount") != "6 of 12": bad.append("dot click did not jump")
            pg.locator("#deck").focus(); pg.keyboard.press("ArrowRight"); pg.wait_for_timeout(200)
            if pg.inner_text("#deckCount") != "7 of 12": bad.append("arrow key did not turn")
            pg.keyboard.press("Enter"); pg.wait_for_timeout(200)
            if not pg.locator(".card.front-most.flipped").count(): bad.append("Enter did not flip")
            pg.click("#deckPlay"); clicks += 1; pg.wait_for_timeout(4000)
            if pg.get_attribute("#deckPlay", "aria-pressed") != "true" or pg.inner_text("#deckCount") == "7 of 12": bad.append("autoplay did not advance")
            pg.click("#deckPlay"); clicks += 1; pg.wait_for_timeout(200)
            if pg.get_attribute("#deckPlay", "aria-pressed") != "false": bad.append("autoplay did not stop")
            if SHOTS: pg.evaluate("document.getElementById('deck').scrollIntoView({block:'center'})"); pg.wait_for_timeout(900); pg.screenshot(path="/tmp/claude-0/sp/site/s-desk-stats.png")
            for i in range(pg.locator(".card .back a").count()):
                if pg.locator(".card .back a").nth(i).get_attribute("target") != "_blank": bad.append("card source link not new tab")
            print("eclipse mode:", pg.evaluate("document.getElementById('eclipse').getContext ? 'ok' : ''"))
            # demo: scan, then open every finding
            pg.evaluate("location.hash='#demo'"); pg.wait_for_timeout(400)
            pg.click("#scanBtn"); clicks += 1; pg.wait_for_selector(".findings li", timeout=8000); pg.wait_for_timeout(600)
            if pg.inner_text("#nTotal") != "76": bad.append("demo: total not 76")
            n = pg.locator(".findings li > button").count()
            for i in range(n):
                btn = pg.locator(".findings li > button").nth(i); btn.click(); clicks += 1; pg.wait_for_timeout(120)
                if btn.get_attribute("aria-expanded") != "true" or pg.locator(".findings li .detail").nth(i).is_hidden(): bad.append(f"demo finding {i} did not open")
            if SHOTS: pg.screenshot(path="/tmp/claude-0/sp/site/s-desk-demo-open.png", full_page=True)
            btn.click(); clicks += 1
            if pg.locator(".findings li .detail").nth(n - 1).is_visible(): bad.append("demo finding did not close")
            pg.click("#scanBtn"); clicks += 1; pg.wait_for_timeout(3000)
            if pg.text_content("#scanBtn") != "Scan again": bad.append("demo: rescan did not finish")
            # technology: every node
            pg.evaluate("location.hash='#technology'"); pg.wait_for_timeout(500)
            for i in range(pg.locator("[data-node]").count()):
                nd = pg.locator("[data-node]").nth(i); nd.click(); clicks += 1; pg.wait_for_timeout(100)
                if nd.get_attribute("aria-pressed") != "true" or nd.inner_text().split("\n")[0] not in pg.inner_text("#nodeDetail"): bad.append(f"node {i} did not show its detail")
            if pg.locator("#mapLinks path").count() != 8: bad.append("map links not drawn")
            # get: downloads, terminal, copy, faq
            pg.evaluate("location.hash='#get'"); pg.wait_for_timeout(400)
            for i in range(pg.locator("[data-dl]").count()):
                pg.locator("[data-dl]").nth(i).click(); clicks += 1; pg.wait_for_timeout(150)
                if pg.locator("#toast").is_hidden(): bad.append(f"download {i}: no feedback")
            if FULL and not any(z.endswith("main.zip") for z in zips): bad.append(f"downloads did not request the zip: {zips}")
            if FULL: print("download requests:", sorted(set(zips)))
            pg.click("details.term summary"); clicks += 1; pg.wait_for_timeout(150)
            for c in ["c1", "c2", "c3"]:
                pg.evaluate("document.getElementById('toast').hidden = true")
                pg.click(f'[data-copy="{c}"]'); clicks += 1; pg.wait_for_timeout(200)
                if pg.locator("#toast").is_hidden(): bad.append(f"copy {c}: no feedback")
            for i in range(pg.locator(".faq summary").count()):
                pg.locator(".faq summary").nth(i).click(); clicks += 1; pg.wait_for_timeout(80)
                if not pg.locator(".faq details").nth(i).evaluate("e => e.open"): bad.append(f"faq {i} did not open")
            # footer "Questions" jumps to the FAQ
            pg.evaluate("location.hash='#home'"); pg.wait_for_timeout(300)
            pg.click('footer [data-faq]'); clicks += 1; pg.wait_for_timeout(900)
            if page_on(pg) != "get" or abs(pg.evaluate("document.querySelector('.faq').getBoundingClientRect().top")) > 400: bad.append("footer Questions did not land on the FAQ")
            # direct link and back
            pg.goto(URL + "#technology"); pg.wait_for_timeout(500)
            if page_on(pg) != "technology": bad.append("direct link #technology failed")
            # external reference links open in a new tab
            for i in range(pg.locator(".refs a").count()):
                if pg.locator(".refs a").nth(i).get_attribute("target") != "_blank": bad.append("ref link not new tab")
        pg.close()
    b.close()
print(f"{clicks} controls exercised")
print("errors:", errs or "none")
print("problems:", bad or "none")
