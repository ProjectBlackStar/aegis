import sys, time, json, resource, os
sys.path.insert(0, "/home/claude/kaalq")
from core.engine import Scan
name = sys.argv[1]; path = f"/tmp/claude-0/sp/scale/{name}"
t = time.time(); s = Scan(path); s.use_cache = False; s.run(); cold = time.time() - t
sm = s.summary()
t = time.time(); s2 = Scan(path); s2.run(); s2b = Scan(path); s2b.run(); warm = time.time() - t
rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
out = {"repo": name, "files": sm["files"], "assets": sm["total"], "classes": sm["classes"], "cold_s": round(cold, 1), "rescan_s": round(time.time()-t - 0, 1), "warm_pair_s": round(warm, 1), "cache_hits": s2b.cache_hits, "peak_mb": round(rss), "status": s.status, "error": s.error, "warnings": len(s.warnings), "top_algos": sm.get("top_algorithms", [])[:5]}
print(json.dumps(out)); open(f"/tmp/claude-0/sp/scale/{name}.json", "w").write(json.dumps(out))
