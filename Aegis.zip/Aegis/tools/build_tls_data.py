"""Builds data/tls.json from public sources (local clones):
 - testssl.sh etc/cipher-mapping.txt, etc/curves-mapping.txt, etc/client-simulation.txt (GPLv2 data, SSL Labs client list)
 - mozilla/ssl-config-generator docs/guidelines/latest.json (Mozilla Server Side TLS)
Usage: python tools/build_tls_data.py <testssl.sh dir> <ssl-config-generator dir>"""
import json, os, re, sys, subprocess, datetime

def rev(d):
    return subprocess.run(["git", "-C", d, "log", "-1", "--format=%H %cd", "--date=short"], capture_output=True, text=True).stdout.strip()

def main(tssl, moz):
    ciphers = []
    for line in open(os.path.join(tssl, "etc", "cipher-mapping.txt")):
        m = re.match(r"\s*(0x[0-9A-Fa-f]{2},0x[0-9A-Fa-f]{2}(?:,0x[0-9A-Fa-f]{2})?)\s+-\s+(\S+)\s+(\S+)\s+(\S+)\s+Kx=(\S+)\s+Au=(\S+)\s+Enc=(\S+)\s+Mac=(\S+)", line)
        if m:
            hx, ossl, iana, ver, kx, au, enc, mac = m.groups()
            ciphers.append({"hex": hx.lower(), "openssl": ossl, "iana": iana, "version": ver, "kx": kx, "au": au, "enc": enc, "mac": mac})
    groups = []
    for line in open(os.path.join(tssl, "etc", "curves-mapping.txt")):
        m = re.match(r"\s*(0x[0-9a-fA-F]{2},0x[0-9a-fA-F]{2})\s+-\s+(\S+)\s+(\S+)", line)
        if m:
            name = m.group(3)
            groups.append({"hex": m.group(1).lower(), "openssl": m.group(2), "name": name,
                           "pq": bool(re.search(r"MLKEM|Kyber", name, re.I))})
    clients, cur = [], {}
    for line in open(os.path.join(tssl, "etc", "client-simulation.txt")):
        m = re.match(r"\s*(names|curves|current|highest_protocol|ciphersuites|handshakebytes)\+=\((.*)\)\s*$", line)
        if not m:
            continue
        k, v = m.group(1), m.group(2).strip('"')
        if k == "names":
            if cur: clients.append(cur)
            cur = {"name": v}
        else:
            cur[k] = v
    if cur: clients.append(cur)
    for c in clients:
        cs = [x for x in c.get("curves", "").split(":") if x]
        c["groups"] = cs
        c["pq_hybrid"] = any(re.search(r"MLKEM|Kyber", x, re.I) for x in cs)
        c["current"] = c.get("current") == "true"
        hb = c.pop("handshakebytes", "")
        c["client_hello_bytes"] = len(hb) // 2 if hb else None
        c.pop("curves", None)
    moz_d = json.load(open(os.path.join(moz, "docs", "guidelines", "latest.json")))
    out = {"meta": {"sources": {"testssl.sh": "github.com/testssl/testssl.sh " + rev(tssl),
                                "mozilla": "github.com/mozilla/ssl-config-generator " + rev(moz) + " (guidelines " + str(moz_d.get("version")) + ")",
                                "client_list": "Qualys SSL Labs client list as curated in testssl.sh"},
                    "built": datetime.date.today().isoformat()},
           "ciphers": ciphers, "groups": groups, "clients": clients, "mozilla": moz_d}
    json.dump(out, open(os.path.join(os.path.dirname(__file__), "..", "data", "tls.json"), "w"))
    print(len(ciphers), "ciphers,", len(groups), "groups (", sum(g["pq"] for g in groups), "PQ),", len(clients), "clients (",
          sum(c["pq_hybrid"] for c in clients), "send a PQ hybrid group;", sum(c["current"] for c in clients), "current)")

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
