"""Builds data/advisories.json from a local clone of github/advisory-database.
Usage: python tools/build_advisories.py <path-to-advisory-database>
Keeps only reviewed advisories that affect cryptography libraries."""
import json, os, sys, subprocess, datetime

CRYPTO_PKGS = {
    "PyPI": ["cryptography", "pycryptodome", "pycryptodomex", "pycrypto", "pyopenssl", "paramiko", "pyjwt", "python-jose",
             "rsa", "ecdsa", "m2crypto", "pynacl", "authlib", "jwcrypto", "oscrypto", "asyncssh", "twisted", "certifi"],
    "npm": ["node-forge", "jsonwebtoken", "elliptic", "crypto-js", "jose", "node-rsa", "sshpk", "tweetnacl", "jsrsasign",
            "browserify-sign", "secp256k1", "openpgp", "ssh2", "jws", "jwa", "node-jose", "bn.js", "public-encrypt"],
    "Maven": ["org.bouncycastle:bcprov-jdk15on", "org.bouncycastle:bcprov-jdk18on", "org.bouncycastle:bcprov-jdk14",
              "org.bouncycastle:bcpkix-jdk15on", "org.bouncycastle:bcpkix-jdk18on", "org.bouncycastle:bc-fips",
              "com.nimbusds:nimbus-jose-jwt", "io.jsonwebtoken:jjwt", "io.jsonwebtoken:jjwt-impl", "com.auth0:java-jwt",
              "org.bitbucket.b_c:jose4j", "com.jcraft:jsch", "org.apache.sshd:sshd-core", "org.apache.santuario:xmlsec"],
    "Go": ["golang.org/x/crypto", "github.com/golang-jwt/jwt", "github.com/golang-jwt/jwt/v4", "github.com/golang-jwt/jwt/v5",
           "github.com/dgrijalva/jwt-go", "github.com/square/go-jose", "gopkg.in/square/go-jose.v2", "github.com/go-jose/go-jose/v3",
           "github.com/go-jose/go-jose/v4", "github.com/cloudflare/circl"],
    "crates.io": ["openssl", "openssl-src", "rustls", "ring", "rsa", "ed25519-dalek", "curve25519-dalek", "libsecp256k1", "sodiumoxide"],
    "RubyGems": ["openssl", "jwt", "net-ssh", "rbnacl"],
    "NuGet": ["BouncyCastle", "Portable.BouncyCastle", "BouncyCastle.Cryptography", "System.IdentityModel.Tokens.Jwt"],
}

def main(root):
    want = {(eco, p.lower()) for eco, ps in CRYPTO_PKGS.items() for p in ps}
    out = []
    base = os.path.join(root, "advisories", "github-reviewed")
    for dp, _, fs in os.walk(base):
        for fn in fs:
            if not fn.endswith(".json"):
                continue
            d = json.load(open(os.path.join(dp, fn)))
            if d.get("withdrawn"):
                continue
            for aff in d.get("affected", []):
                pkg = aff.get("package", {})
                key = (pkg.get("ecosystem"), (pkg.get("name") or "").lower())
                if key not in want:
                    continue
                ranges = []
                for r in aff.get("ranges", []):
                    intro = fixed = last = None
                    for ev in r.get("events", []):
                        intro = ev.get("introduced", intro)
                        fixed = ev.get("fixed", fixed)
                        last = ev.get("last_affected", last)
                    ranges.append({"introduced": intro, "fixed": fixed, "last_affected": last})
                out.append({
                    "id": d["id"], "cve": [a for a in d.get("aliases", []) if a.startswith("CVE-")],
                    "ecosystem": key[0], "package": key[1], "summary": d.get("summary", "")[:200],
                    "severity": (d.get("database_specific") or {}).get("severity", ""),
                    "cwe": (d.get("database_specific") or {}).get("cwe_ids", []),
                    "published": (d.get("published") or "")[:10], "ranges": ranges,
                    "versions": aff.get("versions", [])[:50],
                })
    out.sort(key=lambda a: (a["ecosystem"], a["package"], a["published"]))
    commit = subprocess.run(["git", "-C", root, "log", "-1", "--format=%H %cd", "--date=short"], capture_output=True, text=True).stdout.strip()
    meta = {"source": "GitHub Advisory Database (github.com/github/advisory-database), reviewed advisories",
            "license": "CC-BY-4.0", "snapshot": commit, "built": datetime.date.today().isoformat(),
            "packages": {e: ps for e, ps in CRYPTO_PKGS.items()}, "count": len(out)}
    json.dump({"meta": meta, "advisories": out}, open(os.path.join(os.path.dirname(__file__), "..", "data", "advisories.json"), "w"), indent=0)
    print(meta["count"], "advisories;", commit)

if __name__ == "__main__":
    main(sys.argv[1])
