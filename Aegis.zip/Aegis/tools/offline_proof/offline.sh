# Air-gapped proof. Run as an unprivileged user namespace with no network:
#   unshare -rn bash tools/offline_proof/offline.sh; unshare -rn bash tools/offline_proof/offline_browser.sh
set -e
python3 "$(dirname "$0")/lo_up.py"
echo "--- network interfaces inside the sandbox:"; cat /proc/net/dev | tail -n +3 | awk '{print $1}'
echo "--- outbound check:"; (curl -sS -m 5 https://pypi.org -o /dev/null && echo "INTERNET REACHABLE") || echo "no internet (expected)"
cd "$(dirname "$0")/../.."
echo "--- self-tests:"; python3 -m unittest discover -s tests 2>&1 | tail -3
echo "--- benchmark:"; python3 bench/score.py | grep -E '"corpus"|"precision"|"recall"' | paste - - -
echo "--- CLI scan + CBOM:"; python3 run.py scan samples/digibank-kyc --cbom /tmp/aegis-offline-cbom.json | grep -E "Aegis|CBOM written"
echo "--- web server + API inside the isolated network:"
NO_BROWSER=1 APP_PORT=8799 python3 run.py > /tmp/aegis-offline-server.log 2>&1 &
sleep 2
id=$(curl -s --noproxy "*" -X POST 127.0.0.1:8799/api/scan -H 'Content-Type: application/json' -d '{"target":"sample:digibank-kyc"}' | python3 -c "import sys,json;print(json.load(sys.stdin)['id'])")
sleep 1
curl -s --noproxy "*" 127.0.0.1:8799/api/scan/$id/status | python3 -c "import sys,json;d=json.load(sys.stdin);print('scan status:',d['status'],d['progress']['files'],'files',d['progress']['findings'],'assets')"
curl -s --noproxy "*" "127.0.0.1:8799/api/scan/$id/cbom?check=1"; echo
curl -s --noproxy "*" -o /dev/null -w "UI page served: HTTP %{http_code}\n" 127.0.0.1:8799/
curl -s --noproxy "*" -o /dev/null -w "bundled font served: HTTP %{http_code}\n" 127.0.0.1:8799/web/fonts/IBMPlexSans-Regular.woff2
kill %1
