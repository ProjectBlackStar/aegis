python3 "$(dirname "$0")/lo_up.py"
cd "$(dirname "$0")/../.."
NO_BROWSER=1 APP_PORT=8799 python3 run.py > /dev/null 2>&1 &
sleep 2
python3 - <<'PY'
from playwright.sync_api import sync_playwright
ext, errs = [], []
B = 'http://127.0.0.1:8799'
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1440, 'height': 900})
    pg.on('request', lambda r: ext.append(r.url) if not r.url.startswith(('http://127.0.0.1', 'data:', 'blob:')) else None)
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(B + '/#/start'); pg.wait_for_timeout(800)
    pg.click('.target[data-id="sample:digibank-kyc"]'); pg.wait_for_url('**/#/overview', timeout=30000); pg.wait_for_timeout(1200)
    pg.screenshot(path='/tmp/aegis-offline-overview.png')
    screens = ['overview', 'inventory', 'data', 'quantum', 'systems', 'recommend', 'fix', 'plan', 'exports', 'compare', 'sources', 'policy', 'start']
    for r in screens:
        pg.goto(f'{B}/#/{r}'); pg.wait_for_timeout(700)
    fonts = pg.evaluate("document.fonts.check('16px \"IBM Plex Sans\"') && document.fonts.check('16px \"IBM Plex Mono\"')")
    print(f'--- browser inside the isolated network: {len(screens)} screens opened; bundled fonts loaded: {fonts}; script errors: {len(errs)}; requests to anything other than 127.0.0.1: {ext or "none"}')
    b.close()
PY
kill %1
