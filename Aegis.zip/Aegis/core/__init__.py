"""Aegis engine. Bundled third-party packages (pyelftools, kyber-py, dilithium-py) live in ../vendor."""
import os as _os
import sys as _sys

_VENDOR = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "vendor")
if _VENDOR not in _sys.path:
    _sys.path.insert(0, _VENDOR)
