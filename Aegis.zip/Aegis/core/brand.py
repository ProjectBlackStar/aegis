"""Product name and labels live in ../brand.json - change them there only."""
import json


def _read_json(path, **kw):
    with open(path, **kw) as fh:
        return json.load(fh)
import os

_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "brand.json")
try:
    BRAND = _read_json(_PATH, encoding="utf-8")
except Exception:
    BRAND = {"name": "ECDAT", "tagline": "", "slug": "ecdat", "version": "0.0"}
NAME = BRAND["name"]
SLUG = BRAND.get("slug", "ecdat")
