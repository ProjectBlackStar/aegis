"""Flask API + static UI."""
from __future__ import annotations

import json
import os
import sqlite3
import tempfile
import threading
import time

from flask import Flask, jsonify, request, send_from_directory, abort, Response

from .engine import Scan
from .export.cbom import build_cbom, validate
from .export.sarif import build_sarif
from .patch.patcher import apply_to_copy
from .brand import BRAND, SLUG
from .plan import build_plan, plan_markdown
from .risk import DEFAULT_POLICY
from .knowledge import DATA_CLASSES

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
WEB = os.path.join(ROOT, "web")
SAMPLES = os.path.join(ROOT, "samples")
WORK = os.path.join(tempfile.gettempdir(), f"{SLUG}-work")
os.makedirs(WORK, exist_ok=True)
DB = os.path.join(WORK, f"{SLUG}.sqlite")

app = Flask(__name__, static_folder=None)
SCANS: dict[str, Scan] = {}
PATCHES: dict[str, dict] = {}
_lock = threading.Lock()


def _db():
    c = sqlite3.connect(DB)
    c.execute("create table if not exists scans (id text primary key, label text, target text, started real, summary text)")
    cols = [r[1] for r in c.execute("pragma table_info(scans)")]
    if "findings" not in cols:
        c.execute("alter table scans add column findings text")
    return c


def _persist(scan):
    try:
        with _db() as c:
            c.execute("insert or replace into scans (id,label,target,started,summary,findings) values (?,?,?,?,?,?)",
                      (scan.id, scan.label, scan.target, scan.started or time.time(), json.dumps(scan.summary(), default=str),
                       json.dumps([f.to_dict() for f in scan.findings], default=str)))
    except Exception:
        pass


def _start(target, label=None, parent=None):
    s = Scan(target, label=label)
    s.parent = parent
    with _lock:
        SCANS[s.id] = s

    def work():
        s.run()
        _persist(s)
    threading.Thread(target=work, daemon=True).start()
    return s


def _resolve_target(t):
    t = (t or "").strip()
    if not t:
        abort(400, "target required")
    if t.startswith("sample:"):
        p = os.path.join(SAMPLES, t.split(":", 1)[1])
        if not os.path.exists(p):
            abort(404, "unknown sample")
        return p
    if t.startswith(("http://", "https://", "git@")):
        return t
    p = os.path.abspath(os.path.expanduser(t))
    if not os.path.exists(p):
        abort(404, f"path not found: {t}")
    return p


@app.get("/")
def index():
    return send_from_directory(WEB, "index.html")


@app.get("/web/<path:p>")
def web(p):
    return send_from_directory(WEB, p)


@app.get("/api/brand")
def brand():
    return jsonify(BRAND)


@app.get("/api/policy/defaults")
def policy_defaults():
    return jsonify({"policy": DEFAULT_POLICY,
                    "data_classes": [{"id": d["id"], "label": d["label"], "lifetime": d["lifetime"], "category": d["category"]}
                                     for d in DATA_CLASSES]})


@app.post("/api/scan/<sid>/policy")
def set_policy(sid):
    s = SCANS.get(sid) or abort(404)
    body = request.get_json(force=True, silent=True) or {}
    import copy
    pol = copy.deepcopy(s.policy)
    q = body.get("quantum") or {}
    if q:
        pol.setdefault("quantum", {})
        if q.get("source") in ("survey", "custom"):
            pol["quantum"]["source"] = q["source"]
        if q.get("band") in ("optimistic", "mid", "pessimistic"):
            pol["quantum"]["band"] = q["band"]
        for k in ("p10", "p50"):
            if q.get(k):
                pol["quantum"][k] = max(2026, min(2100, int(q[k])))
        if q.get("doubling_years") is not None:
            pol["quantum"]["doubling_years"] = max(0.0, min(10.0, float(q["doubling_years"])))
    if "lifetimes" in body:
        pol["lifetimes"] = {k: max(0.0, min(150.0, float(v))) for k, v in body["lifetimes"].items()}
    if "migration_factor" in body:
        pol["migration_factor"] = max(0.25, min(4.0, float(body["migration_factor"])))
    if "criticality" in body:
        rules = []
        for r in body["criticality"][:200]:
            if r.get("pattern") and r.get("tier") in ("critical", "high", "normal", "low"):
                rules.append({"pattern": str(r["pattern"])[:200], "tier": r["tier"],
                              "exposure": r.get("exposure") if r.get("exposure") in ("external", "internal") else None})
        pol["criticality"] = rules
    before = s.summary()
    s.reassess(pol)
    _persist(s)
    return jsonify({"summary": s.summary(), "findings": [f.to_dict() for f in s.findings],
                    "before": {"exposed": before["exposed"], "classes": before["classes"]}})


@app.get("/api/quantum")
def quantum_model():
    sid = request.args.get("scan")
    pol = SCANS[sid].policy if sid in SCANS else DEFAULT_POLICY
    from . import quantum as Q
    return jsonify(Q.describe(pol))


@app.get("/api/data/sources")
def data_sources():
    from . import quantum as Q
    from .tlscost import tls_data, client_hellos
    from .detectors.deps import advisories
    meta, idx = advisories()
    t = tls_data()
    defs_path = os.path.join(ROOT, "data", "cyclonedx-cryptography-defs.json")
    with open(defs_path) as fh:
        defs = json.load(fh)
    ch = client_hellos()
    return jsonify([
        {"id": "advisories", "name": "GitHub Advisory Database", "what": f"{meta.get('count', 0)} reviewed advisories for "
         f"{len(idx)} crypto libraries in {len(meta.get('packages', {}))} ecosystems", "snapshot": meta.get("snapshot", ""),
         "license": meta.get("license", ""), "used_for": "Library versions with known weaknesses; upgrade targets"},
        {"id": "quantum", "name": Q.SURVEY["title"], "what": f"{Q.SURVEY['experts']} experts, published {Q.SURVEY['published']}",
         "snapshot": Q.SURVEY["published"], "license": "", "url": Q.SURVEY["url"], "used_for": "Quantum-computer arrival curve (2030 / 2033 / 2037)"},
        {"id": "qubits", "name": "Quantum resource estimates", "what": "Logical-qubit formulas for RSA (2n+2) and elliptic curves (9n+2log2n+10)",
         "snapshot": "2017 papers", "license": "", "used_for": "Which algorithms fall first (qubit ladder)",
         "refs": [Q.DATA["logical_qubits"]["rsa"]["source"], Q.DATA["logical_qubits"]["ecc"]["source"]]},
        {"id": "ciphers", "name": "TLS cipher suite and group registry", "what": f"{len(t['ciphers'])} cipher suites, {len(t['groups'])} groups "
         f"({sum(g['pq'] for g in t['groups'])} post-quantum)", "snapshot": t["meta"]["sources"]["testssl.sh"], "license": "GPLv2 (testssl.sh data)",
         "used_for": "Naming suites in configs; spotting static-RSA key exchange"},
        {"id": "mozilla", "name": "Mozilla Server Side TLS guidelines", "what": f"version {t['mozilla'].get('version')}: modern / intermediate / old profiles",
         "snapshot": t["meta"]["sources"]["mozilla"], "license": "MPL-2.0", "used_for": "Profile check of every TLS configuration"},
        {"id": "clients", "name": "SSL Labs client handshakes", "what": f"{len(t['clients'])} clients; {len(ch['pq_clients'])} of "
         f"{ch['current_clients']} current clients send X25519MLKEM768", "snapshot": t["meta"]["sources"]["testssl.sh"], "license": "GPLv2 (testssl.sh data)",
         "used_for": "Real ClientHello sizes; who benefits from hybrid TLS today"},
        {"id": "cdx", "name": "CycloneDX cryptography registry", "what": f"{len(defs.get('algorithms', []))} algorithm families, "
         f"{sum(len(c.get('curves', [])) for c in defs.get('ellipticCurves', []))} curves", "snapshot": defs.get("lastUpdated", ""),
         "license": "Apache-2.0", "used_for": "Standard names in the CBOM"},
    ])


@app.get("/api/scan/<a>/diff/<b>")
def diff(a, b):
    def load(sid):
        if sid in SCANS and SCANS[sid].status == "done":
            return [f.to_dict() for f in SCANS[sid].findings], SCANS[sid].label
        with _db() as c:
            r = c.execute("select findings,label from scans where id=?", (sid,)).fetchone()
        if not r or not r[0]:
            abort(404, "scan not found")
        return json.loads(r[0]), r[1]
    fa, la = load(a)
    fb, lb = load(b)
    key = lambda f: (f["location"], f["algorithm"], f["params"], f["operation"], f["asset_type"])
    ka, kb = {key(f): f for f in fa}, {key(f): f for f in fb}
    new = [kb[k] for k in kb if k not in ka]
    fixed = [ka[k] for k in ka if k not in kb]
    changed = [{"before": ka[k], "after": kb[k]} for k in kb if k in ka and ka[k]["risk"].get("priority") != kb[k]["risk"].get("priority")]
    return jsonify({"a": {"id": a, "label": la, "total": len(fa)}, "b": {"id": b, "label": lb, "total": len(fb)},
                    "new": new, "fixed": fixed, "changed": changed, "unchanged": len(kb) - len(new) - len(changed)})


@app.post("/api/probe")
def start_probe():
    body = request.get_json(force=True, silent=True) or {}
    import re as _re
    targets = [t.strip() for t in (body.get("targets") or []) if t and _re.match(r"^[A-Za-z0-9.\-:\[\]]{1,260}$", t.strip())][:20]
    if not targets:
        abort(400, "enter host or host:port")
    s = Scan("probe:" + ",".join(targets), label="Live check: " + ", ".join(targets[:3]) + ("…" if len(targets) > 3 else ""))
    s.probe_reports = []
    with _lock:
        SCANS[s.id] = s

    def work():
        from .probe import probe
        s.started = time.time()
        s.status = "scanning"
        s.log("start", target=s.label)
        try:
            for t in targets:
                s.progress["current"] = t
                fs, rep = probe(t)
                s.probe_reports.append(rep)
                s.findings.extend(fs)
                s.progress["files"] += 1
                s.progress["findings"] = len(s.findings)
                s.log("found", file=t, n=len(fs))
            s.file_stats["Endpoint"] = len(targets)
            s.status = "analysing"
            s._assess()
            s.status = "done"
        except Exception as e:
            s.status, s.error = "error", f"{type(e).__name__}: {e}"
        s.finished = time.time()
        _persist(s)
    threading.Thread(target=work, daemon=True).start()
    return jsonify({"id": s.id})


@app.get("/api/scan/<sid>/probe")
def probe_report(sid):
    s = SCANS.get(sid) or abort(404)
    return jsonify(getattr(s, "probe_reports", []))


@app.delete("/api/cache")
def clear_cache():
    from . import cache
    cache.clear()
    return jsonify({"ok": True})


@app.get("/api/scan/<sid>/plan")
def plan(sid):
    s = SCANS.get(sid) or abort(404)
    p = build_plan(s)
    if request.args.get("format") == "md":
        return Response(plan_markdown(s, p), mimetype="text/markdown",
                        headers={"Content-Disposition": f"attachment; filename=migration-plan-{s.label}.md"})
    if request.args.get("format") == "csv":
        import csv, io
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["phase", "due", "priority", "asset", "operation", "location", "line", "action", "owner", "data"])
        for ph in p["phases"]:
            for i in ph["items"]:
                w.writerow([ph["id"] + " " + ph["name"], ph["due"], i["priority"], i["name"], i["operation"], i["location"],
                            i["line"], i["action"], i["owner"], "; ".join(i["data"])])
        return Response(buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": f"attachment; filename=migration-plan-{s.label}.csv"})
    return jsonify(p)


@app.get("/report/<sid>")
def report_page(sid):
    return send_from_directory(WEB, "report.html")


@app.get("/api/samples")
def samples():
    out = []
    for name in sorted(os.listdir(SAMPLES)):
        p = os.path.join(SAMPLES, name)
        desc = ""
        rd = os.path.join(p, "SAMPLE.txt") if os.path.isdir(p) else None
        if rd and os.path.exists(rd):
            desc = open(rd).read().strip()
        out.append({"id": "sample:" + name, "name": name, "kind": "folder" if os.path.isdir(p) else "file", "desc": desc})
    return jsonify(out)


@app.post("/api/scan")
def start_scan():
    body = request.get_json(force=True, silent=True) or {}
    target = _resolve_target(body.get("target"))
    s = _start(target, label=body.get("label") or os.path.basename(target.rstrip("/")))
    return jsonify({"id": s.id})


@app.post("/api/upload")
def upload():
    f = request.files.get("file")
    if not f:
        abort(400, "file required")
    d = tempfile.mkdtemp(prefix="upload-", dir=WORK)
    name = os.path.basename(f.filename or "upload.bin")
    path = os.path.join(d, name)
    f.save(path)
    s = _start(path, label=name)
    return jsonify({"id": s.id})


@app.get("/api/scan/<sid>/status")
def status(sid):
    s = SCANS.get(sid) or abort(404)
    return jsonify({"id": sid, "status": s.status, "progress": s.progress, "events": s.events[-12:], "error": s.error,
                    "elapsed": round(time.time() - (s.started or time.time()), 2)})


@app.get("/api/scan/<sid>")
def result(sid):
    s = SCANS.get(sid)
    if not s:
        with _db() as c:
            r = c.execute("select summary,findings from scans where id=?", (sid,)).fetchone()
        if not r or not r[1]:
            abort(404)
        summ = json.loads(r[0])
        summ["archived"] = True
        return jsonify({"summary": summ, "findings": json.loads(r[1])})
    if s.status not in ("done", "error"):
        return jsonify({"status": s.status}), 202
    return jsonify({"summary": s.summary(), "findings": [f.to_dict() for f in s.findings]})


@app.get("/api/history")
def history():
    try:
        with _db() as c:
            rows = c.execute("select id,label,target,started,summary from scans order by started desc limit 50").fetchall()
        return jsonify([{"id": r[0], "label": r[1], "target": r[2], "started": r[3], "summary": json.loads(r[4]),
                         "live": r[0] in SCANS} for r in rows])
    except Exception:
        return jsonify([])


@app.get("/api/scan/<sid>/source")
def source(sid):
    s = SCANS.get(sid) or abort(404)
    rel = request.args.get("path", "")
    line = int(request.args.get("line", "1") or 1)
    base = s.target
    if not os.path.isdir(base):
        return jsonify({"lines": [], "start": 0})
    full = os.path.abspath(os.path.join(base, rel))
    if not full.startswith(os.path.abspath(base)) or not os.path.isfile(full):
        return jsonify({"lines": [], "start": 0})
    try:
        lines = open(full, encoding="utf-8", errors="replace").read().splitlines()
    except Exception:
        return jsonify({"lines": [], "start": 0})
    a = max(0, line - 7)
    return jsonify({"lines": lines[a:a + 14], "start": a + 1, "line": line})


@app.get("/api/scan/<sid>/cbom")
def cbom(sid):
    s = SCANS.get(sid) or abort(404)
    bom = build_cbom(s)
    ok, errs = validate(bom)
    if request.args.get("check"):
        return jsonify({"valid": ok, "errors": errs, "components": len(bom["components"]), "spec": "CycloneDX 1.6"})
    return Response(json.dumps(bom, indent=2), mimetype="application/json",
                    headers={"Content-Disposition": f"attachment; filename=cbom-{s.label}.cdx.json",
                             "X-Schema-Valid": str(ok)})


@app.get("/api/scan/<sid>/sarif")
def sarif(sid):
    s = SCANS.get(sid) or abort(404)
    return Response(json.dumps(build_sarif(s), indent=2), mimetype="application/json",
                    headers={"Content-Disposition": f"attachment; filename={SLUG}-{s.label}.sarif"})


@app.post("/api/scan/<sid>/finding/<fid>/patch")
def patch(sid, fid):
    s = SCANS.get(sid) or abort(404)
    f = next((x for x in s.findings if x.fid == fid), None) or abort(404)
    if not os.path.isdir(s.target):
        abort(400, "patching needs a folder or repository target")
    fd = f.to_dict()
    try:
        res = apply_to_copy(s.target, fd, WORK)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    rescan = Scan(res["patched_root"], label=s.label + " (patched)").run()
    SCANS[rescan.id] = rescan
    # what now protects the same data?
    classes = {d["data_class"] for d in fd["data_links"]}
    after = [x.to_dict() for x in rescan.findings if classes & {d["data_class"] for d in x.data_links}]
    same_spot = [x.to_dict() for x in rescan.findings if x.location == fd["location"] and x.algorithm == fd["algorithm"]
                 and x.operation == fd["operation"]]
    delta = {
        "before": {"classes": s.summary()["classes"], "exposed": s.summary()["exposed"]},
        "after": {"classes": rescan.summary()["classes"], "exposed": rescan.summary()["exposed"]},
    }
    out = {k: v for k, v in res.items() if k != "patched_root"}
    out.update({"rescan_id": rescan.id, "finding": fd, "now_protecting": after, "remaining_same": same_spot, "delta": delta})
    PATCHES[fid] = out
    return jsonify(out)


def serve(host="127.0.0.1", port=8765):
    app.run(host=host, port=port, debug=False, threaded=True)
