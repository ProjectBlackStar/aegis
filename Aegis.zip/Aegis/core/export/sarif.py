from ..brand import BRAND
"""SARIF 2.1.0 export so findings show up in GitHub code scanning / IDEs."""


def build_sarif(scan):
    rules, results = {}, []
    for f in scan.findings:
        r = f.risk
        if r.get("class") in ("safe", "inventory"):
            continue
        rid = f"PQC-{r['class'].upper()}-{f.algorithm.upper().replace(' ', '_')}"
        rules.setdefault(rid, {"id": rid, "name": f"{r['class']} {f.algorithm}",
                               "shortDescription": {"text": r.get("reason", "")[:200]},
                               "help": {"text": f.recommendation.get("summary", "")}})
        level = "error" if r["severity"] in ("critical", "high") else "warning" if r["severity"] == "medium" else "note"
        loc = {"physicalLocation": {"artifactLocation": {"uri": f.location}}}
        if f.line:
            loc["physicalLocation"]["region"] = {"startLine": f.line}
        results.append({"ruleId": rid, "level": level, "message": {"text": r.get("story", r.get("reason", ""))[:500]},
                        "locations": [loc], "properties": {"priority": r["priority"], "dataClasses": [d["data_class"] for d in f.data_links]}})
    return {"$schema": "https://json.schemastore.org/sarif-2.1.0.json", "version": "2.1.0",
            "runs": [{"tool": {"driver": {"name": BRAND["name"], "version": BRAND.get("version", "0"), "rules": list(rules.values())}},
                      "results": results}]}
