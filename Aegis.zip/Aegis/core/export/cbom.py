"""CycloneDX 1.6 CBOM export, validated against the bundled official schema."""
from __future__ import annotations

import datetime
import json
import os
import uuid

from ..knowledge import OIDS
from ..brand import BRAND, SLUG

SCHEMA_DIR = os.path.join(os.path.dirname(__file__), "schema")

PRIMITIVE_MAP = {"pke": "pke", "signature": "signature", "kem": "kem", "key-agree": "key-agree", "block-cipher": "block-cipher",
                 "stream-cipher": "stream-cipher", "hash": "hash", "mac": "mac", "kdf": "kdf", "protocol": "other", "other": "other"}
FUNC_MAP = {"keygen": ["keygen"], "encrypt": ["encrypt"], "decrypt": ["decrypt"], "sign": ["sign"], "verify": ["verify"],
            "kex": ["keyderive"], "hash": ["digest"], "mac": ["tag"], "kdf": ["keyderive"], "tls": ["encapsulate", "decapsulate"],
            "link": ["other"], "store": ["other"]}
def _registry():
    path = os.path.join(os.path.dirname(__file__), "..", "..", "data", "cyclonedx-cryptography-defs.json")
    with open(path) as fh:
        d = json.load(fh)
    return {a["family"].upper(): a for a in d["algorithms"]}


REGISTRY = _registry()
ALIASES = {"ED25519": "EdDSA", "ED448": "EdDSA", "X25519": "ECDH", "X448": "ECDH", "DH": "FFDH", "SHA-256": "SHA-2", "SHA-384": "SHA-2",
           "SHA-512": "SHA-2", "SHA-224": "SHA-2", "SHA3-256": "SHA-3", "SHA3-512": "SHA-3", "TDEA": "3DES", "CHACHA20-POLY1305": "ChaCha20",
           "X25519MLKEM768": "ML-KEM", "KYBER": "ML-KEM", "DILITHIUM": "ML-DSA", "SPHINCS+": "SLH-DSA"}


def registry_family(algorithm, operation=""):
    """Maps an Aegis finding to the CycloneDX cryptography registry family (data/cyclonedx-cryptography-defs.json)."""
    a = (algorithm or "").upper()
    if a == "RSA":
        fam = {"sign": "RSASSA-PKCS1", "verify": "RSASSA-PKCS1", "encrypt": "RSAES-OAEP", "decrypt": "RSAES-OAEP"}.get(operation)
        if not fam:
            return None
        a = fam.upper()
    a = ALIASES.get(a, a).upper()
    hit = REGISTRY.get(a)
    if not hit:
        return None
    return {"family": hit["family"], "pattern": (hit.get("variant") or [{}])[0].get("pattern", ""),
            "standard": ", ".join(x["name"] for x in hit.get("standard", [])[:2])}


QLEVEL = {"safe": 1, "weakened": 0, "vulnerable": 0, "broken": 0, "inventory": 0}


def _component(f):
    fd = f.to_dict() if hasattr(f, "to_dict") else f
    r = fd["risk"]
    bref = f"crypto-{fd['id']}"
    props = [
        {"name": f"{SLUG}:class", "value": r.get("class", "")},
        {"name": f"{SLUG}:priority", "value": str(r.get("priority", 0))},
        {"name": f"{SLUG}:usage", "value": r.get("usage", "")},
        {"name": f"{SLUG}:mosca:X_years", "value": str(r.get("X"))},
        {"name": f"{SLUG}:mosca:Y_years", "value": str(r.get("Y"))},
        {"name": f"{SLUG}:exposure", "value": fd.get("exposure", "")},
        {"name": f"{SLUG}:detector", "value": fd.get("detector", "")},
    ]
    props.append({"name": f"{SLUG}:evidenceType", "value": fd.get("evidence_type", "")})
    props.append({"name": f"{SLUG}:evidenceStrength", "value": fd.get("evidence_strength", "")})
    if fd.get("extra", {}).get("key_usage"):
        props.append({"name": f"{SLUG}:keyUsage", "value": f"{fd['extra']['key_usage']} ({fd['extra'].get('key_usage_source', '')})"})
    if r.get("breach_year"):
        props.append({"name": f"{SLUG}:breachYear", "value": str(r["breach_year"])})
    for d in fd.get("data_links", []):
        props.append({"name": f"{SLUG}:protectsDataClass",
                      "value": f"{d['data_class']} ({d['lifetime_years']}y, conf {d['confidence']}, {d.get('kind', 'direct')})"})
    fam = registry_family(fd.get("algorithm"), fd.get("operation"))
    if fam:
        props.append({"name": f"{SLUG}:cdxRegistryFamily", "value": f"{fam['family']} ({fam['standard']})"})
        props.append({"name": f"{SLUG}:cdxRegistryPattern", "value": fam["pattern"]})
    if r.get("p_exposure") is not None:
        props.append({"name": f"{SLUG}:pExposure", "value": str(r.get("p_exposure"))})
    if r.get("criticality"):
        props.append({"name": f"{SLUG}:criticality", "value": r["criticality"]})
    if fd.get("recommendation", {}).get("summary"):
        props.append({"name": f"{SLUG}:recommendation", "value": fd["recommendation"]["summary"]})
    occurrence = {"location": fd["location"]}
    if fd.get("line"):
        occurrence["line"] = int(fd["line"])
    comp = {"type": "cryptographic-asset", "bom-ref": bref, "name": fd["name"],
            "evidence": {"occurrences": [occurrence]}, "properties": props}
    at = fd["asset_type"]
    if at == "certificate":
        ex = fd.get("extra", {})
        comp["cryptoProperties"] = {"assetType": "certificate", "certificateProperties": {
            "subjectName": ex.get("subject", ""), "issuerName": ex.get("issuer", ""),
            "notValidAfter": ex.get("not_after", ""), "certificateFormat": "X.509"}}
    elif at == "protocol":
        ptype = "tls" if "TLS" in fd["algorithm"].upper() else ("ssh" if fd.get("language") == "ssh" else "other")
        cp = {"assetType": "protocol", "protocolProperties": {"type": ptype}}
        v = fd.get("params", "")
        if v.upper().startswith(("TLSV", "SSLV")):
            cp["protocolProperties"]["version"] = v.replace("TLSv", "").replace("SSLv", "")
        comp["cryptoProperties"] = cp
    elif at in ("key", "cloud-kms", "hsm") and fd["operation"] in ("keygen", "store", "link") and at != "hsm":
        comp["cryptoProperties"] = {"assetType": "related-crypto-material", "relatedCryptoMaterialProperties": {
            "type": "private-key" if at == "key" else "key", "size": int(fd["params"]) if str(fd["params"]).isdigit() else None}}
        if comp["cryptoProperties"]["relatedCryptoMaterialProperties"]["size"] is None:
            del comp["cryptoProperties"]["relatedCryptoMaterialProperties"]["size"]
    elif at == "library":
        comp["type"] = "library"
        comp["version"] = fd.get("params") or "unknown"
        comp["name"] = fd["algorithm"]
    else:
        ap = {"primitive": PRIMITIVE_MAP.get(fd.get("primitive", "other"), "other"),
              "executionEnvironment": "software-plain-ram",
              "cryptoFunctions": FUNC_MAP.get(fd.get("operation", ""), ["other"]),
              "nistQuantumSecurityLevel": QLEVEL.get(r.get("class"), 0)}
        if fd.get("params"):
            ap["parameterSetIdentifier"] = str(fd["params"])
        comp["cryptoProperties"] = {"assetType": "algorithm", "algorithmProperties": ap}
        oid = OIDS.get(fd["algorithm"].upper())
        if oid:
            comp["cryptoProperties"]["oid"] = oid
    return comp


def build_cbom(scan):
    comps = [_component(f) for f in scan.findings]
    refs = {c["bom-ref"] for c in comps}
    deps = {}
    for f in scan.findings:
        kf = f.extra.get("key_finding")
        if kf and f"crypto-{kf}" in refs and f"crypto-{f.fid}" in refs and kf != f.fid:
            deps.setdefault(f"crypto-{f.fid}", set()).add(f"crypto-{kf}")
    dependencies = [{"ref": r, "dependsOn": sorted(v)} for r, v in sorted(deps.items())]
    bom = {
        "$schema": "http://cyclonedx.org/schema/bom-1.6.schema.json",
        "bomFormat": "CycloneDX", "specVersion": "1.6", "serialNumber": f"urn:uuid:{uuid.uuid4()}", "version": 1,
        "metadata": {"timestamp": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                     "tools": {"components": [{"type": "application", "name": BRAND["name"], "version": BRAND.get("version", "0")}]},
                     "component": {"type": "application", "name": scan.label, "bom-ref": "target"},
                     "properties": [{"name": f"{SLUG}:crqc:" + k, "value": str(v)} for k, v in scan.policy["crqc"].items()]},
        "components": comps,
    }
    if dependencies:
        bom["dependencies"] = dependencies
    return bom


def validate(bom):
    """Returns (ok, errors). Uses the official CycloneDX 1.6 JSON schema bundled with the tool."""
    try:
        from jsonschema import Draft7Validator
        from referencing import Registry, Resource
        from referencing.jsonschema import DRAFT7
    except Exception:
        return None, ["jsonschema not installed; schema validation skipped"]
    reg = Registry()
    for fn in os.listdir(SCHEMA_DIR):
        if fn.endswith(".json"):
            with open(os.path.join(SCHEMA_DIR, fn)) as fh:
                s = json.load(fh)
            r = Resource(contents=s, specification=DRAFT7)
            if isinstance(s, dict) and "$id" in s:
                reg = reg.with_resource(s["$id"], r)
            reg = reg.with_resource(fn, r)
    with open(os.path.join(SCHEMA_DIR, "bom-1.6.schema.json")) as fh:
        schema = json.load(fh)
    errs = [f"{'/'.join(map(str, e.path))}: {e.message[:160]}" for e in Draft7Validator(schema, registry=reg).iter_errors(bom)]
    return not errs, errs[:20]
