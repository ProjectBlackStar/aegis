"""Configs and infrastructure-as-code: TLS (nginx/Apache/OpenSSL), SSH, cloud KMS key specs."""
from __future__ import annotations

import re
from ..model import Finding


def _mk(path, line, algo, params, op, prim, evidence, asset="protocol", conf=0.9, lang="config"):
    return Finding(asset_type=asset, algorithm=algo, params=params, operation=op, primitive=prim, location=path,
                   line=line, detector="config", evidence=evidence.strip()[:160], confidence=conf, language=lang,
                   exposure="external" if asset == "protocol" else "internal")


TLS_PROTO = {"SSLV2": "SSLv2", "SSLV3": "SSLv3", "TLSV1": "TLSv1.0", "TLSV1.0": "TLSv1.0", "TLSV1.1": "TLSv1.1",
             "TLSV1.2": "TLSv1.2", "TLSV1.3": "TLSv1.3"}
WEAK_CIPHER_WORDS = {"DES-CBC3": "3DES", "3DES": "3DES", "RC4": "RC4", "MD5": "MD5", "NULL": "NULL", "EXPORT": "EXPORT"}
KMS_SPEC = {"RSA_2048": ("RSA", "2048"), "RSA_3072": ("RSA", "3072"), "RSA_4096": ("RSA", "4096"),
            "ECC_NIST_P256": ("ECDSA", "P-256"), "ECC_NIST_P384": ("ECDSA", "P-384"), "ECC_NIST_P521": ("ECDSA", "P-521"),
            "ECC_SECG_P256K1": ("ECDSA", "secp256k1"), "SYMMETRIC_DEFAULT": ("AES", "256-GCM"), "HMAC_256": ("HMAC", "SHA-256")}
SSH_KEX = {"diffie-hellman-group1-sha1": ("DH", "group1-SHA1"), "diffie-hellman-group14-sha1": ("DH", "group14-SHA1"),
           "diffie-hellman-group14-sha256": ("DH", "group14"), "curve25519-sha256": ("X25519", "kex"),
           "ecdh-sha2-nistp256": ("ECDH", "P-256"), "sntrup761x25519-sha512@openssh.com": ("sntrup761+X25519", "hybrid PQ"),
           "mlkem768x25519-sha256": ("X25519MLKEM768", "hybrid PQ")}


def is_config(name: str, text: str) -> bool:
    n = name.lower()
    return n.endswith((".conf", ".cnf", ".tf", ".hcl", ".cfg", ".ini", ".yaml", ".yml", "sshd_config", "ssh_config", ".toml",
                       "haproxy.cfg", "java.security")) \
        or "ssl_protocols" in text or "SSLProtocol" in text or "customer_master_key_spec" in text or "ssl-default-bind" in text


def scan_config(path: str, text: str):
    out = []
    for i, raw in enumerate(text.splitlines(), 1):
        line = raw.split("#", 1)[0] if not path.endswith((".tf", ".hcl")) else re.split(r"(?<!:)#|//", raw, 1)[0]
        s = line.strip()
        if not s:
            continue
        low = s.lower()
        # nginx / apache
        m = re.match(r"(ssl_protocols|sslprotocol)\s+(.+?);?$", s, re.I)
        if m:
            for p in re.split(r"[\s]+", m.group(2).replace(";", "")):
                pu = p.lstrip("+-").upper()
                if pu in TLS_PROTO:
                    out.append(_mk(path, i, "TLS", TLS_PROTO[pu], "tls", "protocol", raw))
            continue
        m = re.match(r"(ssl_ciphers|sslciphersuite)\s+(.+?);?$", s, re.I)
        if m:
            suites = m.group(2).replace(";", "").strip("\"'")
            weak = sorted({v for k, v in WEAK_CIPHER_WORDS.items() if k in suites.upper()})
            kex = "RSA/ECDHE"
            for w in weak:
                out.append(_mk(path, i, w, "TLS cipher suite", "encrypt", "block-cipher", raw, asset="algorithm"))
            static = [x for x in suites.split(":") if x and not x.startswith(("ECDHE", "DHE", "EDH", "TLS_", "!", "-", "+"))
                      and not x.upper().startswith(("HIGH", "MEDIUM", "LOW", "DEFAULT", "ALL", "EECDH", "EDH"))]
            if static:
                f = _mk(path, i, "RSA", "static key transport (" + ", ".join(static[:3]) + ")", "kex", "pke", raw, asset="algorithm")
                f.extra["note"] = "No forward secrecy: recorded traffic can be decrypted later if the server key leaks or is broken"
                out.append(f)
            out.append(_mk(path, i, "TLS", "cipher suites, RSA/ECDHE key exchange", "tls", "protocol", raw))
            continue
        # OpenSSL config
        m = re.match(r"(MinProtocol|CipherString)\s*=\s*(\S+)", s)
        if m and m.group(1) == "MinProtocol" and m.group(2).upper() in TLS_PROTO:
            f = _mk(path, i, "TLS", TLS_PROTO[m.group(2).upper()], "tls", "protocol", raw)
            f.extra["minimum_version"] = True
            out.append(f)
            continue
        # SSH
        m = re.match(r"(KexAlgorithms|HostKeyAlgorithms|HostKey|Ciphers|MACs)\s+(.+)$", s)
        if m:
            key, vals = m.group(1), [v.strip() for v in m.group(2).split(",")]
            for v in vals:
                if key == "KexAlgorithms":
                    algo, prm = SSH_KEX.get(v, ("DH" if "diffie" in v else "ECDH", v))
                    out.append(_mk(path, i, algo, prm, "kex", "key-agree", raw, asset="algorithm", lang="ssh"))
                elif key in ("HostKeyAlgorithms",):
                    algo = "RSA" if "rsa" in v else ("Ed25519" if "ed25519" in v else "ECDSA")
                    prm = "SHA-1 (ssh-rsa)" if v == "ssh-rsa" else v
                    out.append(_mk(path, i, "SHA-1" if v == "ssh-rsa" else algo, prm, "sign", "signature", raw, asset="algorithm", lang="ssh"))
                elif key == "HostKey":
                    algo = "RSA" if "rsa" in v else ("Ed25519" if "ed25519" in v else "ECDSA")
                    out.append(_mk(path, i, algo, "SSH host key", "sign", "signature", raw, asset="key", lang="ssh"))
                elif key == "MACs" and "sha1" in v:
                    out.append(_mk(path, i, "SHA-1", "HMAC (SSH)", "mac", "mac", raw, asset="algorithm", lang="ssh"))
                elif key == "Ciphers" and v.startswith("aes128"):
                    out.append(_mk(path, i, "AES", "128-" + v.split("-")[-1].upper(), "encrypt", "block-cipher", raw, asset="algorithm", lang="ssh"))
            continue
        # Terraform / cloud KMS
        m = re.search(r"(customer_master_key_spec|key_spec|algorithm)\s*=\s*\"([A-Z0-9_]+)\"", s)
        if m and m.group(2) in KMS_SPEC:
            algo, prm = KMS_SPEC[m.group(2)]
            f = _mk(path, i, algo, prm, "keygen", "pke" if algo == "RSA" else ("signature" if algo == "ECDSA" else "block-cipher"),
                    raw, asset="cloud-kms", lang="terraform")
            f.exposure = "internal"
            out.append(f)
        m = re.search(r"(azurerm_key_vault_key|google_kms_crypto_key)", s)
        if m:
            out.append(_mk(path, i, "Cloud KMS key", m.group(1), "keygen", "other", raw, asset="cloud-kms", lang="terraform"))
    # cloud KMS: the declared key usage tells us encryption vs signing
    lines = text.splitlines()
    for f in out:
        if f.asset_type != "cloud-kms" or not f.line:
            continue
        lo = f.line - 1
        while lo > 0 and "{" not in lines[lo]:
            lo -= 1
        for raw in lines[lo:lo + 15]:
            m = re.search(r"key_usage\s*=\s*\"([A-Z_]+)\"", raw)
            if m:
                f.extra["declared_usage"] = {"ENCRYPT_DECRYPT": "encryption", "SIGN_VERIFY": "signature",
                                             "GENERATE_VERIFY_MAC": "mac", "KEY_AGREEMENT": "key-establishment"}.get(m.group(1), m.group(1).lower())
                f.evidence += f" (key_usage = {m.group(1)})"
                break
            if raw.strip() == "}":
                break
    out.extend(scan_haproxy_k8s(path, text))
    try:
        tls_profile(path, text, out)
    except Exception:
        pass
    return out


# ---------------------------------------------------------------------------------------------
# TLS profile: expand cipher strings with the local TLS library, map them to IANA names (bundled registry),
# detect key-exchange groups (incl. post-quantum hybrids) and compare with Mozilla's server-side TLS guidelines.
PQ_GROUP_RX = re.compile(r"MLKEM|KYBER", re.I)


def expand_ciphers(spec: str):
    import ssl
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    try:
        ctx.set_ciphers(spec.strip("\"'") + ":@SECLEVEL=0")
    except ssl.SSLError:
        try:
            ctx.set_ciphers(spec.strip("\"'"))
        except ssl.SSLError:
            return []
    from ..tlscost import tls_data
    by_ossl = {}
    for c in tls_data()["ciphers"]:
        if c["openssl"] not in by_ossl or c["iana"].startswith("TLS_"):
            by_ossl[c["openssl"]] = c
    out = []
    for c in ctx.get_ciphers():
        if c.get("protocol") == "TLSv1.3":
            continue  # TLS 1.3 suites are not controlled by the cipher string
        reg = by_ossl.get(c["name"], {})
        out.append({"openssl": c["name"], "iana": reg.get("iana", ""), "hex": reg.get("hex", ""), "kx": c.get("kea", ""),
                    "auth": c.get("auth", ""), "enc": c.get("symmetric", ""), "bits": c.get("strength_bits")})
    have = {c["openssl"] for c in out}
    for tok in re.split(r"[:,\s]+", spec.strip("\"'")):
        if tok in by_ossl and tok not in have:  # named explicitly but not built into this machine's TLS library
            reg = by_ossl[tok]
            kx = {"RSA": "kx-rsa", "ECDH": "kx-ecdhe", "DH": "kx-dhe"}.get(reg["kx"].split("(")[0], reg["kx"])
            out.append({"openssl": tok, "iana": reg["iana"], "hex": reg["hex"], "kx": kx, "auth": reg["au"], "enc": reg["enc"],
                        "bits": None, "legacy": True})
    return out


def tls_profile(path: str, text: str, findings):
    """Adds a per-file TLS profile (protocols, expanded suites, groups, Mozilla comparison) to the TLS findings."""
    from ..tlscost import tls_data
    protos, suites, groups, gline, cert_files = set(), [], [], 0, []
    for i, raw in enumerate(text.splitlines(), 1):
        s = raw.split("#", 1)[0].strip()
        m = re.match(r"(ssl_certificate|SSLCertificateFile|bind\s.*\scrt)\s+(\S+?);?$", s, re.I)
        if m:
            cert_files.append(m.group(2).rsplit("/", 1)[-1])
        m = re.match(r"(ssl_protocols|sslprotocol|ssl-min-ver|ssl-default-bind-options)\s+(.+?);?$", s, re.I)
        if m:
            for p in re.split(r"\s+", m.group(2).replace(";", "")):
                pu = p.lstrip("+-").upper().replace("TLSV1.0", "TLSV1")
                if pu in TLS_PROTO and not p.startswith("-"):
                    protos.add(TLS_PROTO[pu])
        m = re.match(r"(ssl_ciphers|sslciphersuite|ssl-default-bind-ciphers|ciphers)\s+(.+?);?$", s, re.I)
        if m:
            suites = expand_ciphers(m.group(2).replace(";", ""))
        m = re.match(r"(ssl_ecdh_curve|ssl-default-bind-curves|curves)\s+(.+?);?$", s, re.I) or \
            re.match(r"(?:ssl_conf_command|SSLOpenSSLConfCmd)\s+(?:Groups|Curves)\s+(.+?);?$", s, re.I)
        if m:
            groups = [g for g in re.split(r"[:,\s]+", m.groups()[-1].replace(";", "")) if g]
            gline = i
    if not (protos or suites or groups):
        return
    moz = tls_data()["mozilla"]
    inter = moz["configurations"]["intermediate"]
    modern = moz["configurations"]["modern"]
    allowed = set(inter["ciphers"]["openssl"])
    off = [c for c in suites if c["openssl"] not in allowed]
    static_rsa = [c for c in suites if c["kx"] == "kx-rsa"]
    pq = [g for g in groups if PQ_GROUP_RX.search(g)]
    profile = {
        "protocols": sorted(protos), "suites": suites, "cert_files": cert_files, "groups": groups, "pq_groups": pq,
        "outside_mozilla_intermediate": [c["openssl"] for c in off], "static_rsa": [c["openssl"] for c in static_rsa],
        "mozilla_version": moz.get("version"), "mozilla_intermediate_groups": inter.get("tls_curves", []),
        "mozilla_modern_protocols": modern.get("tls_versions", []),
        "verdict": ("modern" if protos and protos <= {"TLSv1.3"} else
                    "intermediate" if protos <= {"TLSv1.2", "TLSv1.3"} and not off else "old / non-compliant"),
    }
    for f in findings:
        if f.algorithm == "TLS" or f.extra.get("tls_profile_anchor"):
            f.extra["tls_profile"] = profile
    if groups and not pq:
        f = _mk(path, gline or 1, "ECDH", "groups: " + ":".join(groups), "kex", "key-agree",
                "no post-quantum hybrid group offered (Mozilla " + str(moz.get("version")) + " recommends " +
                ", ".join(inter.get("tls_curves", [])[:2]) + ")", asset="algorithm")
        f.extra["tls_profile"] = profile
        findings.append(f)
    if pq:
        f = _mk(path, gline or 1, "X25519MLKEM768", "hybrid key exchange", "kex", "kem",
                "post-quantum hybrid group configured", asset="algorithm")
        f.extra["tls_profile"] = profile
        findings.append(f)


def scan_haproxy_k8s(path: str, text: str):
    """HAProxy global TLS settings and Kubernetes TLS secrets / ingress annotations."""
    out = []
    low = path.lower()
    if low.endswith((".yaml", ".yml")) and ("kubernetes.io/tls" in text or "tls.crt" in text):
        import base64
        for m in re.finditer(r"tls\.crt:\s*([A-Za-z0-9+/=]{100,})", text):
            try:
                der_or_pem = base64.b64decode(m.group(1))
            except Exception:
                continue
            from .certs import scan_certs
            line = text.count("\n", 0, m.start()) + 1
            for f in scan_certs(path, der_or_pem):
                f.line = line
                f.evidence = "Kubernetes TLS secret: " + f.evidence
                out.append(f)
    for i, raw in enumerate(text.splitlines(), 1):
        s = raw.strip()
        m = re.search(r"nginx\.ingress\.kubernetes\.io/ssl-(protocols|ciphers):\s*\"?([^\"]+)\"?", s)
        if m:
            if m.group(1) == "protocols":
                for p in m.group(2).split():
                    if p.upper() in TLS_PROTO:
                        out.append(_mk(path, i, "TLS", TLS_PROTO[p.upper()], "tls", "protocol", raw))
            else:
                for c in expand_ciphers(m.group(2)):
                    if c["kx"] == "kx-rsa":
                        out.append(_mk(path, i, "RSA", f"static key transport ({c['openssl']})", "kex", "pke", raw, asset="algorithm"))
                        break
        m = re.match(r"ssl-min-ver\s+(\S+)", s) or re.search(r"ssl-default-bind-options\s+.*ssl-min-ver\s+(\S+)", s)
        if m and m.group(1).upper() in TLS_PROTO:
            f = _mk(path, i, "TLS", TLS_PROTO[m.group(1).upper()], "tls", "protocol", raw)
            f.extra["minimum_version"] = True
            f.evidence = f"minimum TLS version {TLS_PROTO[m.group(1).upper()]}: " + f.evidence
            out.append(f)
        m = re.match(r"ssl-default-bind-ciphers\s+(\S+)", s)
        if m:
            ex = expand_ciphers(m.group(1))
            st = [c["openssl"] for c in ex if c["kx"] == "kx-rsa"]
            if st:
                f = _mk(path, i, "RSA", "static key transport (" + ", ".join(st[:3]) + ")", "kex", "pke", raw, asset="algorithm")
                f.extra["note"] = "No forward secrecy: recorded traffic can be decrypted later if the server key leaks or is broken"
                out.append(f)
            out.append(_mk(path, i, "TLS", "cipher suites (HAProxy)", "tls", "protocol", raw))
    return out
