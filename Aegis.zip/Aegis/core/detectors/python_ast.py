"""Python detector: resolved-import crypto API detection, crypto-object tracking,
and intra-procedural taint that links each crypto call to the data it protects.

Never matches text: comments and string contents cannot produce findings.
"""
from __future__ import annotations

import ast
import re
from ..model import Finding
from ..knowledge import classify_identifier, classify_value, split_ident

# qualified-name suffix -> spec
# spec: (algorithm, operation, primitive, object_kind or None)
CRYPTO = "cryptography.hazmat.primitives"
API = {
    # cryptography (pyca) asymmetric
    f"{CRYPTO}.asymmetric.rsa.generate_private_key": ("RSA", "keygen", "pke", "asym"),
    f"{CRYPTO}.asymmetric.ec.generate_private_key": ("ECDSA", "keygen", "signature", "asym"),
    f"{CRYPTO}.asymmetric.dsa.generate_private_key": ("DSA", "keygen", "signature", "asym"),
    f"{CRYPTO}.asymmetric.ed25519.Ed25519PrivateKey.generate": ("Ed25519", "keygen", "signature", "asym"),
    f"{CRYPTO}.asymmetric.ed448.Ed448PrivateKey.generate": ("Ed448", "keygen", "signature", "asym"),
    f"{CRYPTO}.asymmetric.x25519.X25519PrivateKey.generate": ("X25519", "keygen", "key-agree", "asym"),
    f"{CRYPTO}.asymmetric.dh.generate_parameters": ("DH", "keygen", "key-agree", "asym"),
    f"{CRYPTO}.serialization.load_pem_private_key": ("RSA/ECC", "keyload", "pke", "asym"),
    f"{CRYPTO}.serialization.load_der_private_key": ("RSA/ECC", "keyload", "pke", "asym"),
    f"{CRYPTO}.serialization.load_pem_public_key": ("RSA/ECC", "keyload", "pke", "asym"),
    f"{CRYPTO}.serialization.load_der_public_key": ("RSA/ECC", "keyload", "pke", "asym"),
    f"{CRYPTO}.serialization.load_ssh_public_key": ("RSA/ECC", "keyload", "pke", "asym"),
    f"{CRYPTO}.serialization.load_ssh_private_key": ("RSA/ECC", "keyload", "pke", "asym"),
    f"{CRYPTO}.asymmetric.rsa.RSAPrivateNumbers": ("RSA", "keyload", "pke", "asym"),
    f"{CRYPTO}.asymmetric.rsa.RSAPublicNumbers": ("RSA", "keyload", "pke", "asym"),
    f"{CRYPTO}.asymmetric.ec.EllipticCurvePrivateNumbers": ("ECDSA", "keyload", "signature", "asym"),
    f"{CRYPTO}.asymmetric.ec.EllipticCurvePublicNumbers": ("ECDSA", "keyload", "signature", "asym"),
    f"{CRYPTO}.asymmetric.ec.derive_private_key": ("ECDSA", "keyload", "signature", "asym"),
    f"{CRYPTO}.asymmetric.ed25519.Ed25519PublicKey.from_public_bytes": ("Ed25519", "keyload", "signature", "asym"),
    f"{CRYPTO}.asymmetric.ed25519.Ed25519PrivateKey.from_private_bytes": ("Ed25519", "keyload", "signature", "asym"),
    f"{CRYPTO}.asymmetric.ed448.Ed448PublicKey.from_public_bytes": ("Ed448", "keyload", "signature", "asym"),
    f"{CRYPTO}.asymmetric.ed448.Ed448PrivateKey.from_private_bytes": ("Ed448", "keyload", "signature", "asym"),
    f"{CRYPTO}.asymmetric.x25519.X25519PublicKey.from_public_bytes": ("X25519", "keyload", "key-agree", "asym"),
    "jwt.algorithms.RSAAlgorithm": ("RSA", "sign", "signature", None),
    "jwt.algorithms.RSAPSSAlgorithm": ("RSA", "sign", "signature", None),
    "jwt.algorithms.ECAlgorithm": ("ECDSA", "sign", "signature", None),
    # cryptography symmetric
    f"{CRYPTO}.ciphers.Cipher": ("AES", "encrypt", "block-cipher", "sym"),
    f"{CRYPTO}.ciphers.aead.AESGCM": ("AES", "encrypt", "block-cipher", "sym"),
    f"{CRYPTO}.ciphers.aead.ChaCha20Poly1305": ("ChaCha20-Poly1305", "encrypt", "stream-cipher", "sym"),
    f"{CRYPTO}.hashes.MD5": ("MD5", "hash", "hash", None),
    f"{CRYPTO}.hashes.SHA1": ("SHA-1", "hash", "hash", None),
    f"{CRYPTO}.hashes.SHA224": ("SHA-224", "hash", "hash", None),
    f"{CRYPTO}.hashes.SHA256": ("SHA-256", "hash", "hash", None),
    f"{CRYPTO}.hashes.SHA384": ("SHA-384", "hash", "hash", None),
    f"{CRYPTO}.hashes.SHA512": ("SHA-512", "hash", "hash", None),
    # hashlib / hmac
    "hashlib.md5": ("MD5", "hash", "hash", None),
    "hashlib.sha1": ("SHA-1", "hash", "hash", None),
    "hashlib.sha224": ("SHA-224", "hash", "hash", None),
    "hashlib.sha256": ("SHA-256", "hash", "hash", None),
    "hashlib.sha384": ("SHA-384", "hash", "hash", None),
    "hashlib.sha512": ("SHA-512", "hash", "hash", None),
    "hashlib.new": ("HASH", "hash", "hash", None),
    "hashlib.pbkdf2_hmac": ("PBKDF2", "kdf", "kdf", None),
    "hashlib.scrypt": ("scrypt", "kdf", "kdf", None),
    "hmac.new": ("HMAC", "mac", "mac", None),
    # PyCryptodome
    "Crypto.PublicKey.RSA.generate": ("RSA", "keygen", "pke", "asym"),
    "Crypto.PublicKey.RSA.import_key": ("RSA", "keyload", "pke", "asym"),
    "Crypto.PublicKey.ECC.generate": ("ECDSA", "keygen", "signature", "asym"),
    "Crypto.PublicKey.DSA.generate": ("DSA", "keygen", "signature", "asym"),
    "Crypto.Cipher.PKCS1_OAEP.new": ("RSA", "encrypt", "pke", "asymcipher"),
    "Crypto.Cipher.PKCS1_v1_5.new": ("RSA", "encrypt", "pke", "asymcipher"),
    "Crypto.Cipher.AES.new": ("AES", "encrypt", "block-cipher", "sym"),
    "Crypto.Cipher.DES.new": ("DES", "encrypt", "block-cipher", "sym"),
    "Crypto.Cipher.DES3.new": ("3DES", "encrypt", "block-cipher", "sym"),
    "Crypto.Cipher.ARC4.new": ("RC4", "encrypt", "stream-cipher", "sym"),
    "Crypto.Signature.pkcs1_15.new": ("RSA", "sign", "signature", "signer"),
    "Crypto.Signature.pss.new": ("RSA", "sign", "signature", "signer"),
    "Crypto.Signature.DSS.new": ("ECDSA", "sign", "signature", "signer"),
    "Crypto.Hash.MD5.new": ("MD5", "hash", "hash", None),
    "Crypto.Hash.SHA1.new": ("SHA-1", "hash", "hash", None),
    "Crypto.Hash.SHA256.new": ("SHA-256", "hash", "hash", None),
    # post-quantum (reference implementations)
    **{f"kyber_py.ml_kem.ML_KEM_{n}.{m}": ("ML-KEM", "kex" if m != "keygen" else "keygen", "kem", None)
       for n in (512, 768, 1024) for m in ("keygen", "encaps", "decaps")},
    **{f"dilithium_py.ml_dsa.ML_DSA_{n}.{m}": ("ML-DSA", "sign" if m == "sign" else "keygen", "signature", None)
       for n in (44, 65, 87) for m in ("keygen", "sign")},
    "oqs.KeyEncapsulation": ("ML-KEM", "kex", "kem", None),
    "oqs.Signature": ("ML-DSA", "sign", "signature", None),
    # JWT
    "jwt.encode": ("JWT", "sign", "signature", None),
    # TLS
    "ssl.SSLContext": ("TLS", "tls", "protocol", "tls"),
    "ssl.wrap_socket": ("TLS", "tls", "protocol", None),
    "ssl.create_default_context": ("TLS", "tls", "protocol", "tls"),
    # SSH
    "paramiko.RSAKey.generate": ("RSA", "keygen", "pke", "asym"),
    "paramiko.ECDSAKey.generate": ("ECDSA", "keygen", "signature", "asym"),
    "paramiko.DSSKey.generate": ("DSA", "keygen", "signature", "asym"),
    # HSM (PKCS#11)
    "pkcs11.lib": ("PKCS#11 HSM", "link", "other", "hsm"),
    "PyKCS11.PyKCS11Lib": ("PKCS#11 HSM", "link", "other", "hsm"),
    # Cloud KMS
    "boto3.client": ("AWS KMS", "link", "other", "kms"),
    "azure.keyvault.keys.crypto.CryptographyClient": ("Azure Key Vault", "link", "other", "kms"),
    "google.cloud.kms.KeyManagementServiceClient": ("GCP Cloud KMS", "link", "other", "kms"),
}

OBJ_METHODS = {"encrypt": "encrypt", "decrypt": "decrypt", "sign": "sign", "verify": "verify",
               "exchange": "kex", "update": "encrypt", "encrypt_and_digest": "encrypt", "asymmetric_sign": "sign",
               "asymmetric_decrypt": "decrypt", "generate_data_key": "kex", "wrap_key": "encrypt"}
CURVES = {"SECP256R1": "P-256", "SECP384R1": "P-384", "SECP521R1": "P-521", "SECP256K1": "secp256k1"}
AES_MODES = {"ECB", "CBC", "CTR", "GCM", "CFB", "OFB", "XTS", "CCM", "EAX", "SIV", "OCB"}
JWT_ALGS = {"RS": ("RSA", "signature"), "PS": ("RSA", "signature"), "ES": ("ECDSA", "signature"), "HS": ("HMAC", "mac"),
            "Ed": ("Ed25519", "signature")}
KMS_ALG_HINT = {"RSAES": "RSA", "RSASSA": "RSA", "ECDSA": "ECDSA", "SYMMETRIC_DEFAULT": "AES-256", "SM2": "SM2"}
ROUTE_DECOS = {"route", "get", "post", "put", "patch", "delete", "api_view", "websocket"}
CONTAINERS = {f"{CRYPTO}.asymmetric.padding.OAEP", f"{CRYPTO}.asymmetric.padding.PSS",
              f"{CRYPTO}.asymmetric.padding.MGF1", f"{CRYPTO}.asymmetric.padding.PKCS1v15",
              f"{CRYPTO}.asymmetric.ec.ECDSA", f"{CRYPTO}.kdf.hkdf.HKDF", f"{CRYPTO}.kdf.pbkdf2.PBKDF2HMAC"}


def _dotted(e):
    if isinstance(e, ast.Name):
        return e.id
    if isinstance(e, ast.Attribute):
        d = _dotted(e.value)
        return f"{d}.{e.attr}" if d else None
    if isinstance(e, ast.Call):
        return _dotted(e.func)
    return None


def _base_obj(e):
    """Innermost object an expression chain is rooted on, e.g. KEY.public_key().encrypt -> 'KEY'."""
    chain = []
    while isinstance(e, (ast.Attribute, ast.Call)):
        if isinstance(e, ast.Attribute):
            chain.append(e.attr)
            e = e.value
        else:
            e = e.func
    if isinstance(e, ast.Name):
        # support self.x style keys
        return e.id, list(reversed(chain))
    return None, list(reversed(chain))


def _const(e):
    return e.value if isinstance(e, ast.Constant) else None


class _FileAnalyzer(ast.NodeVisitor):
    def __init__(self, path, source):
        self.path = path
        self.lines = source.splitlines()
        self.alias = {}
        self.findings: list[Finding] = []
        self.summaries = {}      # func name -> {param_index: [finding refs]}
        self.callsites = []      # (callee, caller, [(arg_index, [sources])], line)
        self.routes = set()
        self.module_objs = {}    # module-level crypto objects: name -> info
        self.objs = self.module_objs
        self.taint = {}          # var -> set(source names)
        self.params = []
        self.func = None
        self.cls = None
        self.sizes = {}          # var -> byte length (from os.urandom(N) or bytes literal)
        self.module_sizes = self.sizes
        self.hops = {}           # var -> (line, [names it was derived from])
        self.func_line = 0
        self.type_aliases = {}
        self.depth = 0           # nesting inside a crypto call

    # ---- helpers
    def qual(self, dotted):
        if not dotted:
            return ""
        head, _, rest = dotted.partition(".")
        q = self.alias.get(head)
        if q:
            return q + ("." + rest if rest else "")
        return dotted

    def snippet(self, line):
        if 0 < line <= len(self.lines):
            return self.lines[line - 1].strip()[:160]
        return ""

    def sources_of(self, node):
        out = set()
        for x in ast.walk(node):
            if isinstance(x, ast.Name):
                if x.id in self.taint:
                    out |= self.taint[x.id]
                elif classify_identifier(x.id):
                    out.add(x.id)
            elif isinstance(x, ast.Attribute) and classify_identifier(x.attr):
                out.add(x.attr)
            elif isinstance(x, ast.Subscript):
                k = _const(x.slice)
                if isinstance(k, str) and classify_identifier(k):
                    out.add(k)
            elif isinstance(x, ast.Call) and _dotted(x.func) and _dotted(x.func).endswith((".get", ".getlist")):
                if x.args:
                    k = _const(x.args[0])
                    if isinstance(k, str) and classify_identifier(k):
                        out.add(k)
            elif isinstance(x, ast.Constant) and isinstance(x.value, str):
                if classify_value(x.value):
                    out.add("literal:" + x.value)
        return out

    def flow_for(self, data_node, call_node):
        """Ordered hops from where the data enters to the crypto call (intra-procedural)."""
        call_line = getattr(call_node, "lineno", 0)
        end = {"line": call_line, "text": self.snippet(call_line), "hop": "crypto call"}
        if data_node is None:
            return [end]
        names = [x.id for x in ast.walk(data_node) if isinstance(x, ast.Name)
                 and (x.id in self.taint or x.id in self.params or classify_identifier(x.id))]
        if not names:
            try:
                expr = ast.unparse(data_node)
            except Exception:
                expr = "expression"
            return [{"line": call_line, "text": f"data expression: {expr[:120]}", "hop": "read"}, end]
        cur, seen, assigns = names[0], set(), []
        while cur in self.hops and cur not in seen and len(assigns) < 8:
            seen.add(cur)
            line, froms = self.hops[cur]
            assigns.append({"line": line, "text": self.snippet(line), "hop": "assignment"})
            nxt = [x for x in froms if x not in seen]
            if not nxt:
                break
            cur = nxt[0]
        if cur in self.params:
            root = {"line": self.func_line, "text": f"parameter '{cur}' of {self.func}()", "hop": "parameter"}
        else:
            root = {"line": assigns[-1]["line"] if assigns else call_line, "text": f"'{cur}' read here", "hop": "read"}
        return [root] + list(reversed(assigns)) + [end]

    def add(self, algo, params, op, prim, node, evidence=None, asset="algorithm", conf=0.95, sources=None, extra=None,
            data_node=None):
        f = Finding(asset_type=asset, algorithm=algo, params=str(params or ""), operation=op, primitive=prim,
                    location=self.path, line=getattr(node, "lineno", 0), detector="python-ast",
                    evidence=evidence or self.snippet(getattr(node, "lineno", 0)), confidence=conf,
                    language="python", context=".".join(x for x in (self.cls, self.func) if x) or "<module>",
                    extra=dict(extra or {}))
        f.extra["sources"] = sorted(sources or [])
        f.extra["func"] = self.func
        if sources:
            f.extra["flow"] = self.flow_for(data_node, node)
        self.findings.append(f)
        # function summary: which params reach this crypto op
        if self.func and sources:
            for i, p in enumerate(self.params):
                if p in sources:
                    self.summaries.setdefault(self.func, {}).setdefault(i, []).append(len(self.findings) - 1)
        return f

    # ---- imports
    def visit_Import(self, n):
        for a in n.names:
            self.alias[a.asname or a.name.split(".")[0]] = a.name if a.asname else a.name.split(".")[0]
        self.generic_visit(n)

    def visit_ImportFrom(self, n):
        if n.module:
            for a in n.names:
                self.alias[a.asname or a.name] = f"{n.module}.{a.name}"
        self.generic_visit(n)

    # ---- scopes
    def visit_ClassDef(self, n):
        old = self.cls
        self.cls = n.name
        self.generic_visit(n)
        self.cls = old

    def visit_FunctionDef(self, n):
        old = (self.func, self.taint, self.params, self.objs, self.sizes, self.hops, self.func_line)
        self.func = n.name
        self.hops = {}
        self.func_line = n.lineno
        self.params = [a.arg for a in n.args.args]
        self.taint = {p: {p} for p in self.params if p not in ("self", "cls")}
        self.objs = dict(self.module_objs)  # inherit module-level objects
        self.sizes = dict(self.module_sizes)
        for a in n.args.args + n.args.kwonlyargs:
            if a.annotation is not None:
                try:
                    ann = ast.unparse(a.annotation)
                except Exception:
                    ann = ""
                ann = " ".join(self.type_aliases.get(tok, tok) for tok in re.split(r"([\w.]+)", ann))
                fam = None
                if "RSAPrivateKey" in ann or "RSAPublicKey" in ann:
                    fam = ("RSA", "pke")
                elif "EllipticCurvePrivateKey" in ann or "EllipticCurvePublicKey" in ann:
                    fam = ("ECDSA", "signature")
                elif "Ed25519" in ann and "Ed448" in ann:
                    fam = ("EdDSA", "signature")
                elif "Ed25519" in ann:
                    fam = ("Ed25519", "signature")
                elif "Ed448" in ann:
                    fam = ("Ed448", "signature")
                if fam and len({x for x in ("RSA", "EllipticCurve", "Ed") if x in ann}) == 1:
                    self.objs[a.arg] = {"algo": fam[0], "params": "", "kind": "asym", "finding": None, "typed_by": "annotation"}
        for d in n.decorator_list:
            dn = _dotted(d.func if isinstance(d, ast.Call) else d) or ""
            if dn.split(".")[-1] in ROUTE_DECOS:
                self.routes.add(n.name)
        self.generic_visit(n)
        self.func, self.taint, self.params, self.objs, self.sizes, self.hops, self.func_line = old

    visit_AsyncFunctionDef = visit_FunctionDef

    # ---- assignments: taint + object typing + sizes
    def visit_Assign(self, n):
        self.visit(n.value)  # visit RHS first (may create finding)
        src = self.sources_of(n.value)
        for t in n.targets:
            name = _dotted(t) if isinstance(t, (ast.Name, ast.Attribute)) else None
            if not name:
                continue
            if src:
                self.taint[name] = set(src)
                froms = [x.id for x in ast.walk(n.value) if isinstance(x, ast.Name)
                         and (x.id in self.taint or x.id in self.params or classify_identifier(x.id))]
                self.hops[name] = (n.lineno, froms)
            # sizes
            if isinstance(n.value, ast.Call) and (self.qual(_dotted(n.value.func)) in ("os.urandom", "secrets.token_bytes")):
                if n.value.args and isinstance(_const(n.value.args[0]), int):
                    self.sizes[name] = _const(n.value.args[0])
            if isinstance(n.value, ast.Constant) and isinstance(n.value.value, bytes):
                self.sizes[name] = len(n.value.value)
            # object typing
            info = getattr(n.value, "_crypto_obj", None)
            if info is None and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Attribute):
                inner = n.value.func.value
                info = getattr(inner, "_crypto_obj", None)
            vals = [n.value.body, n.value.orelse] if isinstance(n.value, ast.IfExp) else [n.value]
            for v in vals:
                if info is not None:
                    break
                if isinstance(v, ast.Call):
                    base, chain = _base_obj(v.func)
                    if base in self.objs and chain and chain[-1] in ("public_key", "private_key", "publickey"):
                        info = self.objs[base]
                elif isinstance(v, ast.Name) and v.id in self.objs:
                    info = self.objs[v.id]
            if info:
                self.objs[name] = info
                if self.func is None:
                    self.module_objs[name] = info
        for t in n.targets:
            if isinstance(t, ast.Name) and isinstance(n.value, ast.Constant) and isinstance(n.value.value, str):
                if classify_value(n.value.value):
                    self.taint[t.id] = {"literal:" + n.value.value}

    def visit_Call(self, n):
        if getattr(n, "_kq_done", False):
            return
        n._kq_done = True
        n.func._is_func = True
        d = _dotted(n.func)
        q = self.qual(d)
        if q.startswith("Cryptodome."):
            q = "Crypto." + q[len("Cryptodome."):]
        head = (d or "").split(".")[0]
        spec = API.get(q) if head in self.alias else None   # unresolved names are not imports (e.g. a local 'jwt' string)
        handled = False
        if spec:
            handled = self._api_call(n, q, spec)
        obj_handled = False
        if not handled:
            obj_handled = self._object_call(n)
        # record call sites for inter-procedural linking
        if isinstance(n.func, (ast.Name, ast.Attribute)):
            callee = n.func.id if isinstance(n.func, ast.Name) else n.func.attr
            args = [(i, sorted(self.sources_of(a))) for i, a in enumerate(n.args)]
            args = [(i, s) for i, s in args if s]
            self.callsites.append((callee, self.func, args, n.lineno))
        nested = bool(spec) or obj_handled or q in CONTAINERS
        self.depth += 1 if nested else 0
        self.generic_visit(n)
        self.depth -= 1 if nested else 0

    def visit_Attribute(self, n):
        if not getattr(n, "_is_func", False) and self.depth == 0:
            d = _dotted(n)
            head = (d or "").split(".")[0]
            if d and head in self.alias:
                q = self.qual(d)
                spec = API.get(q)
                if spec and spec[2] == "hash":
                    self.add(spec[0], "", "hash", "hash", n, extra={"reference": True},
                             evidence=self.snippet(n.lineno) + "   (algorithm selected by reference)", conf=0.8)
                elif q.startswith(CRYPTO + ".hashes.") and q.split(".")[-1] in ("MD5", "SHA1", "SHA224", "SHA256", "SHA384", "SHA512"):
                    nm = {"MD5": "MD5", "SHA1": "SHA-1", "SHA224": "SHA-224", "SHA256": "SHA-256", "SHA384": "SHA-384", "SHA512": "SHA-512"}[q.split(".")[-1]]
                    self.add(nm, "", "hash", "hash", n, extra={"reference": True},
                             evidence=self.snippet(n.lineno) + "   (algorithm selected by reference)", conf=0.8)
        self.generic_visit(n)

    def _kw(self, n, name, pos=None):
        for k in n.keywords:
            if k.arg == name:
                return k.value
        if pos is not None and len(n.args) > pos:
            return n.args[pos]
        return None

    def _api_call(self, n, q, spec):
        algo, op, prim, obj = spec
        params = ""
        extra = {}
        # nested hashes inside padding/sign calls are parameters, not separate assets
        if prim == "hash" and self.depth > 0 and q.startswith(CRYPTO):
            return True
        if q.endswith("rsa.generate_private_key") or q.endswith("RSA.generate") or q.endswith("RSAKey.generate"):
            ks = self._kw(n, "key_size", 1 if q.endswith("generate_private_key") else 0) or self._kw(n, "bits", 0)
            params = str(_const(ks)) if ks is not None and _const(ks) else "?"
        elif q.endswith("ec.generate_private_key") or q.endswith("ECC.generate"):
            c = self._kw(n, "curve", 0)
            cn = (_dotted(c) or "").split(".")[-1] if c is not None else ""
            if isinstance(_const(c), str):
                cn = _const(c)
            params = CURVES.get(cn.upper(), cn)
        elif q.endswith("dsa.generate_private_key") or q.endswith("DSA.generate"):
            ks = self._kw(n, "key_size", 0)
            params = str(_const(ks)) if ks is not None else ""
        elif q.endswith("ciphers.Cipher"):
            alg = self._kw(n, "algorithm", 0)
            mode = self._kw(n, "mode", 1)
            an = (_dotted(alg) or "").split(".")[-1] if alg is not None else "AES"
            algo = {"TripleDES": "3DES", "ARC4": "RC4", "Blowfish": "Blowfish", "Camellia": "Camellia"}.get(an, an or "AES")
            mn = (_dotted(mode) or "").split(".")[-1] if mode is not None else ""
            size = ""
            if isinstance(alg, ast.Call) and alg.args:
                size = self._keysize(alg.args[0])
            params = "-".join(x for x in (size, mn) if x)
        elif q.endswith("AESGCM") or q.endswith("ChaCha20Poly1305"):
            size = self._keysize(n.args[0]) if n.args else ""
            params = "-".join(x for x in (size, "GCM" if "AES" in algo else "") if x)
        elif q.endswith("AES.new") or q.endswith("DES.new") or q.endswith("DES3.new"):
            mode = self._kw(n, "mode", 1)
            mn = (_dotted(mode) or "").split(".")[-1].replace("MODE_", "") if mode is not None else ""
            size = self._keysize(n.args[0]) if n.args else ""
            params = "-".join(x for x in (size, mn) if x)
        elif q == "hashlib.new":
            v = _const(n.args[0]) if n.args else None
            if not isinstance(v, str):
                return True
            algo = {"md5": "MD5", "sha1": "SHA-1", "sha256": "SHA-256", "sha512": "SHA-512"}.get(v.lower(), v.upper())
        elif q == "hashlib.pbkdf2_hmac":
            v = _const(n.args[0]) if n.args else None
            params = f"HMAC-{str(v).upper()}" if v else ""
            if isinstance(v, str) and v.lower() in ("sha1", "md5"):
                algo = "SHA-1" if v.lower() == "sha1" else "MD5"
                op = "kdf"
        elif q == "hmac.new":
            dm = self._kw(n, "digestmod", 2)
            dn = ((_dotted(dm) or "").split(".")[-1] if dm is not None else "") or (str(_const(dm)) if dm is not None else "")
            dn = dn.lower()
            if "sha1" in dn:
                algo, params = "SHA-1", "HMAC"
            elif "md5" in dn:
                algo, params = "MD5", "HMAC"
            else:
                known = {"sha256": "SHA-256", "sha512": "SHA-512", "sha384": "SHA-384", "sha224": "SHA-224"}
                algo, params = "HMAC", known.get(dn, "hash chosen at runtime")
        elif q == "jwt.encode":
            a = self._kw(n, "algorithm", 2)
            v = _const(a) if a is not None else "HS256"
            v = v or "HS256"
            fam = JWT_ALGS.get(v[:2], ("JWT", "signature"))
            algo, prim = fam
            params = f"JWT {v}"
            if algo == "HMAC":
                algo, params, op = "HMAC", "SHA-" + v[2:], "mac"
        elif q.startswith("ssl."):
            proto = _dotted(n.args[0]) if n.args else ""
            proto = (proto or "").split(".")[-1]
            params = {"PROTOCOL_TLSv1": "TLSv1.0", "PROTOCOL_TLSv1_1": "TLSv1.1", "PROTOCOL_SSLv3": "SSLv3",
                      "PROTOCOL_SSLv23": "negotiated", "PROTOCOL_TLS_CLIENT": "TLSv1.2+", "PROTOCOL_TLS_SERVER": "TLSv1.2+"}.get(proto, "default")
            extra["note"] = "TLS key exchange uses classical ECDHE/RSA unless a hybrid PQ group is configured"
        elif q.startswith(("kyber_py.", "dilithium_py.")):
            params = q.split(".")[2].split("_")[-1]
        elif q.endswith("boto3.client"):
            v = _const(n.args[0]) if n.args else None
            if v != "kms":
                return False
        elif q.endswith("PKCS1_OAEP.new") or q.endswith("PKCS1_v1_5.new") or q.endswith("pkcs1_15.new") or q.endswith("pss.new") or q.endswith("DSS.new"):
            base, chain = _base_obj(n.args[0]) if n.args else (None, [])
            if base in self.objs:
                params = self.objs[base]["params"]
                algo = self.objs[base]["algo"] if self.objs[base]["algo"] != "RSA/ECC" else algo
                if self.objs[base].get("finding") is not None:
                    extra["key_finding"] = self.objs[base]["finding"].fid
            if "OAEP" in q:
                extra["padding"] = "OAEP"
        asset = {"hsm": "hsm", "kms": "cloud-kms", "tls": "protocol"}.get(obj or "", "algorithm")
        if algo == "TLS":
            asset = "protocol"
        if op in ("keyload",):
            asset = "key"
        srcs = set()
        if op in ("encrypt", "sign", "mac", "hash", "kdf"):
            data_arg = None
            if q == "hmac.new":
                data_arg = self._kw(n, "msg", 1)
            elif q == "jwt.encode" or prim == "hash" or q == "hashlib.pbkdf2_hmac":
                data_arg = self._kw(n, "payload", 0) if q == "jwt.encode" else (n.args[0] if n.args else None)
                if q == "hashlib.pbkdf2_hmac":
                    data_arg = self._kw(n, "password", 1)
            if data_arg is not None:
                srcs = self.sources_of(data_arg)
        else:
            data_arg = None
        f = self.add(algo, params, op if op != "keyload" else "keygen", prim, n, asset=asset, sources=srcs, extra=extra,
                     data_node=data_arg)
        if obj in ("asymcipher", "signer"):
            f.extra["init_only"] = True
        if obj:
            n._crypto_obj = {"algo": algo, "params": params, "kind": obj, "finding": f,
                            "aead": q.endswith(("AESGCM", "ChaCha20Poly1305"))}
        return True

    def _keysize(self, arg):
        if isinstance(arg, ast.Name) and arg.id in self.sizes:
            return str(self.sizes[arg.id] * 8)
        if isinstance(arg, ast.Constant) and isinstance(arg.value, bytes):
            return str(len(arg.value) * 8)
        if isinstance(arg, ast.Call) and self.qual(_dotted(arg.func)) in ("os.urandom", "secrets.token_bytes") and arg.args:
            v = _const(arg.args[0])
            if isinstance(v, int):
                return str(v * 8)
        if isinstance(arg, ast.Call) and (_dotted(arg.func) or "").endswith("generate_key"):
            bl = self._kw(arg, "bit_length", 0)
            if bl is not None and isinstance(_const(bl), int):
                return str(_const(bl))
        return ""

    def _object_call(self, n):
        if not isinstance(n.func, ast.Attribute):
            return
        meth = n.func.attr
        if meth not in OBJ_METHODS or OBJ_METHODS[meth] is None:
            return
        chained = None
        if isinstance(n.func.value, ast.Call):
            self.visit(n.func.value)  # e.g. AESGCM(key).encrypt(...): type the inner object first
            chained = getattr(n.func.value, "_crypto_obj", None)
        base, chain = _base_obj(n.func)
        dotted_base = None
        # support self.key.encrypt(...)
        if isinstance(n.func.value, ast.Attribute):
            dotted_base = _dotted(n.func.value)
        info = chained
        for cand in ((dotted_base, base) if info is None else ()):
            if cand and cand in self.objs:
                info = self.objs[cand]
                break
        if not info and meth in ("sign", "verify", "encrypt", "decrypt"):
            # the padding / signature-scheme argument reveals the algorithm even when the key's origin is unknown
            for a in list(n.args) + [k.value for k in n.keywords]:
                if isinstance(a, ast.Call):
                    qa = self.qual(_dotted(a.func) or "")
                    if qa.startswith(CRYPTO + ".asymmetric.padding.") and qa.split(".")[-1] in ("PKCS1v15", "PSS", "OAEP"):
                        info = {"algo": "RSA", "params": qa.split(".")[-1], "kind": "asym", "finding": None, "typed_by": "padding argument"}
                    elif qa == CRYPTO + ".asymmetric.ec.ECDSA":
                        info = {"algo": "ECDSA", "params": "", "kind": "asym", "finding": None, "typed_by": "ECDSA argument"}
            if info and isinstance(a, ast.Call):
                pass
        if not info:
            return False
        if meth == "update" and info["kind"] != "sym":
            return False
        op = OBJ_METHODS[meth]
        algo, params = info["algo"], info["params"]
        extra = {"via_object": dotted_base or base}
        if info.get("typed_by"):
            extra["typed_by"] = info["typed_by"]
        if info.get("finding") is not None:
            extra["key_finding"] = info["finding"].fid
        if info["kind"] == "kms":
            alg_kw = self._kw(n, "EncryptionAlgorithm") or self._kw(n, "SigningAlgorithm") or self._kw(n, "KeySpec")
            v = _const(alg_kw) if alg_kw is not None else None
            if isinstance(v, str):
                fam = next((f for k, f in KMS_ALG_HINT.items() if v.upper().startswith(k)), v)
                algo, params = fam, v
            else:
                algo, params = "KMS key (spec not in code)", ""
            asset = "cloud-kms"
        elif info["kind"] == "sym":
            asset = "algorithm"
        else:
            asset = "algorithm"
        if meth in ("sign",) and info["kind"] == "asym" and algo == "RSA":
            pass
        data_arg = n.args[0] if n.args else None
        if info.get("aead") and len(n.args) >= 2:
            data_arg = n.args[1]
        if info["kind"] == "kms":
            data_arg = self._kw(n, "Plaintext") or self._kw(n, "Message") or self._kw(n, "plaintext") or data_arg
        srcs = self.sources_of(data_arg) if data_arg is not None and op in ("encrypt", "sign", "kex") else set()
        if info["kind"] == "sym" and info.get("finding") is not None:
            f0 = info["finding"]
            f0.extra["sources"] = sorted(set(f0.extra.get("sources", [])) | srcs)
            if srcs and self.func:
                for i, p in enumerate(self.params):
                    if p in srcs:
                        idx = self.findings.index(f0)
                        self.summaries.setdefault(self.func, {}).setdefault(i, []).append(idx)
            return True
        prim = {"encrypt": "pke", "decrypt": "pke", "sign": "signature", "verify": "signature", "kex": "key-agree"}.get(op, "other")
        if info["kind"] == "sym":
            prim = "block-cipher"
        self.add(algo, params, op, prim, n, asset=asset, sources=srcs, extra=extra, data_node=data_arg)
        return True


def scan_python(path: str, source: str):
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return [], {}, [], set()
    a = _FileAnalyzer(path, source)
    for node in ast.walk(tree):   # type aliases such as AllowedEdDSAKeys = Ed25519PrivateKey | Ed448PrivateKey
        tgt = node.targets[0] if isinstance(node, ast.Assign) and len(node.targets) == 1 else (
            node.target if isinstance(node, ast.AnnAssign) else None)
        if isinstance(tgt, ast.Name) and getattr(node, "value", None) is not None:
            try:
                txt = ast.unparse(node.value)
            except Exception:
                continue
            if "PrivateKey" in txt or "PublicKey" in txt:
                a.type_aliases[tgt.id] = txt
    a.visit(tree)
    # a generated hybrid shim: classical parts are components of a hybrid scheme
    hybrid = None
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "PQC_HYBRID" for t in node.targets):
            hybrid = _const(node.value)
    if hybrid:
        for f in a.findings:
            if f.algorithm == "X25519":
                f.algorithm, f.params = "X25519MLKEM", "hybrid component"
                f.extra["hybrid"] = hybrid
            elif f.algorithm == "AES" and "GCM" in f.params and not f.params.startswith(("128", "192", "256")):
                f.params = "256-GCM"
                f.extra["note"] = "key from HKDF(length=32)"
    return a.findings, a.summaries, a.callsites, a.routes
