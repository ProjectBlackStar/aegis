"""Keystores: PKCS#12 (.p12/.pfx) and Java KeyStore (JKS / JCEKS).

PKCS#12 is opened with an empty password when possible; JKS certificate chains are stored unencrypted,
so they are read directly (only the private keys inside stay sealed)."""
from __future__ import annotations

import struct
from ..model import Finding
from .certs import _key_desc, cert_facts, attach_chain_cost

try:
    from cryptography import x509
    from cryptography.hazmat.primitives.serialization import pkcs12
except Exception:  # pragma: no cover
    x509 = None

JKS_MAGIC = b"\xfe\xed\xfe\xed"
JCEKS_MAGIC = b"\xce\xce\xce\xce"


def is_keystore(name: str, head: bytes) -> bool:
    n = name.lower()
    return n.endswith((".p12", ".pfx", ".jks", ".keystore", ".jceks", ".truststore")) or head[:4] in (JKS_MAGIC, JCEKS_MAGIC)


def _cert_finding(path, c, alias, store):
    import datetime
    algo, size, prim = _key_desc(c.public_key())
    sh = c.signature_hash_algorithm.name.upper() if c.signature_hash_algorithm else "?"
    sh = {"SHA1": "SHA-1", "SHA256": "SHA-256", "SHA384": "SHA-384", "SHA512": "SHA-512"}.get(sh, sh)
    nva = c.not_valid_after_utc
    expired = nva < datetime.datetime.now(datetime.timezone.utc)
    f = Finding(asset_type="certificate", algorithm=algo, params=size, operation="sign", primitive=prim, location=path, line=1,
                detector="keystore", evidence=f"{store} entry '{alias}': {c.subject.rfc4514_string()}; signed with {sh}; valid until {nva.date()}",
                confidence=0.99, language=store.lower())
    f.extra.update(cert_facts(c))
    f.extra.update({"subject": c.subject.rfc4514_string(), "issuer": c.issuer.rfc4514_string(), "not_after": nva.isoformat(),
                    "signature_hash": sh, "expired": expired, "alias": alias})
    return f


def _read_jks(data):
    """Minimal JKS reader (format: magic, version, count, entries). Returns [(alias, kind, [der certs])]."""
    pos = 4
    version, count = struct.unpack(">II", data[pos:pos + 8])
    pos += 8
    out = []

    def utf():
        nonlocal pos
        n = struct.unpack(">H", data[pos:pos + 2])[0]
        pos += 2
        s = data[pos:pos + n].decode("utf-8", "replace")
        pos += n
        return s

    def cert():
        nonlocal pos
        if version == 2:
            utf()  # cert type, e.g. X.509
        n = struct.unpack(">I", data[pos:pos + 4])[0]
        pos += 4
        der = data[pos:pos + n]
        pos += n
        return der

    for _ in range(min(count, 5000)):
        tag = struct.unpack(">I", data[pos:pos + 4])[0]
        pos += 4
        alias = utf()
        pos += 8  # timestamp
        if tag == 1:  # private key entry: encrypted key, then chain in clear
            n = struct.unpack(">I", data[pos:pos + 4])[0]
            pos += 4 + n
            k = struct.unpack(">I", data[pos:pos + 4])[0]
            pos += 4
            out.append((alias, "private-key", [cert() for _ in range(k)]))
        elif tag == 2:
            out.append((alias, "trusted-cert", [cert()]))
        else:
            break
    return out


def scan_keystore(path: str, data: bytes):
    out = []
    if x509 is None:
        return out
    if data[:4] == JKS_MAGIC:
        try:
            entries = _read_jks(data)
        except Exception as e:
            entries = []
            out.append(Finding(asset_type="key", algorithm="encrypted keystore", params="JKS", operation="store", primitive="other",
                               location=path, line=1, detector="keystore", evidence=f"JKS keystore could not be read ({type(e).__name__})",
                               confidence=0.6, language="jks"))
        for alias, kind, ders in entries:
            for i, der in enumerate(ders):
                try:
                    f = _cert_finding(path, x509.load_der_x509_certificate(der), alias + (f" [{i}]" if i else ""), "JKS")
                    if kind == "private-key" and i == 0:
                        f.extra["has_private_key"] = True
                        f.evidence += " (private key present, sealed)"
                    out.append(f)
                except Exception:
                    continue
        return attach_chain_cost(out)
    if data[:4] == JCEKS_MAGIC:
        return [Finding(asset_type="key", algorithm="encrypted keystore", params="JCEKS", operation="store", primitive="other",
                        location=path, line=1, detector="keystore", evidence="JCEKS keystore (contents need the store password)",
                        confidence=0.7, language="jceks", extra={"note": "JCEKS keystore: open with its password to inventory the keys"})]
    for pw in (None, b"", b"changeit", b"password"):
        try:
            key, cert, extra = pkcs12.load_key_and_certificates(data, pw)
        except Exception:
            continue
        if key is not None:
            algo, size, prim = _key_desc(key)
            kf = Finding(asset_type="key", algorithm=algo, params=size, operation="keygen", primitive=prim, location=path, line=1,
                         detector="keystore", evidence=f"PKCS#12 private key ({'no password' if not pw else 'default password ' + pw.decode()})",
                         confidence=0.99, language="pkcs12")
            kf.extra["unprotected_private_key"] = True
            kf.extra["weak_store_password"] = pw.decode() if pw else "(none)"
            out.append(kf)
        for i, c in enumerate([cert] + list(extra or [])):
            if c is not None:
                out.append(_cert_finding(path, c, f"cert {i}", "PKCS12"))
        return attach_chain_cost(out)
    return [Finding(asset_type="key", algorithm="encrypted keystore", params="PKCS#12", operation="store", primitive="other",
                    location=path, line=1, detector="keystore", evidence="password-protected PKCS#12 keystore",
                    confidence=0.7, language="pkcs12", extra={"note": "Password-protected PKCS#12: open it with its password to inventory the keys"})]
