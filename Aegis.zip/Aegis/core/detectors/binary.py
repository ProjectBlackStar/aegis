"""Binary detector: ELF linked libraries + imported crypto symbols + byte signatures
of crypto constants + embedded library version strings. Language independent."""
from __future__ import annotations

import io
import re
import struct
from ..model import Finding
from .lexer import C_SYMBOLS

try:
    from elftools.elf.elffile import ELFFile
    from elftools.elf.dynamic import DynamicSection
    from elftools.elf.sections import SymbolTableSection
except Exception:  # pragma: no cover
    ELFFile = None

CRYPTO_LIBS = {"libcrypto": "OpenSSL libcrypto", "libssl": "OpenSSL libssl", "libgcrypt": "libgcrypt",
               "libmbedcrypto": "mbedTLS", "libmbedtls": "mbedTLS", "libwolfssl": "wolfSSL", "libgnutls": "GnuTLS",
               "libnss3": "NSS", "libsodium": "libsodium", "libbcrypt": "Windows CNG"}

SIGNATURES = [
    ("AES", "", "encrypt", "block-cipher", bytes.fromhex("637c777bf26b6fc53001672bfed7ab76"), "AES S-box"),
    ("SHA-256", "", "hash", "hash", struct.pack("<4I", 0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5), "SHA-256 round constants"),
    ("SHA-1", "", "hash", "hash", struct.pack("<4I", 0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xca62c1d6), "SHA-1 round constants"),
    ("MD5", "", "hash", "hash", struct.pack("<4I", 0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee), "MD5 sine table"),
    ("DES", "", "encrypt", "block-cipher", bytes([14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7]), "DES S-box 1"),
]
VERSION_RX = [
    (re.compile(rb"OpenSSL (\d+\.\d+\.\d+[a-z]?)"), "OpenSSL"),
    (re.compile(rb"mbed TLS (\d+\.\d+\.\d+)"), "mbedTLS"),
    (re.compile(rb"wolfSSL (\d+\.\d+\.\d+)"), "wolfSSL"),
]


def is_binary(head: bytes) -> bool:
    return head.startswith(b"\x7fELF") or head[:2] == b"MZ" or head[:4] in (b"\xcf\xfa\xed\xfe", b"\xfe\xed\xfa\xcf")


def _mk(path, algo, params, op, prim, evidence, asset="algorithm", conf=0.8, line=0):
    return Finding(asset_type=asset, algorithm=algo, params=params, operation=op, primitive=prim, location=path,
                   line=line, detector="binary", evidence=evidence, confidence=conf, language="binary")


def scan_binary(path: str, data: bytes):
    out = []
    seen = set()
    if data.startswith(b"\x7fELF") and ELFFile is not None:
        try:
            elf = ELFFile(io.BytesIO(data))
            for sec in elf.iter_sections():
                if isinstance(sec, DynamicSection):
                    for tag in sec.iter_tags():
                        if tag.entry.d_tag == "DT_NEEDED":
                            lib = tag.needed
                            for k, v in CRYPTO_LIBS.items():
                                if lib.startswith(k) and ("lib", v) not in seen:
                                    seen.add(("lib", v))
                                    out.append(_mk(path, v, lib, "link", "other", f"dynamically links {lib}", asset="library", conf=0.95))
                if isinstance(sec, SymbolTableSection):
                    for sym in sec.iter_symbols():
                        nm = sym.name
                        if nm in C_SYMBOLS and ("sym", nm) not in seen:
                            seen.add(("sym", nm))
                            algo, op = C_SYMBOLS[nm]
                            params = ""
                            if ":" in op:
                                op, params = op.split(":")
                            prim = {"keygen": "pke", "encrypt": "block-cipher" if algo in ("AES", "DES", "3DES", "RC4") else "pke",
                                    "decrypt": "pke", "sign": "signature", "kex": "key-agree", "hash": "hash", "link": "other"}[op]
                            out.append(_mk(path, algo, params, op, prim, f"imports symbol {nm}", conf=0.9))
        except Exception as e:  # malformed ELF
            out.append(_mk(path, "unparsed-binary", "", "link", "other", f"ELF parse error: {e}", asset="library", conf=0.3))
    for algo, params, op, prim, sig, label in SIGNATURES:
        if sig in data and ("sig", algo) not in seen:
            seen.add(("sig", algo))
            out.append(_mk(path, algo, params, op, prim, f"embedded {label} found at offset {data.find(sig)}", conf=0.7))
    for rx, lib in VERSION_RX:
        m = rx.search(data)
        if m:
            out.append(_mk(path, lib, m.group(1).decode(), "link", "other", f"embedded version string '{m.group(0).decode()}'",
                           asset="library", conf=0.85))
    return out
