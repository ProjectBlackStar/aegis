"""Comment-aware lexer detector for Java, JavaScript/TypeScript, C/C++ and Go.

Comments are dropped; string literals are kept as tokens but only count when
they are the argument of a known crypto API. So "RSA" in a log message, or a
crypto call written inside a comment or string, never produces a finding.
"""
from __future__ import annotations

import re
from ..model import Finding

_BODY = r"\"(?:\\.|[^\"\\\n])*\"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`|[A-Za-z_]\w*|\d+|\S"
TOKEN = re.compile(r"//[^\n]*|/\*.*?\*/|" + _BODY, re.S)
TOKEN_C = re.compile(r"//[^\n]*|/\*.*?\*/|#[^\n]*|" + _BODY, re.S)


def tokenize(src: str, lang: str):
    out = []
    rx = TOKEN_C if lang == "c" else TOKEN
    line, last = 1, 0
    for m in rx.finditer(src):
        t = m.group()
        line += src.count("\n", last, m.start())
        last = m.start()
        if t.startswith("//") or t.startswith("/*"):
            continue
        out.append((t, line))
    return out


def _str(tok):
    if tok and tok[0] in "\"'`" and len(tok) >= 2:
        return tok[1:-1]
    return None


def _parse_jca(transform: str):
    """'AES/ECB/PKCS5Padding' -> ('AES','ECB'); 'SHA256withRSA' -> ('RSA','SHA-256')."""
    t = transform.strip()
    up = t.upper()
    if "WITH" in up:
        h, _, a = up.partition("WITH")
        a = {"ECDSA": "ECDSA", "RSA": "RSA", "DSA": "DSA", "RSA/PSS": "RSA"}.get(a, a)
        return a, h.replace("SHA", "SHA-").replace("--", "-")
    parts = t.split("/")
    algo = parts[0].upper()
    algo = {"DESEDE": "3DES", "TRIPLEDES": "3DES", "SHA1": "SHA-1", "SHA-1": "SHA-1", "SHA256": "SHA-256", "SHA-256": "SHA-256",
            "SHA-512": "SHA-512", "MD5": "MD5", "EC": "ECDSA", "ARCFOUR": "RC4"}.get(algo, algo)
    mode = parts[1].upper() if len(parts) > 1 else ""
    if algo == "AES" and not mode:
        mode = "ECB"  # JCA default for "AES" is ECB
    return algo, mode


def _node_cipher(name: str):
    """'aes-128-cbc' -> ('AES','128-CBC'); 'des-ede3' -> ('3DES','')."""
    n = name.lower()
    m = re.match(r"aes-?(\d+)-?(\w+)?", n)
    if m:
        return "AES", "-".join(x for x in (m.group(1), (m.group(2) or "").upper()) if x)
    if n.startswith("des-ede3") or n.startswith("des3"):
        return "3DES", ""
    if n.startswith("des"):
        return "DES", n.split("-")[-1].upper() if "-" in n else ""
    if n.startswith("rc4"):
        return "RC4", ""
    if n.startswith("chacha20"):
        return "ChaCha20-Poly1305", ""
    return n.upper(), ""


HASHES = {"md5": "MD5", "sha1": "SHA-1", "sha-1": "SHA-1", "sha256": "SHA-256", "sha-256": "SHA-256",
          "sha512": "SHA-512", "sha384": "SHA-384", "rsa-sha256": "SHA-256", "rsa-sha1": "SHA-1"}

C_SYMBOLS = {
    "RSA_generate_key_ex": ("RSA", "keygen"), "RSA_generate_key": ("RSA", "keygen"), "RSA_public_encrypt": ("RSA", "encrypt"),
    "RSA_private_decrypt": ("RSA", "decrypt"), "RSA_sign": ("RSA", "sign"), "EVP_PKEY_RSA": ("RSA", "keygen"),
    "EVP_PKEY_CTX_set_rsa_keygen_bits": ("RSA", "keygen"), "EVP_PKEY_EC": ("ECDSA", "keygen"),
    "EC_KEY_generate_key": ("ECDSA", "keygen"), "ECDSA_sign": ("ECDSA", "sign"), "ECDH_compute_key": ("ECDH", "kex"),
    "DH_generate_key": ("DH", "kex"), "DSA_generate_key": ("DSA", "keygen"),
    "EVP_md5": ("MD5", "hash"), "MD5_Init": ("MD5", "hash"), "MD5": ("MD5", "hash"), "EVP_sha1": ("SHA-1", "hash"),
    "SHA1_Init": ("SHA-1", "hash"), "SHA1": ("SHA-1", "hash"), "EVP_sha256": ("SHA-256", "hash"),
    "EVP_aes_128_cbc": ("AES", "encrypt:128-CBC"), "EVP_aes_128_ecb": ("AES", "encrypt:128-ECB"),
    "EVP_aes_256_gcm": ("AES", "encrypt:256-GCM"), "EVP_aes_256_cbc": ("AES", "encrypt:256-CBC"),
    "EVP_des_ecb": ("DES", "encrypt:ECB"), "EVP_des_ede3_cbc": ("3DES", "encrypt:CBC"), "EVP_rc4": ("RC4", "encrypt"),
    "mbedtls_rsa_gen_key": ("RSA", "keygen"), "mbedtls_ecdsa_sign": ("ECDSA", "sign"),
    "wc_MakeRsaKey": ("RSA", "keygen"), "C_Initialize": ("PKCS#11 HSM", "link"), "C_GenerateKeyPair": ("PKCS#11 HSM", "keygen"),
}

GO_PKGS = {"crypto/rsa": ("RSA", "pke"), "crypto/ecdsa": ("ECDSA", "signature"), "crypto/dsa": ("DSA", "signature"),
           "crypto/md5": ("MD5", "hash"), "crypto/sha1": ("SHA-1", "hash"), "crypto/des": ("DES", "block-cipher"),
           "crypto/rc4": ("RC4", "stream-cipher"), "crypto/ecdh": ("ECDH", "key-agree"), "crypto/ed25519": ("Ed25519", "signature"),
           "crypto/elliptic": ("ECDSA", "signature"), "crypto/tls": ("TLS", "protocol"), "crypto/mlkem": ("ML-KEM", "kem")}


GO_CALLS = {
    "sha1": {"Sum": ("SHA-1", "hash", "hash"), "New": ("SHA-1", "hash", "hash")},
    "md5": {"Sum": ("MD5", "hash", "hash"), "New": ("MD5", "hash", "hash")},
    "des": {"NewCipher": ("DES", "encrypt", "block-cipher"), "NewTripleDESCipher": ("3DES", "encrypt", "block-cipher")},
    "rc4": {"NewCipher": ("RC4", "encrypt", "stream-cipher")},
    "ecdsa": {"GenerateKey": ("ECDSA", "keygen", "signature"), "Sign": ("ECDSA", "sign", "signature"), "SignASN1": ("ECDSA", "sign", "signature")},
    "rsa": {"EncryptOAEP": ("RSA", "encrypt", "pke"), "EncryptPKCS1v15": ("RSA", "encrypt", "pke"),
            "SignPKCS1v15": ("RSA", "sign", "signature"), "SignPSS": ("RSA", "sign", "signature")},
    "ed25519": {"GenerateKey": ("Ed25519", "keygen", "signature"), "Sign": ("Ed25519", "sign", "signature")},
}


def _mk(path, line, lang, algo, params, op, prim, evidence, asset="algorithm", conf=0.9):
    return Finding(asset_type=asset, algorithm=algo, params=params, operation=op, primitive=prim, location=path,
                   line=line, detector=f"lexer-{lang}", evidence=evidence[:160], confidence=conf, language=lang)


def scan_lexer(path: str, src: str, lang: str):
    toks = tokenize(src, lang)
    lines = src.splitlines()
    ev = lambda ln: lines[ln - 1].strip() if 0 < ln <= len(lines) else ""
    out = []
    T = [t for t, _ in toks]
    n = len(T)
    for i in range(n):
        t, ln = toks[i]
        nxt = T[i + 1:i + 6]
        if lang == "java":
            # Class.getInstance("...")
            if t in ("Cipher", "KeyPairGenerator", "MessageDigest", "Signature", "KeyAgreement", "KeyGenerator", "Mac", "SSLContext") \
                    and nxt[:3] == [".", "getInstance", "("] and len(nxt) > 3:
                s = _str(nxt[3])
                if s is None:
                    continue
                if t == "SSLContext":
                    out.append(_mk(path, ln, lang, "TLS", s, "tls", "protocol", ev(ln), asset="protocol"))
                    continue
                algo, mode = _parse_jca(s)
                op = {"Cipher": "encrypt", "KeyPairGenerator": "keygen", "MessageDigest": "hash", "Signature": "sign",
                      "KeyAgreement": "kex", "KeyGenerator": "keygen", "Mac": "mac"}[t]
                prim = {"encrypt": "block-cipher" if algo in ("AES", "DES", "3DES") else "pke", "keygen": "pke", "hash": "hash",
                        "sign": "signature", "kex": "key-agree", "mac": "mac"}[op]
                params = mode
                if t == "Mac" and "SHA1" in s.upper():
                    algo, params = "SHA-1", "HMAC"
                # look ahead for initialize(2048)
                if t == "KeyPairGenerator":
                    for j in range(i, min(n - 3, i + 40)):
                        if T[j] == "initialize" and T[j + 1] == "(" and T[j + 2].isdigit():
                            params = T[j + 2]
                            break
                out.append(_mk(path, ln, lang, algo, params, op, prim, ev(ln)))
            if t == "import" and T[i + 1:i + 2] and T[i + 1] in ("org",) and "bouncycastle" in "".join(T[i + 1:i + 6]):
                out.append(_mk(path, ln, lang, "BouncyCastle", "", "link", "other", ev(ln), asset="library", conf=0.8))
        elif lang == "js":
            if t == "crypto" or t in ("require",):
                pass
            if nxt[:2] == [".", "createCipheriv"] or nxt[:2] == [".", "createDecipheriv"] or nxt[:2] == [".", "createCipher"]:
                if len(nxt) > 3 and nxt[2] == "(":
                    s = _str(nxt[3])
                    if s:
                        algo, params = _node_cipher(s)
                        out.append(_mk(path, ln, lang, algo, params, "encrypt", "block-cipher", ev(ln)))
            elif nxt[:2] == [".", "createHash"] or nxt[:2] == [".", "createHmac"]:
                if len(nxt) > 3 and nxt[2] == "(":
                    s = _str(nxt[3])
                    if s:
                        algo = HASHES.get(s.lower(), s.upper())
                        op = "mac" if nxt[1] == "createHmac" else "hash"
                        out.append(_mk(path, ln, lang, algo, "HMAC" if op == "mac" else "", op, "mac" if op == "mac" else "hash", ev(ln)))
            elif nxt[:2] == [".", "createSign"] or nxt[:2] == [".", "createVerify"]:
                if len(nxt) > 3 and nxt[2] == "(":
                    s = _str(nxt[3])
                    if s is None:
                        continue
                    algo = "ECDSA" if "ecdsa" in s.lower() else "RSA"
                    h = HASHES.get(s.lower(), s.upper())
                    out.append(_mk(path, ln, lang, algo, f"sign {h}", "sign", "signature", ev(ln)))
            elif nxt[:2] == [".", "generateKeyPairSync"] or nxt[:2] == [".", "generateKeyPair"]:
                if len(nxt) > 3 and nxt[2] == "(" and _str(nxt[3]) is not None:
                    s = (_str(nxt[3]) or "").lower()
                    algo = {"rsa": "RSA", "ec": "ECDSA", "ed25519": "Ed25519", "x25519": "X25519", "dsa": "DSA"}.get(s, s.upper())
                    params = ""
                    for j in range(i, min(n - 2, i + 30)):
                        if T[j] == "modulusLength" and T[j + 1] == ":" and T[j + 2].isdigit():
                            params = T[j + 2]
                        if T[j] == "namedCurve" and T[j + 1] == ":":
                            params = _str(T[j + 2]) or params
                    out.append(_mk(path, ln, lang, algo, params, "keygen", "pke", ev(ln)))
            elif t == "forge" and nxt[:4] == [".", "pki", ".", "rsa"]:
                bits = ""
                for j in range(i, min(n - 2, i + 20)):
                    if T[j] == "bits" and T[j + 1] == ":" and T[j + 2].isdigit():
                        bits = T[j + 2]
                out.append(_mk(path, ln, lang, "RSA", bits, "keygen", "pke", ev(ln) + " (node-forge)", conf=0.85))
        elif lang == "c":
            if t in C_SYMBOLS and (T[i + 1:i + 2] == ["("] or t.startswith("EVP_PKEY_") or t in ("EVP_PKEY_RSA", "EVP_PKEY_EC")):
                algo, op = C_SYMBOLS[t]
                params = ""
                if ":" in op:
                    op, params = op.split(":")
                if t in ("RSA_generate_key_ex", "EVP_PKEY_CTX_set_rsa_keygen_bits"):
                    for j in range(i, min(n, i + 12)):
                        if T[j].isdigit() and int(T[j]) >= 512:
                            params = T[j]
                            break
                asset = "hsm" if "PKCS#11" in algo else "algorithm"
                prim = {"keygen": "pke", "encrypt": "block-cipher" if algo in ("AES", "DES", "3DES", "RC4") else "pke",
                        "decrypt": "pke", "sign": "signature", "kex": "key-agree", "hash": "hash", "link": "other"}[op]
                out.append(_mk(path, ln, lang, algo, params, op, prim, ev(ln), asset=asset))
            if t.startswith("#") and "include" in t:
                inc = re.search(r"[<\"]([^>\"]+)[>\"]", t)
                if inc and inc.group(1).startswith(("openssl/", "mbedtls/", "wolfssl/", "pkcs11")):
                    out.append(_mk(path, ln, lang, inc.group(1).split("/")[0], inc.group(1), "link", "other", ev(ln), asset="library", conf=0.7))
        elif lang == "go":
            s = _str(t)
            if s in GO_PKGS and ln:
                algo, prim = GO_PKGS[s]
                # only in import position: previous token is 'import' or '(' block or alias
                back = T[max(0, i - 3):i]
                if "import" in back or "(" in back or (back and back[-1].isidentifier()):
                    out.append(_mk(path, ln, lang, "Go " + s, "", "link", "other", ev(ln), asset="library", conf=0.85))
            if t in GO_CALLS and len(nxt) >= 3 and nxt[0] == "." and nxt[1] in GO_CALLS[t] and nxt[2] == "(":
                algo, op, prim = GO_CALLS[t][nxt[1]]
                out.append(_mk(path, ln, lang, algo, "", op, prim, ev(ln)))
            if t == "rsa" and nxt[:2] == [".", "GenerateKey"]:
                params = next((x for x in T[i + 3:i + 12] if x.isdigit() and int(x) >= 512), "")
                out.append(_mk(path, ln, lang, "RSA", params, "keygen", "pke", ev(ln)))
    # OpenSSL: EVP_PKEY_RSA context creation and the keygen-bits call describe ONE key generation
    sized = [f for f in out if f.algorithm == "RSA" and f.operation == "keygen" and f.params]
    out = [f for f in out if not (f.algorithm == "RSA" and f.operation == "keygen" and not f.params
                                  and any(0 < g.line - f.line <= 12 for g in sized))]
    # de-duplicate identical detections on the same line, and library links per file
    seen, uniq = set(), []
    for f in out:
        k = (f.line, f.algorithm, f.params, f.operation) if f.asset_type != "library" else (f.algorithm,)
        if k not in seen:
            seen.add(k)
            uniq.append(f)
    return uniq
