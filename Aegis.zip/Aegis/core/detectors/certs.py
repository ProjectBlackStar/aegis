"""Certificates and key files: PEM / DER / PKCS#12 / OpenSSH."""
from __future__ import annotations

import datetime
import re
from ..model import Finding

try:
    from cryptography import x509
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa, ec, dsa, ed25519, ed448
except Exception:  # pragma: no cover
    x509 = None

PEM_BLOCK = re.compile(rb"-----BEGIN ([A-Z0-9 ]+)-----.*?-----END \1-----", re.S)


def _key_desc(k):
    if isinstance(k, rsa.RSAPublicKey) or isinstance(k, rsa.RSAPrivateKey):
        return "RSA", str(k.key_size), "pke"
    if isinstance(k, (ec.EllipticCurvePublicKey, ec.EllipticCurvePrivateKey)):
        return "ECDSA", {"secp256r1": "P-256", "secp384r1": "P-384", "secp521r1": "P-521"}.get(k.curve.name, k.curve.name), "signature"
    if isinstance(k, (dsa.DSAPublicKey, dsa.DSAPrivateKey)):
        return "DSA", str(k.key_size), "signature"
    if isinstance(k, (ed25519.Ed25519PublicKey, ed25519.Ed25519PrivateKey)):
        return "Ed25519", "", "signature"
    if isinstance(k, (ed448.Ed448PublicKey, ed448.Ed448PrivateKey)):
        return "Ed448", "", "signature"
    return type(k).__name__, "", "other"


def cert_facts(c):
    """Sizes and roles used by the TLS cost model and by Mosca for certificates."""
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    der = c.public_bytes(Encoding.DER)
    spki = c.public_key().public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo)
    try:
        bc = c.extensions.get_extension_for_class(x509.BasicConstraints).value
        is_ca = bool(bc.ca)
    except Exception:
        is_ca = False
    ku = []
    try:
        k = c.extensions.get_extension_for_class(x509.KeyUsage).value
        for name in ("digital_signature", "key_encipherment", "key_agreement", "key_cert_sign"):
            if getattr(k, name, False):
                ku.append(name)
    except Exception:
        pass
    leaf_sig = None
    pk = c.public_key()
    if isinstance(pk, rsa.RSAPublicKey):
        leaf_sig = pk.key_size // 8
    elif isinstance(pk, ec.EllipticCurvePublicKey):
        leaf_sig = 2 * ((pk.curve.key_size + 7) // 8) + 8
    elif isinstance(pk, ed25519.Ed25519PublicKey):
        leaf_sig = 64
    return {"der_len": len(der), "spki_len": len(spki), "sig_len": len(c.signature), "is_ca": is_ca,
            "key_usage_ext": ku, "leaf_sig_len": leaf_sig}


def attach_chain_cost(findings):
    certs = [f for f in findings if f.asset_type == "certificate" and f.extra.get("der_len")]
    if not certs:
        return findings
    from ..tlscost import chain_cost
    leaf = next((f for f in certs if not f.extra.get("is_ca")), certs[0])
    chain = [leaf] + [f for f in certs if f is not leaf]
    leaf.extra["tls_cost"] = chain_cost([{"der_len": f.extra["der_len"], "spki_len": f.extra["spki_len"],
                                          "sig_len": f.extra["sig_len"], "leaf_sig_len": f.extra.get("leaf_sig_len")} for f in chain])
    return findings


def looks_like_keymaterial(name: str, head: bytes) -> bool:
    n = name.lower()
    return b"-----BEGIN" in head or n.endswith((".pem", ".crt", ".cer", ".der", ".key", ".p12", ".pfx", ".pub")) \
        or n.startswith(("id_rsa", "id_ecdsa", "id_ed25519", "ssh_host_"))


def scan_certs(path: str, data: bytes):
    out = []
    if x509 is None:
        return out
    now = datetime.datetime.now(datetime.timezone.utc)
    blocks = [m for m in PEM_BLOCK.finditer(data)]
    items = [(m.group(1).decode(), m.group(0), data.count(b"\n", 0, m.start()) + 1) for m in blocks]
    if not items and data[:1] == b"\x30":
        items = [("DER", data, 1)]
    for kind, blob, line in items:
        try:
            if kind in ("CERTIFICATE", "DER"):
                c = x509.load_pem_x509_certificate(blob) if kind != "DER" else x509.load_der_x509_certificate(blob)
                algo, size, prim = _key_desc(c.public_key())
                sig_hash = c.signature_hash_algorithm.name.upper() if c.signature_hash_algorithm else "?"
                sig_hash = {"SHA1": "SHA-1", "SHA256": "SHA-256", "SHA384": "SHA-384", "SHA512": "SHA-512"}.get(sig_hash, sig_hash)
                nva = c.not_valid_after_utc if hasattr(c, "not_valid_after_utc") else c.not_valid_after.replace(tzinfo=datetime.timezone.utc)
                expired = nva < now
                cn = c.subject.rfc4514_string()
                f = Finding(asset_type="certificate", algorithm=algo, params=size, operation="sign", primitive=prim,
                            location=path, line=line, detector="cert",
                            evidence=f"X.509 {cn}; signed with {sig_hash}; valid until {nva.date()}{' (EXPIRED)' if expired else ''}",
                            confidence=0.99, language="x509")
                f.extra.update(cert_facts(c))
                f.extra.update({"subject": cn, "issuer": c.issuer.rfc4514_string(), "not_after": nva.isoformat(),
                                "signature_hash": sig_hash, "expired": expired, "serial": str(c.serial_number)})
                out.append(f)
            elif "PRIVATE KEY" in kind or "PUBLIC KEY" in kind:
                if "OPENSSH" in kind:
                    k = serialization.load_ssh_private_key(blob, password=None)
                elif "PRIVATE" in kind:
                    k = serialization.load_pem_private_key(blob, password=None)
                else:
                    k = serialization.load_pem_public_key(blob)
                algo, size, prim = _key_desc(k)
                f = Finding(asset_type="key", algorithm=algo, params=size, operation="keygen", primitive=prim,
                            location=path, line=line, detector="cert",
                            evidence=f"{'unencrypted private' if 'PRIVATE' in kind else 'public'} key file ({kind.title()})",
                            confidence=0.99, language="pem")
                if "PRIVATE" in kind:
                    f.extra["unprotected_private_key"] = True
                out.append(f)
        except Exception as e:
            out.append(Finding(asset_type="key", algorithm="unparsed key material", params=kind, operation="store",
                               primitive="other", location=path, line=line, detector="cert",
                               evidence=f"could not parse ({type(e).__name__}); possibly encrypted", confidence=0.5, language="pem"))
    if not items and data.startswith((b"ssh-rsa ", b"ssh-ed25519 ", b"ecdsa-sha2-")):
        algo = {"ssh-rsa": "RSA", "ssh-ed25519": "Ed25519"}.get(data.split(b" ")[0].decode(), "ECDSA")
        out.append(Finding(asset_type="key", algorithm=algo, params="ssh", operation="keygen", primitive="signature",
                           location=path, line=1, detector="cert", evidence="OpenSSH public key", confidence=0.95, language="ssh"))
    return attach_chain_cost(out)
