"""Dependency manifests: crypto libraries, their versions, and the published advisories that affect them.

Advisories come from a bundled snapshot of the GitHub Advisory Database (data/advisories.json,
built by tools/build_advisories.py), so matching works offline."""
from __future__ import annotations

import json


def _read_json(path, **kw):
    with open(path, **kw) as fh:
        return json.load(fh)
import os
import re
from ..model import Finding

PROVIDES = {
    "cryptography": "RSA/ECC/AES (pyca)", "pycryptodome": "RSA/ECC/AES/DES", "pycryptodomex": "RSA/ECC/AES/DES",
    "pycrypto": "RSA/AES/DES (unmaintained since 2013)", "pyjwt": "JWT RS256/ES256/HS256", "python-jose": "JWT / JOSE",
    "paramiko": "SSH RSA/ECDSA", "pyopenssl": "OpenSSL binding", "rsa": "pure-Python RSA", "ecdsa": "pure-Python ECDSA",
    "pynacl": "X25519/Ed25519", "m2crypto": "OpenSSL binding", "authlib": "OAuth / JOSE", "jwcrypto": "JOSE", "asyncssh": "SSH",
    "twisted": "TLS / SSH", "certifi": "CA bundle", "oscrypto": "TLS / crypto", "liboqs-python": "post-quantum (liboqs)",
    "node-forge": "RSA/AES/TLS (JS)", "jsonwebtoken": "JWT (JS)", "elliptic": "ECDSA (JS)", "crypto-js": "AES/MD5/SHA-1 (JS)",
    "jose": "JOSE (JS)", "node-rsa": "RSA (JS)", "sshpk": "SSH keys (JS)", "tweetnacl": "X25519/Ed25519 (JS)",
    "jsrsasign": "RSA/ECDSA (JS)", "browserify-sign": "RSA/ECDSA (JS)", "secp256k1": "ECDSA secp256k1 (JS)", "openpgp": "OpenPGP (JS)",
    "ssh2": "SSH (JS)", "jws": "JWS (JS)", "jwa": "JWA (JS)", "node-jose": "JOSE (JS)",
    "org.bouncycastle:bcprov-jdk15on": "BouncyCastle (Java)", "org.bouncycastle:bcprov-jdk18on": "BouncyCastle (Java)",
    "org.bouncycastle:bcprov-jdk14": "BouncyCastle (Java)", "org.bouncycastle:bcpkix-jdk15on": "BouncyCastle PKIX (Java)",
    "org.bouncycastle:bcpkix-jdk18on": "BouncyCastle PKIX (Java)", "org.bouncycastle:bc-fips": "BouncyCastle FIPS (Java)",
    "com.nimbusds:nimbus-jose-jwt": "JOSE / JWT (Java)", "io.jsonwebtoken:jjwt": "JWT (Java)", "io.jsonwebtoken:jjwt-impl": "JWT (Java)",
    "com.auth0:java-jwt": "JWT (Java)", "org.bitbucket.b_c:jose4j": "JOSE (Java)", "com.jcraft:jsch": "SSH (Java)",
    "org.apache.sshd:sshd-core": "SSH (Java)", "org.apache.santuario:xmlsec": "XML signatures (Java)",
    "golang.org/x/crypto": "Go extended crypto", "github.com/golang-jwt/jwt": "JWT (Go)", "github.com/golang-jwt/jwt/v4": "JWT (Go)",
    "github.com/golang-jwt/jwt/v5": "JWT (Go)", "github.com/dgrijalva/jwt-go": "JWT (Go, unmaintained)",
    "github.com/cloudflare/circl": "PQ / ECC (Go)", "github.com/go-jose/go-jose/v3": "JOSE (Go)", "github.com/go-jose/go-jose/v4": "JOSE (Go)",
    "openssl": "OpenSSL binding", "openssl-src": "bundled OpenSSL", "rustls": "TLS (Rust)", "ring": "crypto (Rust)",
    "ed25519-dalek": "Ed25519 (Rust)", "curve25519-dalek": "X25519 (Rust)", "jwt": "JWT (Ruby)", "net-ssh": "SSH (Ruby)",
    "bouncycastle": "BouncyCastle (.NET)", "portable.bouncycastle": "BouncyCastle (.NET)", "bouncycastle.cryptography": "BouncyCastle (.NET)",
    "system.identitymodel.tokens.jwt": "JWT (.NET)",
}
PQ_READY = {"liboqs-python", "github.com/cloudflare/circl", "org.bouncycastle:bcprov-jdk18on", "bouncycastle.cryptography"}
_ADV = None


def advisories():
    global _ADV
    if _ADV is None:
        try:
            d = _read_json(os.path.join(os.path.dirname(__file__), "..", "..", "data", "advisories.json"))
        except Exception:
            d = {"meta": {}, "advisories": []}
        idx = {}
        for a in d["advisories"]:
            idx.setdefault((a["ecosystem"], a["package"]), []).append(a)
        _ADV = (d["meta"], idx)
    return _ADV


def _nums(v):
    n = [int(x) for x in re.findall(r"\d+", v or "")[:4]]
    return tuple(n + [0] * (4 - len(n)))


def _lt(a, b):
    """Version a < b. PEP 440 when both parse, otherwise numeric parts (works for semver, Maven, Go)."""
    a, b = (a or "").strip().lstrip("v"), (b or "").strip().lstrip("v")
    try:
        from packaging.version import Version
        return Version(a) < Version(b)
    except Exception:
        return _nums(a) < _nums(b)


def affected(adv, version):
    if not version:
        return False
    if version in (adv.get("versions") or []):
        return True
    for r in adv.get("ranges", []):
        intro = r.get("introduced") or "0"
        if intro != "0" and _lt(version, intro):
            continue
        if r.get("fixed"):
            if _lt(version, r["fixed"]):
                return True
        elif r.get("last_affected"):
            if not _lt(r["last_affected"], version):
                return True
        else:
            return True
    return False


def match(ecosystem, package, version):
    meta, idx = advisories()
    allv = idx.get((ecosystem, package.lower()), [])
    hits = [a for a in allv if affected(a, version)]
    fixed = [r["fixed"] for a in hits for r in a["ranges"] if r.get("fixed")]
    upgrade = None
    for fv in fixed:
        if upgrade is None or _lt(upgrade, fv):
            upgrade = fv
    return hits, len(allv), upgrade


def is_manifest(name: str) -> bool:
    n = name.lower().rsplit("/", 1)[-1]
    return n in ("requirements.txt", "package.json", "pom.xml", "go.mod", "pipfile", "pyproject.toml", "cargo.toml",
                 "gemfile.lock", "build.gradle") or n.startswith("requirements") or n.endswith(".csproj")


def _entries(path, text):
    name = path.lower().rsplit("/", 1)[-1]
    ent = []
    ln = lambda pos: text.count("\n", 0, pos) + 1
    if name == "package.json":
        try:
            d = json.loads(text)
            for sec in ("dependencies", "devDependencies"):
                for k, v in (d.get(sec) or {}).items():
                    m = re.search(r"\d+(?:\.\d+)*", str(v))
                    pos = text.find(f'"{k}"')
                    ent.append(("npm", k, m.group(0) if m else "", ln(pos) if pos >= 0 else 1))
        except Exception:
            pass
    elif name == "pom.xml":
        for m in re.finditer(r"<dependency>(.*?)</dependency>", text, re.S):
            body = m.group(1)
            g = re.search(r"<groupId>\s*([^<]+?)\s*</groupId>", body)
            a = re.search(r"<artifactId>\s*([^<]+?)\s*</artifactId>", body)
            v = re.search(r"<version>\s*([^<]+?)\s*</version>", body)
            if g and a:
                ent.append(("Maven", f"{g.group(1)}:{a.group(1)}", v.group(1) if v and "$" not in v.group(1) else "", ln(m.start())))
    elif name == "build.gradle":
        for m in re.finditer(r"['\"]([\w.\-]+):([\w.\-]+):([\w.\-]+)['\"]", text):
            ent.append(("Maven", f"{m.group(1)}:{m.group(2)}", m.group(3), ln(m.start())))
    elif name == "go.mod":
        for m in re.finditer(r"^\s*(?:require\s+)?([\w./\-]+)\s+v([\w.\-+]+)", text, re.M):
            ent.append(("Go", m.group(1), m.group(2), ln(m.start())))
    elif name == "cargo.toml":
        for m in re.finditer(r"^\s*([\w\-]+)\s*=\s*(?:\"([\d.]+)\"|\{[^}]*version\s*=\s*\"([\d.]+)\")", text, re.M):
            ent.append(("crates.io", m.group(1), m.group(2) or m.group(3) or "", ln(m.start())))
    elif name == "gemfile.lock":
        for m in re.finditer(r"^\s{4}([\w\-]+) \(([\d.]+)\)", text, re.M):
            ent.append(("RubyGems", m.group(1), m.group(2), ln(m.start())))
    elif name.endswith(".csproj"):
        for m in re.finditer(r'<PackageReference\s+Include="([^"]+)"\s+Version="([^"]+)"', text):
            ent.append(("NuGet", m.group(1), m.group(2), ln(m.start())))
    else:
        for i, line in enumerate(text.splitlines(), 1):
            if line.strip().startswith("#"):
                continue
            m = re.match(r"\s*([A-Za-z0-9_.\-]+)\s*(?:\[[^\]]*\])?\s*(==|>=|~=|<=|>|<)?\s*([\d][\w.]*)?", line)
            if m and m.group(1):
                ver = m.group(3) if m.group(2) in ("==", None) or m.group(2) == "~=" else ""
                ent.append(("PyPI", m.group(1), ver or "", i))
    return ent


def scan_manifest(path: str, text: str):
    out = []
    meta, _ = advisories()
    for eco, lib, ver, line in _entries(path, text):
        key = lib.lower()
        if key not in PROVIDES:
            continue
        hits, known, upgrade = match(eco, key, ver)
        f = Finding(asset_type="library", algorithm=lib, params=ver or "unpinned", operation="link", primitive="other",
                    location=path, line=line, detector="deps", evidence=f"{lib} {ver or '(no version pinned)'} - provides {PROVIDES[key]}",
                    confidence=0.95, language="manifest")
        f.extra.update({"provides": PROVIDES[key], "ecosystem": eco, "known_advisories": known,
                        "advisory_source": meta.get("source", ""), "advisory_snapshot": meta.get("snapshot", "")})
        if key in PQ_READY:
            f.extra["pq_capable"] = True
        if hits:
            f.extra["advisories"] = [{"id": a["id"], "cve": a["cve"], "severity": a["severity"], "summary": a["summary"],
                                      "published": a["published"]} for a in sorted(hits, key=lambda a: a["published"], reverse=True)]
            f.extra["upgrade_to"] = upgrade
        elif not ver and known:
            f.extra["note"] = f"No version pinned; {known} published advisories exist for {lib}. Pin a version to check."
        out.append(f)
    return out
