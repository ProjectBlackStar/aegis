"""Recommender: post-quantum / hybrid / classical replacements with size and cost trade-offs.
Sizes are from FIPS 203 (ML-KEM), FIPS 204 (ML-DSA), FIPS 205 (SLH-DSA)."""
from __future__ import annotations

OPTS = {
    "hybrid-kem": {"name": "Hybrid X25519 + ML-KEM-768", "standard": "FIPS 203 + RFC 7748", "pk": 1184 + 32, "ct": 1088 + 32,
                   "latency": "low - ML-KEM is typically faster than RSA-2048 decryption in native implementations",
                   "why": "Key establishment that stays secure if either component holds; the transition default for public-facing channels.",
                   "use": "encryption / key establishment",
                   "constraints": ["ML-KEM is a KEM, not a drop-in for RSA encryption: derive a key with HKDF and encrypt with AES-256-GCM (KEM-DEM).",
                                   "Both endpoints must support it; keep a classical fallback during transition."]},
    "ml-kem-768": {"name": "ML-KEM-768", "standard": "FIPS 203", "pk": 1184, "ct": 1088,
                   "latency": "low", "why": "NIST security category 3; general-purpose key establishment.",
                   "use": "encryption / key establishment",
                   "constraints": ["Used as KEM + KDF + AES-GCM, not as direct RSA-style encryption."]},
    "ml-kem-1024": {"name": "ML-KEM-1024", "standard": "FIPS 203", "pk": 1568, "ct": 1568,
                    "latency": "low", "why": "Category 5 for data that must stay secret for decades (national ID, health).",
                    "use": "encryption / key establishment",
                    "constraints": ["Larger keys and ciphertexts than ML-KEM-768; check storage and message-size limits."]},
    "ml-dsa-65": {"name": "ML-DSA-65", "standard": "FIPS 204", "pk": 1952, "sig": 3309,
                  "latency": "low signing and verification cost", "why": "General-purpose post-quantum signatures.",
                  "use": "signatures",
                  "constraints": ["Every verifier must support ML-DSA; consider composite (classical + ML-DSA) signatures during transition.",
                                  "Signatures are ~13x larger than RSA-2048; check protocol and certificate size limits."]},
    "ml-dsa-44": {"name": "ML-DSA-44", "standard": "FIPS 204", "pk": 1312, "sig": 2420,
                  "latency": "lowest", "why": "Smaller signatures where category 2 is acceptable (tokens, sessions).",
                  "use": "signatures",
                  "constraints": ["JWT libraries need ML-DSA support (IETF JOSE drafts); verify your stack before switching."]},
    "slh-dsa": {"name": "SLH-DSA-SHA2-128s", "standard": "FIPS 205", "pk": 32, "sig": 7856,
                "latency": "slow signing, fast verification", "why": "Hash-based; conservative choice for long-lived documents and firmware.",
                "use": "signatures",
                "constraints": ["Large signatures (~7.9 KB) and slow signing; suited to infrequent, long-lived signatures."]},
    "aes-256-gcm": {"name": "AES-256-GCM", "standard": "FIPS 197 / SP 800-38D", "why": "Keeps ~128-bit security against Grover; authenticated."},
    "sha-256": {"name": "SHA-256 (or SHA-384)", "standard": "FIPS 180-4", "why": "Collision-resistant replacement for MD5/SHA-1."},
    "hmac-sha256": {"name": "HMAC-SHA-256", "standard": "FIPS 198-1", "why": "Drop-in replacement for HMAC-SHA1 (coordinate with partner)."},
    "tls13-hybrid": {"name": "TLS 1.3 only + X25519MLKEM768 key-exchange group", "standard": "RFC 8446 + IETF hybrid draft",
                     "why": "Removes legacy protocols and adds post-quantum key exchange.",
                     "use": "protocol", "constraints": ["Needs a TLS stack with the hybrid group (e.g. OpenSSL 3.5+, recent BoringSSL) on both ends.",
                                                        "Server certificates still use classical signatures until PQ certificates are supported by clients."]},
    "ssh-pq": {"name": "mlkem768x25519-sha256 (or sntrup761x25519-sha512)", "standard": "OpenSSH 9.9+ / 9.0+",
               "why": "Hybrid post-quantum SSH key exchange.", "use": "protocol",
               "constraints": ["Client and server must both support the algorithm; keep a classical algorithm listed second."]},
    "upgrade": {"name": "Upgrade library", "standard": "vendor advisory", "why": "Known weakness in the pinned version."},
    "reissue": {"name": "Re-issue certificate", "standard": "PKI policy", "why": "Expired or weak certificate."},
    "kms-pq": {"name": "PQC key spec in the KMS, or hybrid envelope in the application", "standard": "vendor roadmap",
               "why": "Cloud KMS post-quantum support varies by provider and region.", "use": "depends on key_usage",
               "constraints": ["Check your provider's PQC key types before migrating; otherwise wrap data keys with a hybrid KEM in the application."]},
}


CLASSIC_ASYM = ("RSA", "RSA/ECC", "ECDSA", "ECDH", "EC", "ECC", "DSA", "DH", "X25519", "ED25519", "ED448", "X448", "ELGAMAL")


def _sig_ids(f, risk):
    if "JWT" in f.params:
        return ["ml-dsa-44", "ml-dsa-65"]
    if risk["X"] >= 20 or "firmware" in f.location.lower():
        return ["slh-dsa", "ml-dsa-65"]
    return ["ml-dsa-65", "slh-dsa"]


def _kem_ids(risk):
    return ["ml-kem-1024", "hybrid-kem"] if risk["X"] >= 50 else ["hybrid-kem", "ml-kem-768"]


def recommend(f, risk):
    a = f.algorithm.upper()
    cls = risk["class"]
    use = f.extra.get("key_usage") or ""
    ids, summary, note = [], None, None
    if f.asset_type == "library":
        ids = ["upgrade"] if (f.extra.get("advisory") or f.extra.get("advisories")) else []
    elif f.asset_type == "certificate":
        ids = (["reissue"] if f.extra.get("expired") or cls == "broken" else []) + ["ml-dsa-65"]
        note = "Certificate keys authenticate (sign), so the replacement is a signature scheme, not ML-KEM."
    elif a in ("MD5", "SHA-1", "SHA1") and f.operation in ("hash", "kdf"):
        ids = ["sha-256"]
    elif a in ("SHA-1", "MD5") and f.operation == "mac":
        ids = ["hmac-sha256"]
    elif a in ("SHA-1",) and f.operation == "sign":
        ids = ["ml-dsa-65"]
    elif a in ("AES", "DES", "3DES", "RC4", "BLOWFISH") or f.primitive in ("block-cipher", "stream-cipher"):
        ids = ["aes-256-gcm"] if cls != "safe" else []
    elif a == "TLS" or f.params.startswith("static key transport"):
        ids = ["tls13-hybrid"]
    elif f.language == "ssh" and f.operation == "kex":
        ids = ["ssh-pq"]
    elif cls in ("vulnerable", "broken") and (a in CLASSIC_ASYM or f.asset_type in ("key", "cloud-kms")):
        if use == "signature" or risk["usage"] == "authentic":
            ids = _sig_ids(f, risk)
        elif use in ("encryption", "key-establishment"):
            ids = _kem_ids(risk)
        else:
            ids = ["ml-dsa-65", "hybrid-kem"]
            summary = "ML-DSA-65 if it signs, hybrid ML-KEM if it encrypts"
            note = "How this key is used is not visible in the scanned code, so both replacements are shown. Confirm its use before migrating."
        if f.asset_type == "cloud-kms":
            ids = ids + ["kms-pq"]
    elif cls in ("vulnerable", "broken"):
        ids = _kem_ids(risk)
    options = [dict(OPTS[i], id=i) for i in ids]
    for o in options:
        if o["id"] == "upgrade" and f.extra.get("advisories"):
            n = len(f.extra["advisories"])
            o["name"] = f"Upgrade {f.algorithm} to {f.extra.get('upgrade_to') or 'the latest release'}"
            o["why"] = (f"Fixes {n} published advisor{'y' if n == 1 else 'ies'} affecting {f.params} "
                        f"({', '.join(a['id'] for a in f.extra['advisories'][:3])}{'…' if n > 3 else ''}).")
            o["standard"] = "GitHub Advisory Database"
        if o["id"] in ("tls13-hybrid",):
            from .tlscost import client_hellos
            ch = client_hellos()
            o["compat"] = (f"{len(ch['pq_clients'])} of {ch['current_clients']} current clients in the SSL Labs list already send "
                           f"X25519MLKEM768 ({', '.join(ch['pq_clients'][:4])}…); the rest fall back to X25519, so nothing breaks.")
            o["constraints"] = list(o.get("constraints", [])) + [
                f"Hybrid ClientHellos are {min(ch['pq'])}-{max(ch['pq'])} bytes (vs {min(ch['classical'])}-{max(ch['classical'])} classical), "
                "so they span two TCP segments: test middleboxes and load balancers that expect a single-packet ClientHello."]
    current = {}
    if a == "RSA" and f.params.isdigit():
        n = int(f.params) // 8
        current = {"pk": n, "ct": n, "sig": n}
    elif a in ("ECDSA", "ECDH") and "256" in f.params:
        current = {"pk": 64, "sig": 64, "ct": 32}
    patchable = f.language == "python" and f.detector == "python-ast" and (
        (a == "RSA" and f.operation in ("encrypt", "decrypt")) or (a in ("SHA-1", "MD5") and f.operation == "hash"))
    cost = f.extra.get("tls_cost")
    return {"options": options, "current_sizes": current, "patchable": patchable, "key_usage": use or None, "tls_cost": cost,
            "key_usage_source": f.extra.get("key_usage_source"), "note": note,
            "summary": summary or (options[0]["name"] if options else ("No change needed" if cls in ("safe", "inventory") else "Review"))}
