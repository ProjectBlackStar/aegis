"""File-hash cache: unchanged files are not re-analysed. Keyed by content hash + path + engine version."""
from __future__ import annotations

import hashlib
import os
import pickle
import sqlite3
import tempfile
import threading

def _engine_fingerprint():
    """Changes whenever detector code or bundled data changes, so stale results are never reused."""
    h = hashlib.sha256()
    base = os.path.dirname(os.path.abspath(__file__))
    for root in (base, os.path.join(base, "..", "data")):
        for dp, _, fs in sorted(os.walk(root)):
            for fn in sorted(fs):
                if fn.endswith((".py", ".json")):
                    try:
                        with open(os.path.join(dp, fn), "rb") as fh:
                            h.update(fn.encode() + fh.read())
                    except OSError:
                        pass
    return h.hexdigest()[:16]


ENGINE_VERSION = "aegis-" + _engine_fingerprint()
_DB = os.environ.get("AEGIS_CACHE") or os.path.join(tempfile.gettempdir(), "aegis-work", "cache.sqlite")
_lock = threading.Lock()
_pending = []
_mem = {}


def digest(vf):
    return hashlib.sha256(vf.data).hexdigest()


def _key(vf):
    return hashlib.sha256(f"{ENGINE_VERSION}|{vf.path}|{digest(vf)}".encode()).hexdigest()


def _conn():
    os.makedirs(os.path.dirname(_DB), exist_ok=True)
    c = sqlite3.connect(_DB)
    c.execute("create table if not exists cache (k text primary key, v blob)")
    return c


def get(vf):
    k = _key(vf)
    if k in _mem:
        return pickle.loads(_mem[k])
    try:
        with _lock:
            c = _conn()
            row = c.execute("select v from cache where k=?", (k,)).fetchone()
            c.close()
        if row:
            _mem[k] = row[0]
            return pickle.loads(row[0])
    except Exception:
        return None
    return None


def put(vf, value):
    try:
        blob = pickle.dumps(value)
    except Exception:
        return
    k = _key(vf)
    _mem[k] = blob
    _pending.append((k, blob))


def flush():
    if not _pending:
        return
    try:
        with _lock:
            c = _conn()
            c.executemany("insert or replace into cache values (?,?)", list(_pending))
            c.commit()
            c.close()
        _pending.clear()
    except Exception:
        _pending.clear()


def clear():
    _mem.clear()
    try:
        with _lock:
            c = _conn()
            c.execute("delete from cache")
            c.commit()
            c.close()
    except Exception:
        pass
