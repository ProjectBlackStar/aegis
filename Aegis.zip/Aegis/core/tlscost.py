"""TLS handshake cost of moving a certificate chain and key exchange to post-quantum algorithms.

Computed from the certificates actually found in a scan (their real DER sizes), with standard sizes from
FIPS 203 / 204 / 205. Two limits decide whether the change costs an extra round trip:
  * TCP: initial congestion window of 10 segments (RFC 6928), ~14,600 bytes of payload.
  * QUIC: before the client's address is validated a server may send at most 3x the bytes it received (RFC 9000, 8.1).
Real ClientHello sizes come from the bundled SSL Labs client list (data/tls.json)."""
from __future__ import annotations

import json


def _read_json(path, **kw):
    with open(path, **kw) as fh:
        return json.load(fh)
import math
import os

_TLS = None


def tls_data():
    global _TLS
    if _TLS is None:
        _TLS = _read_json(os.path.join(os.path.dirname(__file__), "..", "data", "tls.json"))
    return _TLS


SIG = {  # public key bytes, signature bytes
    "ML-DSA-44": (1312, 2420), "ML-DSA-65": (1952, 3309), "ML-DSA-87": (2592, 4627),
    "SLH-DSA-SHA2-128s": (32, 7856), "SLH-DSA-SHA2-128f": (32, 17088),
}
KEX_SERVER_SHARE = {"X25519": 32, "X25519MLKEM768": 1088 + 32, "SecP256r1MLKEM768": 1088 + 65, "MLKEM1024": 1568}
SPKI_OVERHEAD = 22
SIG_OVERHEAD = 5
MSS = 1460
INITCWND = 10
QUIC_MIN_INITIAL = 1200
QUIC_PAYLOAD = 1200


def _flight(cert_lens, cv_sig, kex_share):
    sh = 90 + kex_share
    ee = 10
    cert_msg = 4 + 1 + 3 + sum(3 + c + 2 for c in cert_lens)
    cv = 8 + cv_sig
    fin = 36
    enc = ee + cert_msg + cv + fin
    records = 5 + sh + math.ceil(enc / 16384) * (5 + 16 + 1) + enc
    return records


def client_hellos():
    cl = [c for c in tls_data()["clients"] if c.get("current") and c.get("client_hello_bytes")]
    pq = [c for c in cl if c["pq_hybrid"]]
    classical = [c for c in cl if not c["pq_hybrid"]]
    return {"pq": sorted(c["client_hello_bytes"] for c in pq), "classical": sorted(c["client_hello_bytes"] for c in classical),
            "pq_clients": [c["name"] for c in pq], "current_clients": len(cl)}


def _verdict(total, ch_bytes):
    segs = math.ceil(total / MSS)
    tcp_extra = total > MSS * INITCWND
    datagrams = max(1, math.ceil(ch_bytes / QUIC_PAYLOAD))
    quic_limit = 3 * max(QUIC_MIN_INITIAL, datagrams * QUIC_MIN_INITIAL)
    quic_extra = total > quic_limit
    return {"bytes": total, "tcp_segments": segs, "tcp_extra_rtt": tcp_extra, "quic_limit": quic_limit, "quic_extra_rtt": quic_extra}


def chain_cost(chain):
    """chain: list of {"der_len", "spki_len", "sig_len"} leaf first. Returns options with byte counts and round-trip verdicts."""
    if not chain:
        return None
    assumed = False
    if len(chain) == 1:
        chain = chain + [dict(chain[0])]  # assume one intermediate of the same shape
        assumed = True
    lens = [c["der_len"] for c in chain]
    leaf_sig = chain[0].get("leaf_sig_len") or chain[0]["sig_len"]
    ch = client_hellos()
    ch_classical = ch["classical"][len(ch["classical"]) // 2] if ch["classical"] else 517
    ch_pq = ch["pq"][len(ch["pq"]) // 2] if ch["pq"] else 1720
    opts = [{"name": "Today (classical chain, X25519)", "kex": "X25519", "sig": "current",
             **_verdict(_flight(lens, leaf_sig, KEX_SERVER_SHARE["X25519"]), ch_classical), "client_hello": ch_classical}]
    opts.append({"name": "Hybrid key exchange only (X25519MLKEM768), classical certificates", "kex": "X25519MLKEM768", "sig": "current",
                 **_verdict(_flight(lens, leaf_sig, KEX_SERVER_SHARE["X25519MLKEM768"]), ch_pq), "client_hello": ch_pq})
    for alg in ("ML-DSA-44", "ML-DSA-65", "SLH-DSA-SHA2-128s"):
        pk, sg = SIG[alg]
        new = [c["der_len"] - c["spki_len"] - c["sig_len"] + pk + SPKI_OVERHEAD + sg + SIG_OVERHEAD for c in chain]
        opts.append({"name": f"Hybrid key exchange + {alg} certificates", "kex": "X25519MLKEM768", "sig": alg,
                     **_verdict(_flight(new, sg, KEX_SERVER_SHARE["X25519MLKEM768"]), ch_pq), "client_hello": ch_pq,
                     "chain_bytes": sum(new)})
    return {"chain_certs": len(chain), "chain_bytes_today": sum(lens), "assumed_intermediate": assumed, "options": opts,
            "limits": {"tcp": MSS * INITCWND, "tcp_source": "RFC 6928 initial window, 10 x 1460-byte segments",
                       "quic_source": "RFC 9000 section 8.1: 3x the bytes received before address validation"},
            "client_hello": {"classical_median": ch_classical, "pq_median": ch_pq, "pq_clients": ch["pq_clients"],
                             "current_clients": ch["current_clients"],
                             "source": "Qualys SSL Labs client list, as captured in testssl.sh etc/client-simulation.txt"}}
