"""PROTOTYPE post-quantum migration shim (generated). Not security-audited.

Dual-read, single-write envelope:
  * new data  -> hybrid X25519 + {KEM} (FIPS 203) -> HKDF-SHA256 -> AES-256-GCM
  * old data  -> still decrypts with the legacy RSA-OAEP key until re-encrypted

The X25519 + ML-KEM secrets are combined with HKDF-SHA256 (a simple concatenation combiner, not the
standardised X-Wing / TLS X25519MLKEM768 construction).

Production: load both private keys from your HSM/KMS instead of generating them here,
and use a native ML-KEM implementation (liboqs, OpenSSL 3.5+). The pure-Python
reference implementation (kyber-py) is used here so the patch runs anywhere.
"""
import os
import struct

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding as _rsa_padding
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from kyber_py.ml_kem import {KEM_CLASS} as _KEM

PQC_HYBRID = "X25519+{KEM}"
_MAGIC = b"KQ1"

# Recipient keys (demo: generated at start-up; production: from HSM/KMS)
_X_SK = X25519PrivateKey.generate()
_X_PK = _X_SK.public_key()
_KEM_EK, _KEM_DK = _KEM.keygen()


def _derive(ss_classic, ss_pq):
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b"pqc-hybrid-v1").derive(ss_classic + ss_pq)


def hybrid_encrypt(plaintext: bytes) -> bytes:
    eph = X25519PrivateKey.generate()
    ss1 = eph.exchange(_X_PK)
    ss2, kem_ct = _KEM.encaps(_KEM_EK)
    nonce = os.urandom(12)
    body = AESGCM(_derive(ss1, ss2)).encrypt(nonce, plaintext, _MAGIC)
    epk = eph.public_key().public_bytes_raw()
    return _MAGIC + struct.pack(">H", len(kem_ct)) + epk + kem_ct + nonce + body


def hybrid_decrypt(blob: bytes, legacy_key=None) -> bytes:
    if blob[:3] != _MAGIC:
        if legacy_key is None:
            raise ValueError("legacy ciphertext and no legacy key supplied")
        # dual-read: data written before the migration
        return legacy_key.decrypt(blob, _rsa_padding.OAEP(mgf=_rsa_padding.MGF1(algorithm=hashes.SHA256()),
                                                           algorithm=hashes.SHA256(), label=None))
    (n,) = struct.unpack(">H", blob[3:5])
    epk, kem_ct = blob[5:37], blob[37:37 + n]
    nonce, body = blob[37 + n:49 + n], blob[49 + n:]
    ss1 = _X_SK.exchange(X25519PublicKey.from_public_bytes(epk))
    ss2 = _KEM.decaps(_KEM_DK, kem_ct)
    return AESGCM(_derive(ss1, ss2)).decrypt(nonce, body, _MAGIC)
