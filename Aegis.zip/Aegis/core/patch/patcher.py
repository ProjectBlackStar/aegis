"""Patcher: generate a post-quantum fix for a Python finding, apply it to a COPY of the
project, run the project's tests, and re-scan to prove the risk moved.

Edits use exact AST positions, so nothing else in the file changes."""
from __future__ import annotations

import ast
import difflib
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = os.path.dirname(os.path.abspath(__file__))
VENDOR = os.path.abspath(os.path.join(HERE, "..", "..", "vendor"))


def _offsets(src):
    starts = [0]
    for line in src.splitlines(keepends=True):
        starts.append(starts[-1] + len(line))
    return starts


def _span(src, node):
    st = _offsets(src)
    return st[node.lineno - 1] + node.col_offset, st[node.end_lineno - 1] + node.end_col_offset


def _find_call(tree, line, pred):
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and n.lineno <= line <= n.end_lineno and pred(n):
            return n
    return None


def _base_name(e):
    while isinstance(e, (ast.Attribute, ast.Call)):
        e = e.value if isinstance(e, ast.Attribute) else e.func
    return e.id if isinstance(e, ast.Name) else None


def _import_line(root, file_rel):
    d = os.path.dirname(file_rel)
    if d and os.path.exists(os.path.join(root, d, "__init__.py")):
        return "from . import pqc_shim\n"
    return "import pqc_shim\n"


def _insert_import(src, stmt):
    tree = ast.parse(src)
    last = 0
    for n in tree.body:
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            last = n.end_lineno
        elif isinstance(n, ast.Expr) and isinstance(getattr(n, "value", None), ast.Constant) and last == 0:
            last = n.end_lineno
    lines = src.splitlines(keepends=True)
    lines.insert(last, stmt)
    return "".join(lines)


def plan_patch(root, finding):
    """Returns dict(file, new_source, shim, description) or raises ValueError."""
    rel = finding["location"]
    path = os.path.join(root, rel)
    src = Path(path).read_text(encoding="utf-8")
    tree = ast.parse(src)
    algo, op, line = finding["algorithm"].upper(), finding["operation"], finding["line"]
    edits = []
    shim = None
    desc = ""
    if algo == "RSA" and op in ("encrypt", "decrypt"):
        opts = finding.get("recommendation", {}).get("options", [])
        kem = "ML_KEM_1024" if opts and opts[0]["id"] == "ml-kem-1024" else "ML_KEM_768"
        key_obj = finding.get("extra", {}).get("via_object")
        # patch every encrypt/decrypt call on the same key object in this file (consistent migration)
        for n in ast.walk(tree):
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ("encrypt", "decrypt") \
                    and _base_name(n.func) == key_obj and n.args:
                data = ast.get_source_segment(src, n.args[0])
                if n.func.attr == "encrypt":
                    new = f"pqc_shim.hybrid_encrypt({data})"
                else:
                    new = f"pqc_shim.hybrid_decrypt({data}, legacy_key={key_obj})"
                edits.append((*_span(src, n), new))
        if not edits:
            raise ValueError("could not locate the RSA call on the key object")
        tmpl = Path(HERE, "pqc_shim_template.py").read_text(encoding="utf-8")
        kem_label = kem.replace("_", "-")
        shim = tmpl.replace("{KEM_CLASS}", kem).replace("{KEM}", kem_label)
        desc = (f"Replaced {len(edits)} RSA-OAEP call(s) on {key_obj} with a hybrid X25519 + {kem_label} envelope "
                f"(AES-256-GCM). Existing ciphertext still decrypts with the legacy key (dual-read).")
    elif algo in ("SHA-1", "MD5") and op == "hash":
        target = "sha1" if algo == "SHA-1" else "md5"
        n = _find_call(tree, line, lambda c: isinstance(c.func, ast.Attribute) and c.func.attr == target)
        if not n:
            raise ValueError("could not locate the hash call")
        a, b = _span(src, n.func)
        seg = src[a:b]
        edits.append((a, b, seg[: -len(target)] + "sha256"))
        desc = f"Replaced hashlib.{target} with hashlib.sha256. Stored digests must be recomputed on next write."
    else:
        raise ValueError("auto-patch is available for Python RSA encryption and MD5/SHA-1 hashing in this version")
    new = src
    for a, b, text in sorted(edits, reverse=True):
        new = new[:a] + text + new[b:]
    if shim:
        new = _insert_import(new, _import_line(root, rel))
    ast.parse(new)  # must still be valid Python
    return {"file": rel, "old_source": src, "new_source": new, "shim": shim, "description": desc,
            "shim_path": os.path.join(os.path.dirname(rel), "pqc_shim.py") if shim else None}


def run_tests(root, timeout=180):
    env = dict(os.environ)
    env["PYTHONPATH"] = os.pathsep.join([root, VENDOR, env.get("PYTHONPATH", "")])
    try:
        import pytest  # noqa: F401
        cmd = [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider"]
    except Exception:
        cmd = [sys.executable, "-m", "unittest", "discover", "-v"]
    t = time.time()
    try:
        p = subprocess.run(cmd, cwd=root, env=env, capture_output=True, text=True, timeout=timeout)
        out = (p.stdout + "\n" + p.stderr).strip()
        return {"ok": p.returncode == 0, "code": p.returncode, "output": out[-4000:], "cmd": " ".join(cmd[2:]),
                "seconds": round(time.time() - t, 2)}
    except subprocess.TimeoutExpired:
        return {"ok": False, "code": -1, "output": "tests timed out", "cmd": " ".join(cmd[2:]), "seconds": timeout}


def apply_to_copy(project_root, finding, work_dir):
    plan = plan_patch(project_root, finding)
    dest = tempfile.mkdtemp(prefix="patch-", dir=work_dir)
    shutil.copytree(project_root, dest, dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns(".git", "node_modules", "__pycache__", ".venv", "venv"))
    before_tests = run_tests(dest)
    with open(os.path.join(dest, plan["file"]), "w", encoding="utf-8") as fh:
        fh.write(plan["new_source"])
    if plan["shim"]:
        with open(os.path.join(dest, plan["shim_path"]), "w", encoding="utf-8") as fh:
            fh.write(plan["shim"])
    after_tests = run_tests(dest)
    diff = "".join(difflib.unified_diff(plan["old_source"].splitlines(keepends=True), plan["new_source"].splitlines(keepends=True),
                                        fromfile="a/" + plan["file"], tofile="b/" + plan["file"]))
    return {"patched_root": dest, "file": plan["file"], "diff": diff, "description": plan["description"],
            "shim_path": plan["shim_path"], "shim": plan["shim"], "tests_before": before_tests, "tests_after": after_tests,
            "fixed": after_tests["ok"]}
