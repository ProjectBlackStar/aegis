"""Built-in knowledge: data classes (for lifetime inference) and algorithm facts.

Everything here is editable policy, not hard-coded truth. Lifetimes are defaults
an organisation can change in rules/policy.json.
"""
import re

# --- Data classes -----------------------------------------------------------
# pattern: regex on identifier names (snake/camel split, lower-cased)
# lifetime: years the data must stay secret (confidentiality horizon)
DATA_CLASSES = [
    {"id": "AADHAAR", "label": "Aadhaar number", "pattern": r"(^|_)(aadhaar|aadhar|adhaar|uidai|aadhaar_?no|uid_?number)(_|$)",
     "lifetime": 70, "category": "DPDP personal data - national ID (lifelong)"},
    {"id": "BIOMETRIC", "label": "Biometric data", "pattern": r"(^|_)(biometric|fingerprint|iris|face_?template)(_|$)",
     "lifetime": 70, "category": "DPDP personal data - biometric (lifelong)"},
    {"id": "HEALTH", "label": "Health record", "pattern": r"(^|_)(health|diagnosis|medical|prescription|abha|patient|lab_?report)(_|$)",
     "lifetime": 70, "category": "DPDP personal data - health (lifelong)"},
    {"id": "PAN", "label": "PAN (tax ID)", "pattern": r"(^|_)(pan|pan_?no|pan_?number|pan_?card)(_|$)",
     "lifetime": 50, "category": "DPDP personal data - tax ID"},
    {"id": "PASSPORT", "label": "Passport / govt ID", "pattern": r"(^|_)(passport|voter_?id|driving_?licen[cs]e|dl_?number)(_|$)",
     "lifetime": 50, "category": "DPDP personal data - government ID"},
    {"id": "ESIGN", "label": "Signed legal document", "pattern": r"(^|_)(esign|contract|agreement|deed|legal_?doc|signed_?doc)(_|$)",
     "lifetime": 30, "category": "Legal document (long-lived signature validity)"},
    {"id": "FINANCIAL", "label": "Financial / account data", "pattern": r"(^|_)(account_?(no|number)?|acct|ifsc|card_?(no|number)?|cvv|upi|vpa|balance|salary|txn|transaction|loan)(_|$)",
     "lifetime": 10, "category": "Financial record (retention ~10 years)"},
    {"id": "CLASSIFIED", "label": "Classified / strategic", "pattern": r"(^|_)(classified|secret_?doc|intel|strategic)(_|$)",
     "lifetime": 50, "category": "Strategic / classified"},
    {"id": "PERSONAL", "label": "Personal contact data", "pattern": r"(^|_)(full_?name|customer_?name|holder_?name|dob|date_?of_?birth|address|phone|mobile|email)(_|$)",
     "lifetime": 20, "category": "DPDP personal data - identity"},
    {"id": "CREDENTIAL", "label": "Credential / password", "pattern": r"(^|_)(password|passwd|pwd|secret|api_?key|private_?key|pin)(_|$)",
     "lifetime": 2, "category": "Credential (rotated)"},
    {"id": "EPHEMERAL", "label": "OTP / session token", "pattern": r"(^|_)(otp|nonce|session(_?id)?|csrf|captcha|challenge)(_|$)",
     "lifetime": 0.001, "category": "Ephemeral (minutes)"},
]
for dc in DATA_CLASSES:
    dc["rx"] = re.compile(dc["pattern"])


def split_ident(name: str) -> str:
    """camelCase / kebab / dotted -> snake lower."""
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)
    s = re.sub(r"[^A-Za-z0-9]+", "_", s)
    return s.lower().strip("_")


def classify_identifier(name: str):
    ident = split_ident(name)
    for dc in DATA_CLASSES:
        if dc["rx"].search(ident):
            return dc
    return None


# --- Value validators (stronger than names) ---------------------------------
_VERHOEFF_D = [[0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],[3,4,0,1,2,8,9,5,6,7],
               [4,0,1,2,3,9,5,6,7,8],[5,9,8,7,6,0,4,3,2,1],[6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],
               [8,7,6,5,9,3,2,1,0,4],[9,8,7,6,5,4,3,2,1,0]]
_VERHOEFF_P = [[0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],[8,9,1,6,0,4,3,5,2,7],
               [9,4,5,3,1,2,6,8,7,0],[4,2,8,6,5,7,3,9,0,1],[2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8]]


def verhoeff_ok(num: str) -> bool:
    c = 0
    for i, ch in enumerate(reversed(num)):
        c = _VERHOEFF_D[c][_VERHOEFF_P[i % 8][int(ch)]]
    return c == 0


def classify_value(v: str):
    s = v.replace(" ", "").replace("-", "")
    if re.fullmatch(r"[2-9]\d{11}", s) and verhoeff_ok(s):
        return "AADHAAR", "12-digit value passes the Aadhaar Verhoeff checksum"
    if re.fullmatch(r"[A-Z]{5}\d{4}[A-Z]", v.strip()):
        return "PAN", "value matches the PAN format AAAAA9999A"
    if re.fullmatch(r"[A-Z]{4}0[A-Z0-9]{6}", v.strip()):
        return "FINANCIAL", "value matches the IFSC format"
    if re.fullmatch(r"[\w.\-]{2,}@[a-zA-Z]{2,}", v.strip()) and "." not in v.split("@")[1]:
        return "FINANCIAL", "value matches a UPI VPA (name@bank)"
    return None


DATA_CLASS_BY_ID = {d["id"]: d for d in DATA_CLASSES}

# --- Algorithm knowledge ----------------------------------------------------
# class: broken (classically broken today) | vulnerable (Shor) | weakened (Grover) | safe
def classify_algorithm(algo: str, params: str = "", operation: str = ""):
    a = algo.upper()
    p = (params or "").upper()
    if a in ("MD5", "MD4", "SHA-1", "SHA1", "DES", "3DES", "TDEA", "RC4", "RC2", "BLOWFISH"):
        if a in ("SHA-1", "SHA1") and operation in ("mac",):
            return "weakened", f"HMAC-SHA1 is not broken, but SHA-1 is deprecated; migrate to SHA-256+"
        return "broken", f"{algo} is broken or deprecated today, independent of quantum computers"
    if a == "AES" and "ECB" in p:
        return "broken", "ECB mode leaks plaintext patterns; unsafe today"
    if a in ("RSA", "DSA", "ECDSA", "ECDH", "EC", "ECC", "DH", "X25519", "ED25519", "X448", "ED448", "ELGAMAL"):
        if a == "RSA":
            m = re.fullmatch(r"(\d{3,5})", p.strip())
            if m and int(m.group(1)) < 2048:
                return "broken", f"RSA-{m.group(1)} is below the 2048-bit minimum today, and also quantum-vulnerable"
        if a == "DSA":
            return "broken", "DSA is withdrawn (FIPS 186-5) and quantum-vulnerable"
        return "vulnerable", f"{algo} is broken by Shor's algorithm on a cryptographically relevant quantum computer"
    if a == "AES":
        m = re.search(r"(128|192|256)", p)
        if m and m.group(1) == "128":
            return "weakened", "AES-128 drops to ~64-bit security under Grover; use AES-256"
        if not m:
            return "weakened", "AES key size not determined; assume AES-128 until proven 256"
        return "safe", f"AES-{m.group(1)} keeps adequate security against quantum attacks"
    if a in ("SHA-224", "SHA224"):
        return "weakened", "SHA-224 gives ~112-bit collision security; prefer SHA-384"
    if a in ("SHA-256", "SHA256", "SHA-384", "SHA-512", "SHA3-256", "SHA3-512", "BLAKE2", "HMAC-SHA256", "CHACHA20", "CHACHA20-POLY1305"):
        return "safe", f"{algo} is considered adequately quantum-resistant"
    if a in ("X25519MLKEM",):
        return "safe", "Classical half of a hybrid X25519 + ML-KEM scheme; security holds while ML-KEM holds"
    if a in ("ML-KEM", "ML-DSA", "SLH-DSA", "KYBER", "DILITHIUM", "SPHINCS+", "FN-DSA", "HQC", "X25519MLKEM768"):
        return "safe", f"{algo} is a NIST post-quantum standard"
    if a == "TLS":
        if p in ("SSLV2", "SSLV3", "TLSV1", "TLSV1.0", "TLSV1.1", "TLS1.0", "TLS1.1"):
            return "broken", f"{params} is deprecated and insecure today"
        return "vulnerable", "TLS key exchange/auth relies on RSA/ECDHE, quantum-vulnerable without a hybrid PQ group"
    if a == "SSH":
        return "vulnerable", "SSH host keys and key exchange rely on RSA/ECC/DH"
    if a in ("SCRYPT", "PBKDF2", "ARGON2", "BCRYPT"):
        return "safe", f"{algo} is a password-hashing KDF; quantum computers do not materially weaken it"
    if a in ("HMAC",):
        return "safe", "HMAC with a SHA-2 hash is quantum-resistant"
    return "vulnerable" if operation in ("sign", "kex", "keygen") else "weakened", f"{algo}: classification needs review"


PRIMITIVE = {
    "RSA": "pke", "DSA": "signature", "ECDSA": "signature", "ED25519": "signature", "ED448": "signature",
    "ECDH": "key-agree", "DH": "key-agree", "X25519": "key-agree", "X448": "key-agree", "EC": "pke", "ECC": "pke",
    "AES": "block-cipher", "DES": "block-cipher", "3DES": "block-cipher", "RC4": "stream-cipher", "CHACHA20": "stream-cipher",
    "MD5": "hash", "SHA-1": "hash", "SHA-224": "hash", "SHA-256": "hash", "SHA-384": "hash", "SHA-512": "hash",
    "HMAC": "mac", "TLS": "protocol", "SSH": "protocol", "ML-KEM": "kem", "ML-DSA": "signature",
}

OIDS = {"RSA": "1.2.840.113549.1.1.1", "ECDSA": "1.2.840.10045.2.1", "EC": "1.2.840.10045.2.1",
        "ED25519": "1.3.101.112", "X25519": "1.3.101.110", "SHA-1": "1.3.14.3.2.26", "SHA-256": "2.16.840.1.101.3.4.2.1",
        "MD5": "1.2.840.113549.2.5", "AES": "2.16.840.1.101.3.4.1", "DSA": "1.2.840.10040.4.1",
        "ML-KEM": "2.16.840.1.101.3.4.4.2", "ML-DSA": "2.16.840.1.101.3.4.3.18"}
