"""Scan orchestration: collect -> detect -> link data -> assess risk -> recommend."""
from __future__ import annotations

import math
import os
import time
import uuid
from collections import Counter, defaultdict

from .collect import collect, VFile
from .model import Finding, DataLink
from .knowledge import classify_identifier, classify_value, DATA_CLASS_BY_ID
from .detectors.python_ast import scan_python
from .detectors.lexer import scan_lexer
from .detectors.binary import scan_binary, is_binary
from .detectors.certs import scan_certs, looks_like_keymaterial
from .detectors.configs import scan_config, is_config
from .detectors.deps import scan_manifest, is_manifest
from .detectors.keystore import scan_keystore, is_keystore
from .risk import assess, DEFAULT_POLICY, prepare, criticality
from .recommend import recommend
from . import cache as CACHE
from . import quantum as Q

LEX = {".java": "java", ".kt": "java", ".js": "js", ".mjs": "js", ".cjs": "js", ".ts": "js", ".tsx": "js", ".jsx": "js",
       ".c": "c", ".h": "c", ".cc": "c", ".cpp": "c", ".hpp": "c", ".cxx": "c", ".go": "go"}
TEXT_LANG = {".py": "Python", **{k: v.capitalize() for k, v in LEX.items()}}


def _text(data: bytes):
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("latin-1")


def detect_file(vf: VFile):
    """Returns (findings, python_meta or None, kind)."""
    p = vf.path
    low = p.lower()
    ext = os.path.splitext(low)[1]
    head = vf.data[:4096]
    if ext == ".py":
        f, summ, calls, routes = scan_python(p, _text(vf.data))
        return f, (p, summ, calls, routes), "Python"
    if ext in LEX:
        return scan_lexer(p, _text(vf.data), LEX[ext]), None, LEX[ext].upper() if LEX[ext] != "js" else "JS/TS"
    if is_keystore(p, head):
        return scan_keystore(p, vf.data), None, "Keystore"
    if is_binary(head):
        return scan_binary(p, vf.data), None, "Binary"
    if looks_like_keymaterial(p, head):
        return scan_certs(p, vf.data), None, "Cert/Key"
    if is_manifest(p):
        return scan_manifest(p, _text(vf.data)), None, "Manifest"
    if b"\x00" not in head:
        t = _text(vf.data)
        if is_config(p, t):
            return scan_config(p, t), None, "Config"
    return [], None, None


class Scan:
    def __init__(self, target, label=None, policy=None):
        self.id = uuid.uuid4().hex[:10]
        self.target = target
        self.label = label or os.path.basename(target.rstrip("/")) or target
        self.policy = policy or DEFAULT_POLICY
        self.status = "queued"
        self.progress = {"files": 0, "findings": 0, "current": ""}
        self.started = None
        self.finished = None
        self.findings: list[Finding] = []
        self.file_stats = Counter()
        self.error = None
        self.events = []
        self.warnings = []
        self.use_cache = True
        self.cache_hits = 0
        self.file_hashes = {}

    def log(self, kind, **kw):
        self.events.append({"t": round(time.time() - (self.started or time.time()), 2), "kind": kind, **kw})

    def run(self):
        self.started = time.time()
        self.status = "scanning"
        self.log("start", target=self.label)
        py_meta = []
        try:
            for vf in collect(self.target):
                self.progress["files"] += 1
                self.progress["current"] = vf.path
                if vf.origin.startswith("error:"):
                    self.log("warn", file=vf.path, msg=vf.origin[6:])
                    self.warnings.append({"file": vf.path, "msg": vf.origin[6:]})
                    continue
                try:
                    hit = CACHE.get(vf) if self.use_cache else None
                    if hit is not None:
                        fs, meta, kind = hit
                        self.cache_hits += 1
                    else:
                        fs, meta, kind = detect_file(vf)
                        if self.use_cache:
                            CACHE.put(vf, (fs, meta, kind))
                    self.file_hashes[vf.path] = CACHE.digest(vf)
                except Exception as e:  # never let one file kill the scan
                    fs, meta, kind = [], None, None
                    self.log("warn", file=vf.path, msg=str(e)[:200])
                    self.warnings.append({"file": vf.path, "msg": f"{type(e).__name__}: {str(e)[:160]}"})
                if kind:
                    self.file_stats[kind] += 1
                if meta:
                    py_meta.append(meta)
                if fs:
                    self.findings.extend(fs)
                    self.progress["findings"] = len(self.findings)
                    self.log("found", file=vf.path, n=len(fs))
            self.status = "analysing"
            CACHE.flush()
            self._link(py_meta)
            self._assess()
            self.status = "done"
        except Exception as e:
            self.status = "error"
            self.error = f"{type(e).__name__}: {e}"
        self.finished = time.time()
        self.log("end", status=self.status)
        return self

    # --- data-link: sources -> DataLinks, inter-procedural hop, key propagation, exposure
    def _link(self, py_meta):
        by_file = defaultdict(list)
        for f in self.findings:
            by_file[f.location].append(f)
        # function summaries across files
        summaries = defaultdict(list)  # func -> [(file, {param: [finding idx]})]
        routes = set()
        for path, summ, calls, rts in py_meta:
            for fn, pm in summ.items():
                summaries[fn].append((path, pm))
            routes |= {(path, r) for r in rts}
        route_funcs = {r for _, r in routes}
        external_funcs = set(route_funcs)
        for path, summ, calls, rts in py_meta:
            file_findings = [f for f in by_file[path] if f.detector == "python-ast"]
            is_test = "/tests/" in "/" + path or path.rsplit("/", 1)[-1].startswith("test_")
            for callee, caller, args, line in calls:
                if caller in route_funcs:
                    external_funcs.add(callee)
                if callee not in summaries:
                    continue
                for tpath, pm in summaries[callee]:
                    targets = [f for f in by_file[tpath] if f.detector == "python-ast"]
                    for ai, srcs in args:
                        for idx in pm.get(ai, []):
                            if idx < len(targets):
                                t = targets[idx]
                                via = t.extra.setdefault("via_calls", [])
                                via.append(f"{path}:{line} {caller or '<module>'}() -> {callee}()")
                                t.extra["sources"] = sorted(set(t.extra.get("sources", [])) | set(srcs))
                                t.extra.setdefault("ip_sources", {})
                                for s_ in srcs:
                                    t.extra["ip_sources"].setdefault(s_, f"{path}:{line}")
                                hop = {"line": line, "file": path, "hop": "caller",
                                       "text": f"{caller or '<module>'}() passes {', '.join(srcs)} to {callee}()"}
                                fl = t.extra.setdefault("flow", [])
                                hop["text"] = hop["text"].replace("literal:", "value ")
                                if is_test:
                                    t.extra.setdefault("test_callers", []).append(f"{path}:{line}")
                                    continue
                                if not any(h.get("hop") == "caller" and h.get("file") == path and h.get("line") == line for h in fl):
                                    fl.insert(0, hop)
        # exposure
        for f in self.findings:
            if f.detector == "python-ast" and f.extra.get("func") in external_funcs:
                f.exposure = "external"
        # classify sources into DataLinks
        for f in self.findings:
            links = {}
            srcs = f.extra.get("sources", [])
            idents = [x for x in srcs if not x.startswith("literal:")]
            literals = [x[8:] for x in srcs if x.startswith("literal:")]
            for s in idents:
                dc = classify_identifier(s)
                if dc:
                    conf = 0.9 if dc["id"] in ("AADHAAR", "PAN", "HEALTH", "BIOMETRIC", "EPHEMERAL") else 0.75
                    ip = (f.extra.get("ip_sources") or {}).get(s)
                    kind = "inter-procedural" if ip else "direct"
                    reason = (f"'{s}' flows into this call; the name matches {dc['label']}"
                              + (f" (passed in from {ip})" if ip else ""))
                    prev = links.get(dc["id"])
                    if not prev or prev.confidence < conf:
                        links[dc["id"]] = DataLink(s, dc["id"], dc["label"], dc["lifetime"], conf, reason, kind,
                                                   list(f.extra.get("flow", [])))
            for v in literals:
                r = classify_value(v)
                if not r:
                    continue
                dc = DATA_CLASS_BY_ID[r[0]]
                if dc["id"] in links:
                    d = links[dc["id"]]
                    d.confidence = max(d.confidence, 0.97)
                    d.reason += f"; confirmed: a value reaching it {r[1][r[1].find('passes') if 'passes' in r[1] else 0:]}"
                else:
                    links[dc["id"]] = DataLink("value " + v[:4] + "…", dc["id"], dc["label"], dc["lifetime"], 0.95, r[1],
                                               "value-validated", list(f.extra.get("flow", [])))
            f.data_links = sorted(links.values(), key=lambda d: -d.lifetime_years)
        # propagate usage data links to the key that serves them
        by_fid = {f.fid: f for f in self.findings}
        for f in self.findings:
            kf = f.extra.get("key_finding")
            if kf and kf in by_fid and f.data_links:
                key = by_fid[kf]
                have = {d.data_class for d in key.data_links}
                for d in f.data_links:
                    if d.data_class not in have:
                        key.data_links.append(DataLink(d.source, d.data_class, d.label, d.lifetime_years, d.confidence,
                                                       f"this key is used at line {f.line} to protect '{d.source}'",
                                                       "shared-key", list(d.path) + [{"line": key.line, "hop": "key",
                                                       "text": f"key created here ({key.display_name})"}]))
                if f.exposure == "external":
                    key.exposure = "external"
            if kf and kf in by_fid and f.operation == "sign":
                by_fid[kf].primitive = "signature"
        # a cipher/signer object that is only a wrapper around a key is merged into its usage
        used = {f.extra.get("key_finding") for f in self.findings}
        drop = {fid for fid in used if fid in by_fid and by_fid[fid].extra.get("init_only")}
        if drop:
            for f in self.findings:
                if f.extra.get("key_finding") in drop:
                    w = by_fid[f.extra["key_finding"]]
                    f.data_links = f.data_links or w.data_links
                    f.extra["key_finding"] = w.extra.get("key_finding")
            self.findings = [f for f in self.findings if f.fid not in drop]
            by_fid = {f.fid: f for f in self.findings}
        # usages of the same key share what that key protects (e.g. decrypt of the Aadhaar vault)
        for f in self.findings:
            kf = f.extra.get("key_finding")
            if kf and kf in by_fid and not f.data_links and by_fid[kf].data_links:
                f.data_links = [DataLink(d.source, d.data_class, d.label, d.lifetime_years, round(d.confidence * 0.95, 2),
                                         f"same key ({by_fid[kf].display_name}, line {by_fid[kf].line}) protects '{d.source}' elsewhere",
                                         "shared-key", list(d.path))
                                for d in by_fid[kf].data_links]
                if by_fid[kf].exposure == "external":
                    f.exposure = "external"

    def reassess(self, policy):
        """Apply a new policy (quantum-arrival years, data lifetimes, migration speed) without re-scanning."""
        import copy
        self.policy = copy.deepcopy(policy)
        lt = self.policy.get("lifetimes") or {}
        for f in self.findings:
            for d in f.data_links:
                dd = d if isinstance(d, dict) else d.to_dict()
                base = DATA_CLASS_BY_ID.get(dd["data_class"], {}).get("lifetime", dd["lifetime_years"])
                v = lt.get(dd["data_class"], base)
                if isinstance(d, dict):
                    d["lifetime_years"] = float(v)
                else:
                    d.lifetime_years = float(v)
        self._assess()
        return self

    def _evidence(self):
        for f in self.findings:
            ev = f.evidence or ""
            if f.detector == "python-ast" and f.extra.get("reference"):
                t, st = "algorithm selected by reference (resolved import)", "strong"
            elif f.detector == "python-ast" and f.extra.get("typed_by"):
                t, st = f"crypto call, key type from {f.extra['typed_by']}", "confirmed"
            elif f.detector == "python-ast":
                t, st = ("call on a tracked crypto object" if f.extra.get("via_object") else "resolved API call"), "confirmed"
            elif f.detector.startswith("lexer-"):
                t, st = ("include / import" if f.asset_type == "library" else "API call pattern"), ("indicative" if f.asset_type == "library" else "strong")
            elif f.detector == "binary":
                if ev.startswith("dynamically links"):
                    t, st = "linked library", "strong"
                elif ev.startswith("imports symbol"):
                    t, st = "imported symbol", "strong"
                elif ev.startswith("embedded version string"):
                    t, st = "version string", "indicative"
                else:
                    t, st = "code signature (algorithm present, use not proven)", "indicative"
            elif f.detector in ("cert", "keystore"):
                t, st = "parsed certificate / key file", "confirmed"
            elif f.detector == "probe":
                t, st = "observed on the live endpoint", "confirmed"
            elif f.detector == "config":
                t, st = "declared in configuration", "confirmed"
            elif f.detector == "deps":
                t, st = "declared dependency", "indicative"
            else:
                t, st = f.detector, "indicative"
            f.evidence_type, f.evidence_strength = t, st

    def _key_usage(self):
        """How each key is used: observed in code, declared in config, inferred, or unknown.
        Drives the ML-KEM (encryption / key establishment) vs ML-DSA (signatures) choice."""
        uses = defaultdict(set)
        for f in self.findings:
            kf = f.extra.get("key_finding")
            if kf:
                uses[kf].add("signature" if f.operation in ("sign", "verify") else "encryption")
        for f in self.findings:
            if f.extra.get("key_usage"):
                continue
            u, src = None, None
            if f.fid in uses:
                u = "both" if len(uses[f.fid]) > 1 else next(iter(uses[f.fid]))
                src = "observed in code"
            elif f.extra.get("declared_usage"):
                u, src = f.extra["declared_usage"], "declared in configuration"
            elif f.operation in ("sign", "verify") or f.primitive == "signature":
                u, src = "signature", "operation"
            elif f.operation in ("encrypt", "decrypt"):
                u, src = "encryption", "operation"
            elif f.operation == "kex" or f.primitive in ("key-agree", "kem"):
                u, src = "key-establishment", "algorithm"
            elif f.asset_type == "certificate":
                u, src = "signature", "certificate (authentication)"
            elif f.operation == "keygen":
                hint = (f.location + " " + f.context + " " + f.evidence).lower()
                if any(k in hint for k in ("sign", "auth", "jwt", "token", "cert")):
                    u, src = "signature", "inferred from names (low confidence)"
                else:
                    u, src = "unknown", "use not visible in scanned code"
            if u:
                f.extra["key_usage"], f.extra["key_usage_source"] = u, src
                if u == "signature" and f.primitive == "pke":
                    f.primitive = "signature"

    def _link_tls_certs(self):
        """A TLS config that names a certificate file inherits that certificate's handshake-cost analysis."""
        by_base = {}
        for f in self.findings:
            if f.asset_type == "certificate" and f.extra.get("tls_cost"):
                by_base.setdefault(f.location.rsplit("/", 1)[-1].rsplit(".", 1)[0], f)
        for f in self.findings:
            prof = f.extra.get("tls_profile")
            if not prof or f.extra.get("tls_cost"):
                continue
            for cf in prof.get("cert_files", []):
                c = by_base.get(cf.rsplit(".", 1)[0])
                if c:
                    f.extra["tls_cost"] = c.extra["tls_cost"]
                    f.extra["tls_cert"] = f"{c.location}:{c.line}"
                    break

    def _agility(self):
        """Crypto-agility per algorithm family: how scattered and how hard-coded it is. Feeds Mosca's Y."""
        code = [f for f in self.findings if f.detector == "python-ast" or f.detector.startswith("lexer-")]
        spread = defaultdict(set)
        sites = Counter()
        for f in code:
            spread[f.algorithm].add(f.location)
            sites[f.algorithm] += 1
        out = {}
        for f in self.findings:
            parts = []
            score = 100
            if f.asset_type == "library":
                continue
            if f.detector == "python-ast" or f.detector.startswith("lexer-"):
                n = len(spread[f.algorithm])
                pen = min(45, round(15 * math.log2(n))) if n > 1 else 0
                if pen:
                    parts.append({"why": f"{f.algorithm} used in {n} files ({sites[f.algorithm]} call sites), not behind one module", "points": -pen})
                score -= pen
                if f.params:
                    parts.append({"why": "algorithm and parameters written into the code", "points": -20})
                    score -= 20
            elif f.detector == "binary" or "firmware" in f.location.lower():
                parts.append({"why": "compiled into a binary: needs a vendor rebuild", "points": -35})
                score -= 35
            elif f.detector in ("cert", "keystore"):
                parts.append({"why": "certificate / key replacement needs re-issue and distribution", "points": -15})
                score -= 15
            else:
                parts.append({"why": "set in configuration: can be changed without code changes", "points": 0})
            out[f.fid] = {"score": max(5, score), "parts": parts}
        return out

    def _assess(self):
        self._evidence()
        self._key_usage()
        self.policy, model = prepare(self.policy)
        self._link_tls_certs()
        ag = self._agility()
        for f in self.findings:
            f.data_links = [d.to_dict() if isinstance(d, DataLink) else d for d in f.data_links]
            tier, src, exp = criticality(f, self.policy)
            if exp in ("external", "internal"):
                f.extra.setdefault("exposure_detected", f.exposure)
                f.exposure = exp
            elif "exposure_detected" in f.extra:
                f.exposure = f.extra.pop("exposure_detected")
            f.risk = assess(f, self.policy, ag.get(f.fid), model)
            f.recommendation = recommend(f, f.risk)
        self.findings.sort(key=lambda f: (-f.risk["priority"], f.location, f.line))

    # --- summaries for the UI
    def summary(self):
        cls = Counter(f.risk.get("class") for f in self.findings)
        sev = Counter(f.risk.get("severity") for f in self.findings)
        assets = Counter(f.asset_type for f in self.findings)
        algos = Counter(f.algorithm for f in self.findings if f.risk.get("class") in ("vulnerable", "broken", "weakened"))
        linked = sum(1 for f in self.findings if f.data_links)
        exposed = sum(1 for f in self.findings if f.risk.get("exposed"))
        dclasses = Counter(d["data_class"] for f in self.findings for d in f.data_links)
        return {
            "id": self.id, "label": self.label, "target": self.target, "status": self.status, "error": self.error,
            "duration": round((self.finished or time.time()) - (self.started or time.time()), 2),
            "files": self.progress["files"], "file_types": dict(self.file_stats), "total": len(self.findings),
            "classes": dict(cls), "severity": dict(sev), "assets": dict(assets), "top_algorithms": algos.most_common(8),
            "data_linked": linked, "exposed": exposed, "warnings": self.warnings[:50], "data_classes": dict(dclasses), "policy": self.policy,
            "cache_hits": self.cache_hits, "started": self.started,
            "p_exposure_mean": round(sum(f.risk.get("p_exposure", 0) for f in self.findings if f.risk.get("class") == "vulnerable")
                                     / max(1, sum(1 for f in self.findings if f.risk.get("class") == "vulnerable")), 3),
            "criticality": dict(Counter(f.risk.get("criticality") for f in self.findings)),
        }
