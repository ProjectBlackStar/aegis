"""Quantum arrival model built from published data (bundled in data/quantum.json).

* CRQC arrival for RSA-2048 = a log-normal fitted to the Global Risk Institute 2025 expert survey.
* Each algorithm is shifted by its logical-qubit requirement relative to RSA-2048 (the "qubit ladder").
* Probabilistic Mosca: P(exposure) = F(t_now + Y + X - shift)."""
from __future__ import annotations

import datetime
import json


def _read_json(path, **kw):
    with open(path, **kw) as fh:
        return json.load(fh)
import math
import os
from statistics import NormalDist

_N = NormalDist()
DATA = _read_json(os.path.join(os.path.dirname(__file__), "..", "data", "quantum.json"))
SURVEY = DATA["survey"]
BANDS = ("optimistic", "mid", "pessimistic")


def now_year():
    t = datetime.date.today()
    return t.year + (t.timetuple().tm_yday - 1) / 365.25


def _prob(point, band):
    lo, hi = point["low"], point["high"]
    return {"optimistic": hi, "pessimistic": lo}.get(band, (lo + hi) / 2)


def fit_survey(band="mid"):
    """Log-normal (in years after the survey year) through the two published horizons."""
    p1, p2 = SURVEY["points"][:2]
    z1, z2 = _N.inv_cdf(_prob(p1, band)), _N.inv_cdf(_prob(p2, band))
    s = (math.log(p2["horizon_years"]) - math.log(p1["horizon_years"])) / (z2 - z1)
    mu = math.log(p1["horizon_years"]) - z1 * s
    return {"mu": mu, "sigma": s, "origin": SURVEY["survey_year"], "band": band, "kind": "survey"}


def fit_years(p10_year, p50_year, origin=None):
    """Log-normal through two user-chosen years (10% and 50% points)."""
    origin = origin if origin is not None else SURVEY["survey_year"]
    a, b = max(0.25, p10_year - origin), max(0.5, p50_year - origin)
    if b <= a:
        b = a + 0.5
    s = (math.log(b) - math.log(a)) / (0 - _N.inv_cdf(0.10))
    return {"mu": math.log(b), "sigma": s, "origin": origin, "band": "custom", "kind": "custom"}


def cdf(model, year):
    t = year - model["origin"]
    if t <= 0:
        return 0.0
    return _N.cdf((math.log(t) - model["mu"]) / model["sigma"])


def quantile(model, p):
    return model["origin"] + math.exp(model["mu"] + _N.inv_cdf(p) * model["sigma"])


def scenarios(model):
    return {"early": round(quantile(model, 0.10)), "planning": round(quantile(model, 0.25)), "median": round(quantile(model, 0.50))}


# --- qubit ladder -------------------------------------------------------------
def logical_qubits(algorithm, params=""):
    a = (algorithm or "").upper()
    p = str(params or "").upper()
    import re
    m = re.search(r"(\d{3,5})", p)
    if a in ("RSA", "DH", "DSA", "ELGAMAL") and m:
        n = int(m.group(1))
        return 2 * n + 2, ("rsa" if a == "RSA" else "dh"), n
    curve_bits = None
    if a in ("ECDSA", "ECDH", "EC", "ECC"):
        for tag, bits in (("521", 521), ("384", 384), ("256", 256), ("224", 224), ("192", 192)):
            if tag in p:
                curve_bits = bits
                break
        curve_bits = curve_bits or 256
    elif a in ("X25519", "ED25519"):
        curve_bits = 255
    elif a in ("X448", "ED448"):
        curve_bits = 448
    if curve_bits:
        n = curve_bits
        return 9 * n + 2 * math.ceil(math.log2(n)) + 10, "ecc", n
    if a in ("RSA",):
        return 2 * 2048 + 2, "rsa", 2048
    return None


ANCHOR_Q = 2 * 2048 + 2


def shift_years(algorithm, params, doubling_years):
    q = logical_qubits(algorithm, params)
    if not q:
        return 0.0, None
    return round(doubling_years * math.log2(q[0] / ANCHOR_Q), 2), {"qubits": q[0], "family": q[1], "n": q[2]}


def ladder(doubling_years, model):
    rows = []
    for algo, params, label in (("ECDSA", "P-256", "ECC P-256 (ECDH / ECDSA)"), ("X25519", "", "X25519 / Ed25519"),
                                ("ECDSA", "P-384", "ECC P-384"), ("RSA", "2048", "RSA-2048"), ("ECDSA", "P-521", "ECC P-521"),
                                ("RSA", "3072", "RSA-3072"), ("RSA", "4096", "RSA-4096")):
        sh, q = shift_years(algo, params, doubling_years)
        rows.append({"label": label, "qubits": q["qubits"], "family": q["family"], "shift": sh,
                     "p25_year": round(quantile(model, 0.25) + sh, 1), "p50_year": round(quantile(model, 0.50) + sh, 1)})
    return rows


def model_from_policy(policy):
    q = policy.get("quantum") or {}
    if q.get("source") == "custom" and q.get("p10") and q.get("p50"):
        return fit_years(float(q["p10"]), float(q["p50"]))
    return fit_survey(q.get("band", "mid"))


def describe(policy):
    m = model_from_policy(policy)
    d = float((policy.get("quantum") or {}).get("doubling_years", DATA["doubling_years_default"]))
    curve = [{"year": y, "p": round(cdf(m, y), 4)} for y in range(2026, 2071)]
    bands = {}
    for b in BANDS:
        mb = fit_survey(b)
        bands[b] = {"curve": [{"year": y, "p": round(cdf(mb, y), 4)} for y in range(2026, 2071)], "scenarios": scenarios(mb)}
    return {"model": m, "scenarios": scenarios(m), "curve": curve, "ladder": ladder(d, m), "doubling_years": d, "bands": bands,
            "source": (policy.get("quantum") or {}).get("source", "survey"), "band": (policy.get("quantum") or {}).get("band", "mid"),
            "survey": SURVEY, "sources": DATA["logical_qubits"], "context": DATA["context"], "doubling_note": DATA["doubling_note"]}
