"""Shared data model: every detector emits Finding records with one schema."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field, asdict
from typing import Optional


@dataclass
class DataLink:
    source: str            # identifier or field the data came from, e.g. "aadhaar_number"
    data_class: str        # e.g. "AADHAAR"
    label: str             # human label, e.g. "Aadhaar number"
    lifetime_years: float  # required secrecy lifetime
    confidence: float      # 0..1
    reason: str            # why we believe this
    kind: str = "direct"   # direct | inter-procedural | shared-key | value-validated
    path: list = field(default_factory=list)  # ordered hops from the data to the crypto call

    def to_dict(self):
        return asdict(self)


@dataclass
class Finding:
    asset_type: str              # algorithm | certificate | key | protocol | library | hsm | cloud-kms
    algorithm: str               # canonical family, e.g. "RSA", "AES", "SHA-1"
    params: str = ""             # e.g. "2048", "ECB", "P-256"
    operation: str = ""          # keygen | encrypt | decrypt | sign | verify | kex | hash | mac | tls | link | store
    primitive: str = ""          # pke | signature | kem | block-cipher | hash | mac | key-agree | protocol | other
    location: str = ""           # relative path
    line: int = 0
    detector: str = ""           # python-ast | lexer-java | binary | cert | config | deps | ...
    evidence: str = ""           # snippet / symbol / reason
    confidence: float = 0.9
    evidence_type: str = ""      # what kind of proof backs this finding (set by the engine)
    evidence_strength: str = ""  # confirmed | strong | indicative
    language: str = ""
    exposure: str = "internal"   # external | internal
    context: str = ""            # function / module / route context
    data_links: list = field(default_factory=list)   # list[DataLink]
    extra: dict = field(default_factory=dict)
    # filled by risk engine
    risk: dict = field(default_factory=dict)
    recommendation: dict = field(default_factory=dict)

    @property
    def fid(self) -> str:
        key = f"{self.location}|{self.line}|{self.algorithm}|{self.params}|{self.operation}|{self.detector}"
        return hashlib.sha1(key.encode()).hexdigest()[:12]

    @property
    def display_name(self) -> str:
        if self.params == "HMAC":
            return f"HMAC-{self.algorithm}"
        if self.algorithm == "TLS" and self.params.upper().startswith(("TLSV", "SSLV")):
            return self.params.replace("TLSv", "TLS ").replace("SSLv", "SSL ")
        if self.algorithm == "TLS":
            return "TLS config"
        if self.params and self.params.startswith(self.algorithm):
            return self.params
        return f"{self.algorithm}-{self.params}" if self.params else self.algorithm

    def to_dict(self):
        d = asdict(self)
        d["id"] = self.fid
        d["name"] = self.display_name
        d["data_links"] = [dl if isinstance(dl, dict) else dl.to_dict() for dl in self.data_links]
        return d
