"""Collector: turns any input (folder, git URL, zip, single file, container image tar)
into a stream of virtual files, safely."""
from __future__ import annotations

import gzip
import io
import json
import os
import shutil
import subprocess
import tarfile
import tempfile
import zipfile
from pathlib import Path
from dataclasses import dataclass

SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "env", ".tox", "dist", "build", ".mypy_cache",
             ".pytest_cache", ".idea", ".vscode", "site-packages"}
MAX_TEXT = 2 * 1024 * 1024
MAX_BIN = 40 * 1024 * 1024


@dataclass
class VFile:
    path: str        # display path (relative, or image:layer/path)
    data: bytes
    origin: str      # "fs" | "container:<image>"


def _safe_member(name: str) -> bool:
    return not (name.startswith("/") or ".." in name.split("/"))


def iter_container(tar_bytes: bytes, label: str):
    """docker save / OCI archive -> files of every layer (no Docker daemon)."""
    outer = tarfile.open(fileobj=io.BytesIO(tar_bytes))
    names = outer.getnames()
    layers = []
    if "manifest.json" in names:
        man = json.load(outer.extractfile("manifest.json"))
        for entry in man:
            layers.extend(entry.get("Layers", []))
            label = (entry.get("RepoTags") or [label])[0]
    elif "index.json" in names:
        idx = json.load(outer.extractfile("index.json"))
        for m in idx.get("manifests", []):
            d = m["digest"].replace(":", "/")
            man = json.load(outer.extractfile(f"blobs/{d}"))
            layers.extend("blobs/" + l["digest"].replace(":", "/") for l in man.get("layers", []))
    for li, lname in enumerate(layers):
        raw = outer.extractfile(lname).read()
        if raw[:2] == b"\x1f\x8b":
            raw = gzip.decompress(raw)
        lt = tarfile.open(fileobj=io.BytesIO(raw))
        for m in lt.getmembers():
            if not m.isfile() or not _safe_member(m.name) or m.size > MAX_BIN:
                continue
            base = m.name.rsplit("/", 1)[-1]
            if base.startswith(".wh."):
                continue
            yield VFile(f"{label}!layer{li + 1}/{m.name}", lt.extractfile(m).read(), f"container:{label}")


def _safe_container(data: bytes, label: str):
    """A damaged image must not stop the scan: keep what was read and report the rest."""
    files = []
    try:
        for vf in iter_container(data, label):
            files.append(vf)
    except Exception as e:
        files.append(VFile(label, b"", f"error:container image could not be fully read ({type(e).__name__}: {e})"[:300]))
    yield from files


def is_container_tar(data: bytes) -> bool:
    try:
        t = tarfile.open(fileobj=io.BytesIO(data))
        n = t.getnames()
        return "manifest.json" in n or "index.json" in n
    except Exception:
        return False


def collect(target: str, work_dir: str | None = None):
    """Yield VFiles for a folder, file, zip, container tar, or git URL."""
    tmp = None
    if target.startswith(("http://", "https://", "git@")):
        tmp = tempfile.mkdtemp(prefix="scan-clone-", dir=work_dir)
        subprocess.run(["git", "clone", "--depth", "1", "--quiet", target, tmp], check=True, timeout=180)
        target = tmp
    if not os.path.exists(target):
        raise FileNotFoundError(f"scan target not found: {target}")
    try:
        if os.path.isfile(target):
            data = Path(target).read_bytes()
            base = os.path.basename(target)
            if zipfile.is_zipfile(target):
                with zipfile.ZipFile(target) as z:
                    for info in z.infolist():
                        if info.is_dir() or not _safe_member(info.filename) or info.file_size > MAX_BIN:
                            continue
                        if any(p in SKIP_DIRS for p in info.filename.split("/")):
                            continue
                        yield VFile(info.filename, z.read(info), "fs")
            elif base.endswith((".tar", ".tar.gz", ".tgz")) and is_container_tar(data):
                yield from _safe_container(data, base)
            else:
                yield VFile(base, data, "fs")
            return
        root = os.path.abspath(target)
        for dp, dns, fns in os.walk(root):
            dns[:] = [d for d in dns if d not in SKIP_DIRS]
            for fn in fns:
                full = os.path.join(dp, fn)
                rel = os.path.relpath(full, root).replace(os.sep, "/")
                try:
                    size = os.path.getsize(full)
                    if size > MAX_BIN or os.path.islink(full):
                        continue
                    data = Path(full).read_bytes()
                except OSError:
                    continue
                if fn.endswith(".tar") and is_container_tar(data):
                    yield from _safe_container(data, rel)
                    continue
                yield VFile(rel, data, "fs")
    finally:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
