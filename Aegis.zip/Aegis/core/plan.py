"""Migration plan: turns ranked findings into a phased, dated roadmap aligned to
India's DST quantum-safe roadmap for critical information infrastructure (CII)."""
from __future__ import annotations

import datetime

PHASES = [
    {"id": "P0", "name": "Stop the bleeding", "due": None, "due_label": "within 90 days",
     "goal": "Remove crypto that is broken today, expired certificates and vulnerable libraries."},
    {"id": "P1", "name": "Protect long-lived secrets", "due": "2027-12-31", "due_label": "by Dec 2027",
     "goal": "Move harvest-now-decrypt-later exposed data and public TLS to hybrid ML-KEM. Complete the CII crypto inventory (DST milestone)."},
    {"id": "P2", "name": "Migrate signatures and PKI", "due": "2028-12-31", "due_label": "by Dec 2028",
     "goal": "Move signing keys, certificates and long-validity signatures to ML-DSA / SLH-DSA (DST high-priority milestone)."},
    {"id": "P3", "name": "Complete and retire classical", "due": "2029-12-31", "due_label": "by Dec 2029",
     "goal": "Finish remaining quantum-vulnerable and weakened assets; retire legacy keys (DST full-adoption milestone)."},
]


def _owner(f):
    loc = f.location.lower()
    if f.asset_type in ("certificate",) or "cert" in loc:
        return "PKI / security team"
    if f.detector in ("config",) or loc.endswith((".conf", ".tf", "sshd_config")):
        return "Infra / DevOps"
    if f.detector == "binary" or "firmware" in loc:
        return "Firmware / embedded"
    if f.asset_type == "library":
        return "App team (dependencies)"
    if f.asset_type == "cloud-kms":
        return "Cloud platform"
    return "App team"


def build_plan(scan):
    today = datetime.date.today()
    p0_due = (today + datetime.timedelta(days=90)).isoformat()
    buckets = {p["id"]: [] for p in PHASES}
    for f in scan.findings:
        r = f.risk
        cls = r.get("class")
        if cls in ("safe",) or (cls == "inventory" and not (f.extra.get("advisory") or f.extra.get("advisories"))):
            continue
        if cls == "broken" or f.extra.get("expired") or f.extra.get("advisory") or f.extra.get("advisories"):
            ph = "P0"
        elif cls == "vulnerable" and r.get("usage") == "confidential" and (r.get("exposed") or f.exposure == "external"):
            ph = "P1"
        elif cls == "vulnerable" and r.get("usage") == "authentic":
            ph = "P2"
        else:
            ph = "P3"
        buckets[ph].append({
            "id": f.fid, "name": f.display_name, "operation": f.operation, "location": f.location, "line": f.line,
            "class": cls, "priority": r.get("priority", 0), "action": f.recommendation.get("summary", "Review"),
            "effort_years": r.get("Y"), "owner": _owner(f), "data": [d["label"] for d in f.data_links],
            "patchable": f.recommendation.get("patchable", False),
        })
    phases = []
    for p in PHASES:
        items = sorted(buckets[p["id"]], key=lambda x: -x["priority"])
        owners = {}
        for it in items:
            owners[it["owner"]] = owners.get(it["owner"], 0) + 1
        phases.append({**p, "due": p["due"] or p0_due, "items": items, "count": len(items),
                       "auto_fixable": sum(1 for i in items if i["patchable"]), "owners": owners})
    return {"generated": today.isoformat(), "start": today.isoformat(), "phases": phases,
            "note": "Deadlines follow the DST / National Quantum Mission quantum-safe roadmap for CII (inventory Dec 2027, "
                    "high-priority migration Dec 2028, full adoption Dec 2029)."}


def plan_markdown(scan, plan):
    lines = [f"# Post-quantum migration plan: {scan.label}", "", plan["note"], ""]
    for p in plan["phases"]:
        lines += [f"## {p['id']} · {p['name']} ({p['due_label']}, due {p['due']})", "", p["goal"], "",
                  "| Priority | Asset | Location | Action | Owner |", "| --- | --- | --- | --- | --- |"]
        for i in p["items"]:
            lines.append(f"| {i['priority']} | {i['name']} {i['operation']} | {i['location']}:{i['line']} | {i['action']} | {i['owner']} |")
        lines.append("")
    return "\n".join(lines)
