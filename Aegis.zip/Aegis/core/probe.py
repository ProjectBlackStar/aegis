"""Live endpoint check (opt-in, only for hosts the user types in).

1. Post-quantum readiness: sends a hand-built TLS 1.3 ClientHello offering the hybrid group X25519MLKEM768
   (IANA 0x11EC) with a real ML-KEM-768 + X25519 key share, then reads only the ServerHello. It never completes
   the handshake, so it works with any local TLS library version.
2. Classical facts: protocol, cipher and certificate chain from a normal TLS connection.
Everything is turned into ordinary findings, so a probe appears in the inventory, CBOM and plan like any scan."""
from __future__ import annotations

import os
import socket
import ssl
import struct
import subprocess
import shutil

from .model import Finding

GROUPS = {0x11EC: "X25519MLKEM768", 0x11EB: "SecP256r1MLKEM768", 0x11ED: "SecP384r1MLKEM1024", 0x001D: "x25519",
          0x0017: "secp256r1", 0x0018: "secp384r1", 0x0019: "secp521r1", 0x0200: "MLKEM512", 0x0201: "MLKEM768", 0x0202: "MLKEM1024",
          0x6399: "X25519Kyber768Draft00"}
HRR_RANDOM = bytes.fromhex("CF21AD74E59A6111BE1D8C021E65B891C2A211167ABB8C5E079E09E2C8A8339C")
ALERTS = {40: "handshake_failure", 47: "illegal_parameter", 70: "protocol_version", 71: "insufficient_security", 112: "unrecognized_name"}
CIPHERS13 = {0x1301: "TLS_AES_128_GCM_SHA256", 0x1302: "TLS_AES_256_GCM_SHA384", 0x1303: "TLS_CHACHA20_POLY1305_SHA256"}


def _ext(t, body):
    return struct.pack(">HH", t, len(body)) + body


def _hybrid_share():
    from kyber_py.ml_kem import ML_KEM_768
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
    ek, _dk = ML_KEM_768.keygen()
    x = X25519PrivateKey.generate().public_key().public_bytes_raw()
    return ek + x  # X25519MLKEM768 client share: ML-KEM-768 encapsulation key || X25519 public key


def client_hello(host):
    share = _hybrid_share()
    sni = host.encode()
    exts = b""
    if not _is_ip(host):
        exts += _ext(0x0000, struct.pack(">H", len(sni) + 3) + b"\x00" + struct.pack(">H", len(sni)) + sni)
    groups = [0x11EC, 0x001D, 0x0017, 0x0018]
    exts += _ext(0x000A, struct.pack(">H", 2 * len(groups)) + b"".join(struct.pack(">H", g) for g in groups))
    sigs = [0x0403, 0x0804, 0x0401, 0x0503, 0x0805, 0x0501, 0x0806, 0x0601, 0x0807, 0x0905, 0x0906, 0x0904]
    exts += _ext(0x000D, struct.pack(">H", 2 * len(sigs)) + b"".join(struct.pack(">H", s) for s in sigs))
    exts += _ext(0x002B, b"\x02\x03\x04")
    exts += _ext(0x002D, b"\x01\x01")
    ks = struct.pack(">HH", 0x11EC, len(share)) + share
    exts += _ext(0x0033, struct.pack(">H", len(ks)) + ks)
    body = b"\x03\x03" + os.urandom(32) + b"\x20" + os.urandom(32)
    body += struct.pack(">H", 6) + b"\x13\x01\x13\x02\x13\x03" + b"\x01\x00"
    body += struct.pack(">H", len(exts)) + exts
    hs = b"\x01" + struct.pack(">I", len(body))[1:] + body
    return b"\x16\x03\x01" + struct.pack(">H", len(hs)) + hs


def _is_ip(h):
    try:
        socket.inet_pton(socket.AF_INET6 if ":" in h else socket.AF_INET, h)
        return True
    except OSError:
        return False


def _recv_exact(s, n):
    buf = b""
    while len(buf) < n:
        chunk = s.recv(n - len(buf))
        if not chunk:
            break
        buf += chunk
    return buf


def pq_handshake(host, port=443, timeout=8.0):
    ch = client_hello(host)
    res = {"client_hello_bytes": len(ch), "offered": "X25519MLKEM768"}
    with socket.create_connection((host, port), timeout=timeout) as s:
        s.sendall(ch)
        hdr = _recv_exact(s, 5)
        if len(hdr) < 5:
            res.update({"result": "no-response", "detail": "connection closed without a reply"})
            return res
        ctype, _ver, ln = hdr[0], hdr[1:3], struct.unpack(">H", hdr[3:5])[0]
        body = _recv_exact(s, ln)
    if ctype == 0x15:
        desc = body[1] if len(body) > 1 else 0
        res.update({"result": "alert", "detail": f"server refused: {ALERTS.get(desc, desc)}", "pq": False, "tls13": desc != 70})
        return res
    if ctype != 0x16 or not body or body[0] != 0x02:
        res.update({"result": "unexpected", "detail": f"record type {ctype}", "pq": False})
        return res
    p = 4
    p += 2
    rnd = body[p:p + 32]
    p += 32
    sid_len = body[p]
    p += 1 + sid_len
    cipher = struct.unpack(">H", body[p:p + 2])[0]
    p += 3
    ext_len = struct.unpack(">H", body[p:p + 2])[0]
    p += 2
    end = p + ext_len
    version, group, share_len = None, None, None
    while p + 4 <= end:
        t, l = struct.unpack(">HH", body[p:p + 4])
        v = body[p + 4:p + 4 + l]
        if t == 0x002B and l >= 2:
            version = struct.unpack(">H", v[:2])[0]
        if t == 0x0033 and l >= 2:
            group = struct.unpack(">H", v[:2])[0]
            if l >= 4:
                share_len = struct.unpack(">H", v[2:4])[0]
        p += 4 + l
    hrr = rnd == HRR_RANDOM
    res.update({"tls13": version == 0x0304, "cipher": CIPHERS13.get(cipher, hex(cipher)),
                "selected_group": GROUPS.get(group, hex(group) if group else None), "server_share_bytes": share_len,
                "hello_retry": hrr})
    if version != 0x0304:
        res.update({"result": "tls12-only", "pq": False, "detail": "server answered with TLS 1.2 or older; no TLS 1.3, so no hybrid key exchange"})
    elif hrr:
        res.update({"result": "classical", "pq": False,
                    "detail": f"server supports TLS 1.3 but asked to retry with {GROUPS.get(group, group)}: no post-quantum key exchange"})
    elif group == 0x11EC:
        res.update({"result": "pq-hybrid", "pq": True, "detail": f"server accepted X25519MLKEM768 (server share {share_len} bytes)"})
    else:
        res.update({"result": "other", "pq": False, "detail": f"server selected {GROUPS.get(group, group)}"})
    return res


def classical(host, port=443, timeout=8.0):
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    out = {}
    with socket.create_connection((host, port), timeout=timeout) as raw:
        with ctx.wrap_socket(raw, server_hostname=None if _is_ip(host) else host) as s:
            out["version"] = s.version()
            out["cipher"] = s.cipher()[0]
            ders = []
            try:
                ders = [c.public_bytes(ssl.Encoding.DER) if hasattr(c, "public_bytes") else c for c in s._sslobj.get_unverified_chain()]
            except Exception:
                leaf = s.getpeercert(binary_form=True)
                ders = [leaf] if leaf else []
            out["chain_der"] = ders
    if len(out.get("chain_der", [])) <= 1 and shutil.which("openssl"):
        try:
            r = subprocess.run(["openssl", "s_client", "-connect", f"{host}:{port}", "-showcerts", "-servername", host],
                               input=b"", capture_output=True, timeout=timeout)
            import re
            pems = re.findall(rb"-----BEGIN CERTIFICATE-----.+?-----END CERTIFICATE-----", r.stdout, re.S)
            if len(pems) > 1:
                from cryptography import x509
                from cryptography.hazmat.primitives.serialization import Encoding
                out["chain_der"] = [x509.load_pem_x509_certificate(p).public_bytes(Encoding.DER) for p in pems]
        except Exception:
            pass
    return out


def probe(target):
    """target 'host[:port]'. Returns (findings, report)."""
    host, _, port = target.strip().rpartition(":") if target.count(":") == 1 else (target.strip(), "", "443")
    if not host:
        host, port = target.strip(), "443"
    port = int(port or 443)
    loc = f"{host}:{port}"
    report = {"host": host, "port": port}
    findings = []
    try:
        report["pq"] = pq_handshake(host, port)
    except Exception as e:
        report["pq"] = {"result": "error", "detail": f"{type(e).__name__}: {e}"}
    try:
        report["classical"] = cl = classical(host, port)
    except Exception as e:
        report["classical"] = cl = {"error": f"{type(e).__name__}: {e}"}
    pq = report["pq"]
    if pq.get("pq"):
        f = Finding(asset_type="protocol", algorithm="X25519MLKEM768", params="hybrid key exchange (live)", operation="kex",
                    primitive="kem", location=loc, line=0, detector="probe", evidence=pq["detail"], confidence=0.99,
                    language="tls", exposure="external")
        findings.append(f)
    elif pq.get("result") not in ("error", "no-response", None):
        f = Finding(asset_type="protocol", algorithm="TLS", params=(cl.get("version") or "TLS") + " classical key exchange",
                    operation="tls", primitive="protocol", location=loc, line=0, detector="probe",
                    evidence=pq.get("detail", ""), confidence=0.99, language="tls", exposure="external")
        f.extra["pq_probe"] = pq
        findings.append(f)
    if cl.get("version") in ("TLSv1", "TLSv1.1", "SSLv3"):
        findings.append(Finding(asset_type="protocol", algorithm="TLS", params=cl["version"].replace("TLSv1", "TLSv1.0") if cl["version"] == "TLSv1" else cl["version"],
                                operation="tls", primitive="protocol", location=loc, line=0, detector="probe",
                                evidence=f"server negotiated {cl['version']}", confidence=0.99, language="tls", exposure="external"))
    if cl.get("chain_der"):
        from .detectors.certs import scan_certs
        blob = b"".join(b"-----BEGIN CERTIFICATE-----\n" + __import__("base64").encodebytes(d) + b"-----END CERTIFICATE-----\n"
                        for d in cl["chain_der"])
        for f in scan_certs(loc, blob):
            f.detector = "probe"
            f.exposure = "external"
            f.evidence = "served by " + loc + ": " + f.evidence
            findings.append(f)
    for f in findings:
        f.extra["probe"] = {"pq": pq, "version": cl.get("version"), "cipher": cl.get("cipher")}
    return findings, report
