"""Risk engine.

For every asset: classical/quantum class, how it is used (confidentiality vs authenticity), Mosca's X / Y / Z,
the probability of exposure from the published arrival curve shifted by the algorithm's qubit requirement,
business criticality, and a 0-100 priority that is fully explained."""
from __future__ import annotations

import copy
import datetime
import fnmatch
import math

from .knowledge import classify_algorithm, DATA_CLASS_BY_ID
from . import quantum as Q

NOW = Q.now_year()

_MODEL0 = Q.fit_survey("mid")
DEFAULT_POLICY = {
    "quantum": {"source": "survey", "band": "mid", "doubling_years": Q.DATA["doubling_years_default"], "p10": None, "p50": None},
    "crqc": Q.scenarios(_MODEL0),
    "crqc_source": f"Fitted to {Q.SURVEY['title']} ({Q.SURVEY['authors']}, {Q.SURVEY['published']})",
    "default_lifetime": {"confidential": 5.0, "authentic": 1.0},
    "migration_factor": 1.0,
    "lifetimes": {},
    "migration_base": {"library": 0.5, "algorithm": 1.0, "protocol": 1.5, "certificate": 2.0, "key": 2.0,
                       "cloud-kms": 1.0, "hsm": 3.0, "firmware": 3.0},
    "criticality": [],      # [{"pattern": "digibank/kyc/*", "tier": "critical", "exposure": "external"|None, "note": ""}]
}

CONF_OPS = {"encrypt", "decrypt", "kex", "tls", "keygen", "keyload", "store"}
AUTH_OPS = {"sign", "verify"}
CRITICAL_HINTS = ("kyc", "aadhaar", "payment", "upi", "auth", "login", "esign", "vault", "card", "bank", "health")
TIER_POINTS = {"critical": 10, "high": 5, "normal": 0, "low": -10}
NON_RESIGNABLE = ("ESIGN", "CLASSIFIED")


def prepare(policy):
    """Normalises a policy and attaches the fitted arrival model (computed once per assessment run)."""
    p = copy.deepcopy(policy or DEFAULT_POLICY)
    for k, v in DEFAULT_POLICY.items():
        p.setdefault(k, copy.deepcopy(v))
    model = Q.model_from_policy(p)
    p["crqc"] = Q.scenarios(model)
    if p["quantum"].get("source") == "custom":
        p["crqc_source"] = "Custom: 10% and 50% years set by the user"
    else:
        p["crqc_source"] = f"Fitted to {Q.SURVEY['title']} ({p['quantum'].get('band', 'mid')} of the published ranges)"
    return p, model


def criticality(f, policy):
    """User rules first (glob on the path), then an automatic hint from names. Returns (tier, source, exposure override)."""
    for rule in policy.get("criticality") or []:
        pat = rule.get("pattern") or ""
        if pat and (fnmatch.fnmatch(f.location, pat) or f.location.startswith(pat.rstrip("*"))):
            return rule.get("tier", "normal"), f"rule '{pat}'", rule.get("exposure")
    ctx = (f.location + " " + f.context).lower()
    hit = next((h for h in CRITICAL_HINTS if h in ctx), None)
    if hit:
        return "high", f"automatic: name contains '{hit}'", None
    return "normal", "default", None


def _migration_years(f, policy, agility):
    base = policy["migration_base"]
    if f.detector == "binary" or "firmware" in f.location.lower():
        y, why = base["firmware"], "firmware / binary"
    else:
        y, why = base.get(f.asset_type, 1.0), f"{f.asset_type}"
    parts = [f"{why} {y:g} y"]
    if f.exposure == "external":
        y += 0.5
        parts.append("+0.5 y internet-facing (partners must move too)")
    mult = 1.0
    if agility:
        mult = 1 + (100 - agility["score"]) / 100
        parts.append(f"x{mult:.2f} crypto-agility {agility['score']}/100")
    mf = float(policy.get("migration_factor", 1.0))
    if mf != 1.0:
        parts.append(f"x{mf:g} organisation speed")
    return round(y * mult * mf, 2), "; ".join(parts)


def assess(f, policy=None, agility=None, model=None):
    if model is None:
        policy, model = prepare(policy)
    z = policy["crqc"]
    cls, reason = classify_algorithm(f.algorithm, f.params, f.operation)
    if f.asset_type == "library":
        adv = f.extra.get("advisories") or []
        if adv:
            cls, reason = "broken", f"{len(adv)} published advisor{'y' if len(adv) == 1 else 'ies'} affect this version"
        elif f.extra.get("advisory"):
            cls, reason = "broken", f.extra["advisory"]
        else:
            cls, reason = "inventory", f"Crypto library in use: provides {f.extra.get('provides', 'cryptography')}"
    if f.asset_type == "cloud-kms" and f.algorithm.startswith("Cloud KMS"):
        cls, reason = "vulnerable", "KMS key spec is defined outside the code; assume classical until verified"
    if f.algorithm in ("PKCS#11 HSM",):
        cls, reason = "inventory", "Hardware security module in use; its key types need inventory via the HSM"
    if f.asset_type == "certificate":
        sh = f.extra.get("signature_hash", "")
        if sh in ("SHA-1", "MD5"):
            cls, reason = "broken", f"Certificate signed with {sh}"
        if f.extra.get("expired"):
            reason += "; certificate is EXPIRED"
            cls = "broken"
    if f.algorithm in ("unparsed key material", "unparsed-binary", "encrypted keystore"):
        cls, reason = "inventory", f.extra.get("note") or "Could not be parsed; review manually"
    prof = f.extra.get("tls_profile") or {}
    if f.algorithm == "TLS" and f.params == "TLSv1.3" and prof.get("pq_groups"):
        cls, reason = "safe", ("TLS 1.3 with a post-quantum hybrid key exchange (" + ", ".join(prof["pq_groups"]) +
                               "); recorded traffic stays confidential. Certificates still authenticate classically.")
    if f.extra.get("eol"):
        cls, reason = "broken", f.extra["eol"]

    ku = f.extra.get("key_usage")
    if ku == "signature":
        usage = "authentic"
    elif ku in ("encryption", "key-establishment", "both"):
        usage = "confidential"
    else:
        usage = "authentic" if f.operation in AUTH_OPS or f.primitive == "signature" else (
            "confidential" if f.operation in CONF_OPS or f.primitive in ("pke", "kem", "key-agree", "protocol", "block-cipher", "stream-cipher") else "integrity")

    # X: how long the protected data must stay secret (or a signature must stay trusted)
    links = [d if isinstance(d, dict) else d.to_dict() for d in (f.data_links or [])]
    signed_note = ""
    resignable = True
    if usage == "authentic" and links:
        long_lived = [d for d in links if d["data_class"] in NON_RESIGNABLE]
        if not long_lived:
            signed_note = (f"; it signs {links[0]['label']} data, but a signature only needs to stay valid for the "
                           f"transaction/token lifetime (and does not hide the data)")
            links = []
        else:
            links = long_lived
            resignable = False
    if usage == "authentic" and ("firmware" in f.location.lower() or f.detector == "binary"):
        resignable = False
    if links:
        top = max(links, key=lambda d: d["lifetime_years"])
        X = top["lifetime_years"]
        x_reason = f"protects {top['label']} ({DATA_CLASS_BY_ID[top['data_class']]['category']}); inferred from '{top['source']}'"
        x_conf = top["confidence"]
    elif f.asset_type == "certificate" and f.extra.get("not_after"):
        na = datetime.datetime.fromisoformat(f.extra["not_after"])
        X = max(0.0, round(na.year + na.timetuple().tm_yday / 366 - NOW, 2))
        x_reason = "remaining certificate validity"
        x_conf = 0.95
        if f.extra.get("is_ca"):
            resignable = False
    else:
        X = policy["default_lifetime"]["authentic" if usage == "authentic" else "confidential"]
        x_reason = ("policy default for " + ("signature validity" if usage == "authentic" else "unclassified data")) + signed_note
        x_conf = 0.4 if not signed_note else 0.7
    Y, y_reason = _migration_years(f, policy, agility)

    tier, tier_src, _ = criticality(f, policy)
    out = {"class": cls, "reason": reason, "usage": usage, "X": X, "Y": Y, "x_reason": x_reason, "y_reason": y_reason,
           "x_confidence": round(x_conf, 2), "crqc": dict(z), "now": round(NOW, 2), "criticality": tier,
           "criticality_source": tier_src, "resignable": resignable}
    if agility:
        out["agility"] = agility

    if cls == "vulnerable":
        dbl = float(policy["quantum"].get("doubling_years", 2.0))
        shift, q = Q.shift_years(f.algorithm, f.params, dbl)
        horizon = NOW + Y + (X if (usage != "authentic" or not resignable) else 0)
        p_exp = Q.cdf(model, horizon - shift)
        overrun = {k: round(X + Y - (v + shift - NOW), 1) for k, v in z.items()}
        exposed = overrun["planning"] > 0
        out.update({
            "shift": shift, "qubits": q, "p_exposure": round(p_exp, 3),
            "p_basis": ("P(quantum computer for this algorithm arrives before " +
                        (f"migration ends and the data stops mattering, {horizon:.0f})" if usage != "authentic" or not resignable
                         else f"migration ends and keys are rotated, {horizon:.0f})")),
            "overrun": overrun, "exposed": exposed,
            "exposure_end": round(NOW + X + Y, 1),
            "migrate_by": round(z["planning"] + shift - X - Y, 1),
            "breach_year": round(z["planning"] + shift) if exposed else None,
            "hndl": usage == "confidential",
        })
        if usage == "confidential":
            out["story"] = (f"Data protected here must stay secret for {X:g} years and migration takes about {Y:g} years. "
                            f"Anyone recording it today can decrypt it once a quantum computer arrives; the chance that happens "
                            f"in time is {p_exp * 100:.0f}%.")
        else:
            out["story"] = (f"Signatures here must stay trustworthy {'for ' + format(X, 'g') + ' years' if not resignable else 'until keys are rotated'}. "
                            f"Forgery becomes possible once a quantum computer arrives; chance before migration ends: {p_exp * 100:.0f}%. "
                            f"No harvest-now risk.")
    elif cls == "broken":
        out.update({"exposed": True, "breach_year": int(NOW), "overrun": {k: 99 for k in z}, "exposure_end": round(NOW + X + Y, 1),
                    "migrate_by": round(NOW, 1), "p_exposure": 1.0, "shift": 0,
                    "story": reason + ". This is exploitable with classical computers now."})
    else:
        out.update({"exposed": False, "breach_year": None, "overrun": {k: 0 for k in z}, "exposure_end": round(NOW + X + Y, 1),
                    "migrate_by": None, "p_exposure": 0.0, "shift": 0, "story": reason})

    # priority 0..100, every part recorded
    parts = []
    base = {"broken": 80, "vulnerable": 45, "weakened": 25, "safe": 0, "inventory": 8}[cls]
    parts.append((f"{cls}", base))
    if cls == "vulnerable":
        pts = round(30 * out["p_exposure"])
        parts.append((f"{out['p_exposure'] * 100:.0f}% chance of exposure", pts))
    if links:
        pts = 10 if X >= 50 else (6 if X >= 10 else 0)
        if pts:
            parts.append((f"protects data needed for {X:g} years", pts))
    if f.exposure == "external":
        parts.append(("internet-facing", 8))
    if TIER_POINTS.get(tier):
        parts.append((f"{tier} system ({tier_src})", TIER_POINTS[tier]))
    if f.confidence < 0.6:
        parts.append(("low-confidence finding", -10))
    if cls == "broken" and f.operation == "hash" and links and X < 0.01:
        parts.append(("only protects short-lived data", -25))
        out["reason"] = reason + "; impact is limited because it only protects short-lived data"
    score = int(max(0, min(100, round(sum(p for _, p in parts)))))
    out["priority"] = score
    out["priority_parts"] = [{"why": w, "points": p} for w, p in parts]
    out["severity"] = "critical" if score >= 85 else "high" if score >= 65 else "medium" if score >= 40 else "low" if score > 0 else "none"
    return out
