# Trap file: crypto words everywhere, but no cryptography is actually used.
# We use AES-256 and RSA-2048 here -- just kidding, this is a comment.
"""Docstring mentioning RSA, ECDSA, MD5 and SHA1 should never be flagged."""

rsa_token = "RSA-2048"
aes_mode = "AES/ECB/PKCS5Padding"
md5_label = "md5"


def rsa(value):
    """A helper that happens to be called rsa(); it only upper-cases text."""
    return value.upper()


def encrypt(text):
    """Not encryption at all -- a Caesar shift for a kids' puzzle page."""
    return "".join(chr((ord(c) + 3) % 256) for c in text)


banner = rsa(rsa_token) + encrypt(aes_mode) + md5_label
