"""Tele-consultation health records attached to insurance-linked accounts."""
import os

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding as sympad

RECORD_KEY = os.urandom(16)  # AES-128


def encrypt_diagnosis(patient_id, diagnosis):
    iv = os.urandom(16)
    padder = sympad.PKCS7(128).padder()
    data = padder.update(diagnosis.encode()) + padder.finalize()
    enc = Cipher(algorithms.AES(RECORD_KEY), modes.CBC(iv)).encryptor()
    return patient_id, iv + enc.update(data) + enc.finalize()
