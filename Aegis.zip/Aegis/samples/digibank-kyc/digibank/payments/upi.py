"""UPI payment signing: every payment instruction is signed before it leaves the bank."""
import hashlib
import hmac
import json

from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes

GATEWAY_KEY = ec.generate_private_key(ec.SECP256R1())
PSP_SHARED_SECRET = b"demo-psp-secret"


def sign_payment(upi_vpa, account_number, amount):
    txn = json.dumps({"vpa": upi_vpa, "acct": account_number, "amt": amount}).encode()
    signature = GATEWAY_KEY.sign(txn, ec.ECDSA(hashes.SHA256()))
    return txn, signature


def psp_checksum(transaction):
    """Legacy PSP integration still expects an HMAC-SHA1 checksum."""
    return hmac.new(PSP_SHARED_SECRET, transaction, hashlib.sha1).hexdigest()
