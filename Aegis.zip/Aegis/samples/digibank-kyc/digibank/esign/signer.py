"""eSign: loan agreements are digitally signed and must stay verifiable for decades."""
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes

ESIGN_KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)


def sign_agreement(loan_agreement):
    return ESIGN_KEY.sign(loan_agreement, padding.PKCS1v15(), hashes.SHA256())
