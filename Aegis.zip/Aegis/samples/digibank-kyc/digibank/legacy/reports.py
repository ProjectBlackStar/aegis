"""Legacy nightly report export (written in 2014, still running)."""
import hashlib

from Crypto.Cipher import DES

REPORT_KEY = b"8bytekey"


def export_statement(account_number, statement_text):
    cipher = DES.new(REPORT_KEY, DES.MODE_ECB)
    padded = statement_text.ljust((len(statement_text) // 8 + 1) * 8).encode()
    return cipher.encrypt(padded)


def file_checksum(path):
    with open(path, "rb") as fh:
        return hashlib.md5(fh.read()).hexdigest()
