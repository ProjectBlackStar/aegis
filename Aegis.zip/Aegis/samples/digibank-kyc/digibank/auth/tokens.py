"""Session tokens for the mobile app."""
import jwt

JWT_SIGNING_KEY = open("/etc/digibank/jwt_rs256.pem").read() if False else "dev-key"


def issue_token(customer_id, pan_number):
    payload = {"sub": customer_id, "pan": pan_number}
    return jwt.encode(payload, JWT_SIGNING_KEY, algorithm="RS256")
