"""OTP verification for login."""
import hashlib
import time


def hash_otp(otp_code, session_id):
    # OTPs live for 5 minutes; we only store a digest of them.
    return hashlib.sha1(f"{otp_code}:{session_id}".encode()).hexdigest()


def otp_expired(issued_at, ttl=300):
    return time.time() - issued_at > ttl
