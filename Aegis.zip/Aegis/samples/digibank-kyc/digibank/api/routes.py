"""Public REST API (Flask)."""
from flask import Flask, request, jsonify

from digibank.kyc import aadhaar_vault
from digibank.payments import upi

app = Flask(__name__)


@app.route("/api/kyc/enroll", methods=["POST"])
def enroll():
    body = request.get_json()
    aadhaar_vault.store_citizen(body["customer_id"], body["aadhaar_number"], body["full_name"])
    return jsonify({"status": "enrolled"})


@app.route("/api/pay", methods=["POST"])
def pay():
    body = request.get_json()
    txn, sig = upi.sign_payment(body["upi_vpa"], body["account_number"], body["amount"])
    return jsonify({"txn": txn.decode(), "sig": sig.hex()})
