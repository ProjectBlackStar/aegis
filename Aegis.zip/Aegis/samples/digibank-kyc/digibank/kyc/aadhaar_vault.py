"""Aadhaar vault: stores citizens' Aadhaar numbers encrypted at rest (e-KYC flow)."""
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes

# Vault key pair, generated at service start (demo). In production loaded from HSM.
VAULT_KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)

_DB = {}


def store_citizen(customer_id, aadhaar_number, full_name):
    """Encrypt the Aadhaar number with the vault public key and persist it."""
    blob = aadhaar_number.encode()
    ciphertext = VAULT_KEY.public_key().encrypt(
        blob,
        padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None),
    )
    _DB[customer_id] = {"name": full_name, "aadhaar_ct": ciphertext}
    return ciphertext


def read_aadhaar(customer_id):
    record = _DB[customer_id]
    plain = VAULT_KEY.decrypt(
        record["aadhaar_ct"],
        padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None),
    )
    return plain.decode()
