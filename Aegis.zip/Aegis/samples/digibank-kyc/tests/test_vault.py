import unittest

from digibank.kyc import aadhaar_vault


class VaultTest(unittest.TestCase):
    def test_round_trip(self):
        aadhaar_vault.store_citizen("C1", "234123412346", "Asha Rao")
        self.assertEqual(aadhaar_vault.read_aadhaar("C1"), "234123412346")

    def test_ciphertext_hides_value(self):
        ct = aadhaar_vault.store_citizen("C2", "987654321098", "Ravi K")
        self.assertNotIn(b"987654321098", ct)


if __name__ == "__main__":
    unittest.main()
