package in.digibank.gateway;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.Signature;

/** Card-network gateway. // Cipher.getInstance("RC4") in a comment is not a finding. */
public class PaymentGateway {
    private static final String NOTE = "Cipher.getInstance(\"DES\") inside a string is not a finding";
    private String rsa_token = "RSA";

    public byte[] encryptCardNumber(byte[] cardNumber, java.security.Key key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(cardNumber);
    }

    public java.security.KeyPair merchantKeys() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        return kpg.generateKeyPair();
    }

    public byte[] signSettlement(byte[] settlement, java.security.PrivateKey pk) throws Exception {
        Signature s = Signature.getInstance("SHA256withECDSA");
        s.initSign(pk);
        s.update(settlement);
        return s.sign();
    }

    public byte[] legacyDigest(byte[] data) throws Exception {
        return MessageDigest.getInstance("SHA-1").digest(data);
    }

    public byte[] partnerMac(byte[] data, javax.crypto.SecretKey k) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(k);
        return mac.doFinal(data);
    }
}
