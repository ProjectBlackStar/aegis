# Keys in AWS KMS used by the KYC and statements services
resource "aws_kms_key" "kyc_documents" {
  description              = "Encrypts customer KYC documents"
  customer_master_key_spec = "RSA_2048"
  key_usage                = "ENCRYPT_DECRYPT"
}

resource "aws_kms_key" "statement_signing" {
  description              = "Signs monthly account statements"
  customer_master_key_spec = "ECC_NIST_P256"
  key_usage                = "SIGN_VERIFY"
}

resource "aws_kms_key" "backups" {
  description              = "Envelope key for nightly backups"
  customer_master_key_spec = "SYMMETRIC_DEFAULT"
}
