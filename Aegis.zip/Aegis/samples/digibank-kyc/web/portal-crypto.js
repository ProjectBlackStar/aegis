// Customer web portal helpers (Node.js)
const crypto = require('crypto');
const forge = require('node-forge');

// crypto.createHash('md5') in a comment must be ignored
const label = "createCipheriv('des-ecb') is just text here";

function encryptPanForDisplay(panNumber, key, iv) {
  const cipher = crypto.createCipheriv('aes-128-cbc', key, iv);
  return cipher.update(panNumber, 'utf8', 'hex') + cipher.final('hex');
}

function sessionFingerprint(sessionId) {
  return crypto.createHash('md5').update(sessionId).digest('hex');
}

function signReceipt(receipt, privateKeyPem) {
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(receipt);
  return signer.sign(privateKeyPem, 'base64');
}

function newDeviceKeys() {
  return crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
}

function legacyKeys() {
  return forge.pki.rsa.generateKeyPair({ bits: 1024 });
}

module.exports = { encryptPanForDisplay, sessionFingerprint, signReceipt, newDeviceKeys, legacyKeys, label };
