package branch

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha1"
)

// BranchKey issues the key used by branch terminals to authenticate to the core bank.
func BranchKey() (*rsa.PrivateKey, error) {
	return rsa.GenerateKey(rand.Reader, 2048)
}

// ReceiptID derives a short receipt id.
func ReceiptID(receipt []byte) [20]byte {
	return sha1.Sum(receipt)
}
