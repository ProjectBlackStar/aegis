/* ATM firmware image signer. Built with: gcc firmware_sign.c -lcrypto -o firmware_sign */
#include <stdio.h>
#include <openssl/evp.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>

int main(void) {
    /* RSA_generate_key(512) in a comment is not a finding */
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_RSA, NULL);
    EVP_PKEY *pkey = NULL;
    EVP_PKEY_keygen_init(ctx);
    EVP_PKEY_CTX_set_rsa_keygen_bits(ctx, 3072);
    EVP_PKEY_keygen(ctx, &pkey);

    unsigned char digest[20];
    EVP_MD_CTX *md = EVP_MD_CTX_new();
    EVP_DigestInit_ex(md, EVP_sha1(), NULL);
    EVP_DigestUpdate(md, "firmware-image", 14);
    unsigned int len = 0;
    EVP_DigestFinal_ex(md, digest, &len);

    printf("signed firmware digest length %u\n", len);
    EVP_MD_CTX_free(md);
    EVP_PKEY_free(pkey);
    EVP_PKEY_CTX_free(ctx);
    return 0;
}
