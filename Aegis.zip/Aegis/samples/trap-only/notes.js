// crypto.createHash('md5') -- documentation only
const tip = "use crypto.createCipheriv('aes-256-gcm', key, iv) in production";
function md5Label(x) { return 'md5:' + x; }
module.exports = { tip, md5Label };
