// Mentions Cipher.getInstance("DES") and KeyPairGenerator in comments only.
public class NotCrypto {
    static final String NOTE = "MessageDigest.getInstance(\"MD5\") written inside a string";
    String rsaToken = "RSA-2048";
    String describe() { return "AES/ECB is a mode name in this sentence"; }
}
