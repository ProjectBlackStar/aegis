"""Precision / recall of detection against hand-labelled ground truth.
Run from the project folder:  python bench/score.py"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path[:0] = [ROOT, os.path.join(ROOT, "vendor")]
from core.engine import Scan  # noqa: E402


def score():
    gt = json.load(open(os.path.join(HERE, "ground_truth.json")))
    rows = []
    for name, c in gt["corpora"].items():
        path = c["path"] if os.path.isabs(c["path"]) else os.path.join(ROOT, c["path"])
        if not os.path.exists(path):
            rows.append({"corpus": name, "skipped": "not present on this machine"})
            continue
        s = Scan(path).run()
        found = {f"{f.location}:{f.line}" for f in s.findings if f.asset_type != "library" and f.line}
        truth = set(c["truth"])
        tp, fp, fn = found & truth, found - truth, truth - found
        rows.append({"corpus": name, "set": c.get("set", ""), "origin": c["origin"], "truth": len(truth), "found": len(found), "tp": len(tp),
                     "fp": sorted(fp), "fn": sorted(fn),
                     "precision": round(len(tp) / len(found), 3) if found else (1.0 if not truth else 0.0),
                     "recall": round(len(tp) / len(truth), 3) if truth else 1.0,
                     "expected_miss": c.get("expected_miss", {})})
    return rows


if __name__ == "__main__":
    for r in score():
        print(json.dumps(r, indent=1))
