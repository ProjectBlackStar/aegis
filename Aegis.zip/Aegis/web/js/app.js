/* Aegis app shell: state, routing, navigation, search, detail panel, guidance. */
"use strict";

const S = {
  brand: { name: "Aegis" }, scanId: null, summary: null, findings: [], quantum: null, history: [], sources: null,
  filter: {}, guide: true, plan: null, lastPatch: null,
};

const ROUTES = [
  { id: "start", label: "New scan", ic: "scan", group: null, needs: false },
  { id: "overview", label: "Overview", ic: "overview", group: null, needs: true },
  { id: "inventory", label: "Inventory", ic: "list", group: 1, needs: true },
  { id: "data", label: "Data at risk", ic: "flow", group: 2, needs: true },
  { id: "quantum", label: "Quantum timeline", ic: "horizon", group: 2, needs: true },
  { id: "systems", label: "Systems", ic: "systems", group: 2, needs: true },
  { id: "recommend", label: "Replacements", ic: "swap", group: 3, needs: true },
  { id: "fix", label: "Fix and verify", ic: "wrench", group: 3, needs: true },
  { id: "plan", label: "Migration plan", ic: "plan", group: 3, needs: true },
  { id: "exports", label: "Reports and CBOM", ic: "export", group: 3, needs: true },
  { id: "compare", label: "Compare scans", ic: "compare", group: "foot", needs: false },
  { id: "sources", label: "Data sources", ic: "source", group: "foot", needs: false },
  { id: "policy", label: "Policy", ic: "sliders", group: "foot", needs: false },
];
const GROUPS = { 1: "Discover", 2: "Link and assess", 3: "Migrate and prove" };
const VIEWS = {};

function buildRail() {
  const rail = $("#rail");
  rail.innerHTML = "";
  rail.append(h("div", { class: "mark" },
    h("span", { html: '<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M16 3 5 7.5v7.8C5 22.2 9.7 27.4 16 29c6.3-1.6 11-6.8 11-13.7V7.5z" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"/><path d="M9.5 18.5c2.2 0 2.8-7 6.5-7s4.3 7 6.5 7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>' }),
    h("div", null, h("b", null, S.brand.name), h("span", null, S.brand.tagline || ""))));
  let lastGroup = null;
  const foot = h("div", { class: "rail-foot" });
  for (const r of ROUTES) {
    if (r.group && r.group !== "foot" && r.group !== lastGroup) {
      rail.append(h("div", { class: "stage" }, h("i", null, r.group), h("b", null, GROUPS[r.group])));
      lastGroup = r.group;
    }
    const disabled = r.needs && !S.scanId;
    const count = r.id === "inventory" && S.findings.length ? h("span", { class: "count" }, S.findings.length)
      : r.id === "fix" && S.findings.length ? h("span", { class: "count" }, S.findings.filter((f) => f.recommendation.patchable).length) : null;
    const b = h("button", { class: "nav-item", "data-route": r.id, disabled, title: disabled ? "Run a scan first" : null,
      onclick: () => go(r.id) }, icon(r.ic), r.label, count);
    (r.group === "foot" ? foot : rail).append(b);
  }
  const theme = document.documentElement.dataset.theme === "dark";
  foot.append(h("button", { class: "nav-item", id: "themeBtn", onclick: toggleTheme }, icon(theme ? "sun" : "moon"), theme ? "Light theme" : "Dark theme"));
  foot.append(h("div", { class: "offline", title: "Aegis makes no internet requests except a live endpoint check you start yourself" }, "Running offline on this machine"));
  rail.append(foot);
  markNav();
}
function markNav() {
  const cur = location.hash.slice(2) || "start";
  $$(".nav-item[data-route]").forEach((b) => b.toggleAttribute("aria-current", false));
  const b = $(`.nav-item[data-route="${cur.split("?")[0]}"]`);
  if (b) b.setAttribute("aria-current", "page");
}
function toggleTheme() {
  const d = document.documentElement;
  d.dataset.theme = d.dataset.theme === "dark" ? "light" : "dark";
  try { localStorage.setItem("aegis-theme", d.dataset.theme); } catch (e) { /* storage unavailable */ }
  buildRail();
  render();
}

function go(id, params) {
  const q = params ? "?" + new URLSearchParams(params).toString() : "";
  if (location.hash === `#/${id}${q}`) render(); else location.hash = `#/${id}${q}`;
}
function routeParams() {
  const [, q] = (location.hash.slice(2) || "").split("?");
  return Object.fromEntries(new URLSearchParams(q || ""));
}
function render() {
  const [id] = (location.hash.slice(2) || "start").split("?");
  const r = ROUTES.find((x) => x.id === id) || ROUTES[0];
  const v = $("#view");
  TT.hide();
  if (r.needs && !S.scanId) { location.hash = "#/start"; return; }
  v.innerHTML = "";
  v.classList.remove("enter"); void v.offsetWidth; v.classList.add("enter");
  $("#crumb").innerHTML = "";
  $("#crumb").append(S.summary ? h("span", null, h("b", null, S.summary.label), " · " + r.label) : h("b", null, r.label));
  if (S.summary && S.summary.archived && r.needs) {
    v.append(h("div", { class: "note warn row", style: "margin-bottom:16px" }, h("span", { style: "flex:1" }, "Opened from history, so it is read-only. Scan again to change the policy, build the plan or generate fixes."),
      h("button", { class: "btn s", onclick: () => go("start", { rescan: S.summary.target, label: S.summary.label }) }, icon("scan"), "Scan again")));
  }
  try { (VIEWS[r.id] || VIEWS.start)(v, routeParams()); } catch (e) { console.error(e); v.append(h("div", { class: "note bad" }, "This screen failed to draw: " + e.message)); }
  markNav();
  window.scrollTo({ top: 0 });
}
window.addEventListener("hashchange", () => {
  $("#palette").hidden = true;
  if ($("#drawer").classList.contains("on")) { $("#drawer").classList.remove("on"); $("#scrim").classList.remove("on"); }
  $$(".term-pop").forEach((p) => p.remove());
  render();
});

/* ---- guidance: one line per screen saying what you see and what to do next ---- */
function guide(text, next, detail) {
  const g = h("div", { class: "guide" }, icon("info"), h("div", { style: "display:grid;gap:4px" }, h("p", null, text), detail ? h("p", { class: "small detail-line" }, detail) : null));
  if (next) g.append(h("button", { class: "btn s guide-next", onclick: () => go(next.to) }, next.label, icon("arrow")));
  if (!S.guide) g.hidden = true;
  return g;
}
function head(title, lede, ...actions) {
  return h("div", { class: "head" }, h("div", { style: "flex:1;min-width:280px" }, h("h2", null, title), lede ? h("p", { class: "lede" }, lede) : null), ...actions);
}

/* ---- scan lifecycle ---- */
async function loadScan(id) {
  const r = await api(`/api/scan/${id}`);
  if (r.pending) return false;
  S.scanId = id; S.summary = r.summary; S.findings = r.findings; S.plan = null;
  S.quantum = await api(`/api/quantum?scan=${id}`);
  buildRail();
  return true;
}
async function applyPolicy(body) {
  if (S.summary.archived) { toast("This scan is from an earlier session. Scan again to change its policy."); return; }
  const r = await api(`/api/scan/${S.scanId}/policy`, { method: "POST", body });
  S.summary = r.summary; S.findings = r.findings; S.plan = null;
  S.quantum = await api(`/api/quantum?scan=${S.scanId}`);
  const d = r.summary.exposed - r.before.exposed;
  toast(d === 0 ? "Policy applied. Exposure unchanged." : `Policy applied. ${Math.abs(d)} ${d > 0 ? "more" : "fewer"} assets exposed.`);
  render();
}
const byId = (id) => S.findings.find((f) => f.id === id);

/* ---- search (Ctrl K) ---- */
function openPalette() {
  const p = $("#palette"), inp = $("#palInput"), list = $("#palList");
  p.hidden = false; inp.value = ""; inp.focus();
  let sel = 0, items = [];
  const draw = () => {
    const q = inp.value.trim().toLowerCase();
    const screens = ROUTES.filter((r) => !r.needs || S.scanId).map((r) => ({ t: r.label, sub: "Screen", run: () => go(r.id) }));
    const assets = S.findings.map((f) => ({ t: `${f.name} ${f.operation}`, sub: `${fmt.where(f)}${f.data_links.length ? " · " + f.data_links.map((d) => d.label).join(", ") : ""}`, run: () => openFinding(f.id) }));
    items = [...screens, ...assets].filter((i) => !q || (i.t + " " + i.sub).toLowerCase().includes(q)).slice(0, 40);
    sel = Math.min(sel, Math.max(0, items.length - 1));
    list.innerHTML = "";
    if (!items.length) list.append(h("div", { class: "empty" }, "Nothing matches. Try an algorithm (RSA), a file name or a data type (Aadhaar)."));
    items.forEach((it, i) => list.append(h("div", { class: "pal-item", role: "option", "aria-selected": i === sel ? "true" : "false",
      onclick: () => { close(); it.run(); } }, h("span", null, it.t), h("small", null, it.sub))));
  };
  const close = () => { p.hidden = true; document.removeEventListener("keydown", key, true); };
  const key = (e) => {
    if (p.hidden) { document.removeEventListener("keydown", key, true); return; }
    if (e.key === "Escape") { close(); e.preventDefault(); }
    else if (e.key === "ArrowDown") { sel = Math.min(items.length - 1, sel + 1); draw(); e.preventDefault(); }
    else if (e.key === "ArrowUp") { sel = Math.max(0, sel - 1); draw(); e.preventDefault(); }
    else if (e.key === "Enter" && items[sel]) { close(); items[sel].run(); e.preventDefault(); }
  };
  inp.oninput = () => { sel = 0; draw(); };
  p.onclick = (e) => { if (e.target === p) close(); };
  document.addEventListener("keydown", key, true);
  draw();
}

/* ---- detail panel ---- */
function closeDrawer() {
  $("#drawer").classList.remove("on"); $("#scrim").classList.remove("on"); $("#drawer").inert = true;
  if (S._lastFocus) S._lastFocus.focus();
}
function openFinding(id, tab) {
  const f = byId(id);
  if (!f) return;
  S._lastFocus = document.activeElement;
  const d = $("#drawer");
  d.innerHTML = "";
  const r = f.risk;
  const tabs = [["why", "Why it matters"], ["flow", "Data flow"], ["evidence", "Evidence"], ["fix", "How to fix"]];
  if (f.recommendation.tls_cost || f.extra.tls_cost) tabs.push(["cost", "Handshake cost"]);
  if ((f.extra.advisories || []).length) tabs.push(["adv", "Advisories"]);
  if (f.extra.tls_profile) tabs.push(["tls", "TLS profile"]);
  const body = h("div", { class: "drawer-body" });
  const tabBar = h("div", { class: "tabs", role: "tablist" }, tabs.map(([k, t]) => h("button", { role: "tab", "data-k": k, onclick: () => show(k) }, t)));
  d.append(h("div", { class: "drawer-head" },
    h("button", { class: "btn ghost s x", onclick: closeDrawer, "aria-label": "Close" }, icon("x")),
    h("div", { class: "row" }, prio(r.priority), status(r.class), f.data_links.map((x) => h("span", { class: "chip data" }, x.label)),
      h("span", { class: "chip" }, f.exposure === "external" ? "internet-facing" : "internal"),
      r.criticality && r.criticality !== "normal" ? h("span", { class: `chip tier-${r.criticality}` }, `${r.criticality} system`) : null),
    h("h2", null, `${f.name} `, h("span", { class: "muted", style: "font-weight:400" }, f.operation)),
    h("div", { class: "where" }, fmt.where(f), f.context ? `  ·  ${f.context}` : ""), tabBar), body);
  const show = (k) => {
    $$("button[role=tab]", tabBar).forEach((b) => b.setAttribute("aria-selected", b.dataset.k === k));
    body.innerHTML = "";
    body.append(...DRAWER[k](f));
  };
  show(tab && tabs.some((t) => t[0] === tab) ? tab : "why");
  d.inert = false;
  d.classList.add("on"); $("#scrim").classList.add("on");
  setTimeout(() => $(".x", d).focus(), 50);
}

const DRAWER = {
  why(f) {
    const r = f.risk, out = [];
    out.push(h("p", { class: `story ${r.class}` }, r.story));
    out.push(h("div", { class: "mosca" },
      h("div", null, h("span", null, term("X")), h("b", null, fmt.yrs(r.X)), h("span", null, r.x_reason)),
      h("div", null, h("span", null, term("Y")), h("b", null, fmt.yrs(r.Y)), h("span", null, r.y_reason || "")),
      h("div", null, h("span", null, term("Z")), h("b", null, r.crqc.planning + (r.shift ? (r.shift > 0 ? " +" : " ") + r.shift.toFixed(1) : "")), h("span", null, r.shift ? `planning year ${r.crqc.planning}, shifted for this algorithm (${term("ladder").textContent})` : "planning year: 25% chance")),
      h("div", null, h("span", null, term("pexp")), h("b", null, r.class === "vulnerable" ? fmt.pct(r.p_exposure) : r.class === "broken" ? "now" : "–"),
        h("span", null, r.class === "vulnerable" ? (r.usage === "confidential" ? "harvest-now risk: yes" : "signature: no harvest risk") : STATUS[r.class].note))));
    out.push(h("h4", { style: "margin:18px 0 8px" }, "Why priority ", r.priority));
    out.push(h("div", { class: "parts" }, (r.priority_parts || []).map((p) => h("div", null, h("span", null, p.why), h("span", null, (p.points > 0 ? "+" : "") + p.points))),
      h("div", null, h("span", null, "Priority (0–100)"), h("span", null, r.priority))));
    out.push(h("dl", { class: "kv", style: "margin-top:18px" },
      h("dt", null, "Used for"), h("dd", null, r.usage === "authentic" ? "signatures / authentication" : r.usage === "confidential" ? "encryption / key exchange" : "integrity", f.extra.key_usage_source ? h("span", { class: "faint" }, `  (${f.extra.key_usage_source})`) : null),
      h("dt", null, term("criticality", "Criticality")), h("dd", null, `${r.criticality}  `, h("span", { class: "faint" }, r.criticality_source)),
      r.agility ? [h("dt", null, term("agility", "Crypto-agility")), h("dd", null, `${r.agility.score}/100  `, h("span", { class: "faint" }, r.agility.parts.map((p) => p.why).join("; ") || "no penalties"))] : null,
      f.extra.note ? [h("dt", null, "Note"), h("dd", null, f.extra.note)] : null,
      h("dt", null, "Reason"), h("dd", null, r.reason)));
    return out;
  },
  flow(f) {
    if (!f.data_links.length) return [h("div", { class: "empty" }, icon("flow"), h("p", null, "No sensitive data was traced to this call."),
      h("p", { class: "small" }, "Aegis links data only when it can follow it from a variable or value into the crypto call. Without a link, X uses the policy default."))];
    return f.data_links.map((d) => h("div", { style: "margin-bottom:22px" },
      h("div", { class: "row", style: "margin-bottom:10px" }, h("span", { class: "chip data" }, d.label), h("span", { class: "chip" }, d.kind.replace("-", " ")), h("span", { class: "faint small" }, `confidence ${Math.round(d.confidence * 100)}%`)),
      h("div", { class: "chart" }, flowPath(d.path || [], f)),
      h("p", { class: "small muted", style: "margin-top:10px" }, d.reason)));
  },
  evidence(f) {
    const box = h("div", null, h("p", { class: "muted" }, "Loading the source…"));
    const out = [h("dl", { class: "kv", style: "margin-bottom:16px" },
      h("dt", null, term("evidence", "Evidence")), h("dd", null, `${f.evidence_strength} · ${f.evidence_type}`),
      h("dt", null, "Found by"), h("dd", null, f.detector),
      h("dt", null, "What it saw"), h("dd", { class: "mono small" }, f.evidence)), box];
    if (S.summary.archived || f.detector === "probe" || !f.line) { box.innerHTML = ""; box.append(h("p", { class: "faint small" }, f.detector === "probe" ? "Observed on the live endpoint; there is no source file." : "No source excerpt for this item.")); return out; }
    api(`/api/scan/${S.scanId}/source?path=${encodeURIComponent(f.location)}&line=${f.line}`).then((src) => {
      box.innerHTML = "";
      if (!src.lines.length) { box.append(h("p", { class: "faint small" }, "Source not available (binary, archive or container file).")); return; }
      box.append(h("pre", { class: "code" }, src.lines.map((l, i) => h("div", { class: src.start + i === f.line ? "hit" : "" }, h("span", { class: "ln" }, src.start + i), l))));
    }).catch(() => { box.innerHTML = ""; box.append(h("p", { class: "faint small" }, "Source not available.")); });
    return out;
  },
  fix(f) {
    const rec = f.recommendation, out = [];
    if (rec.note) out.push(h("p", { class: "note warn", style: "margin-bottom:12px" }, rec.note));
    if (!rec.options.length) return [h("div", { class: "empty" }, icon("check"), h("p", null, rec.summary || "No change needed."))];
    rec.options.forEach((o, i) => {
      const sizes = [];
      const cur = rec.current_sizes || {};
      const pairs = [["Public key", cur.pk, o.pk], [o.sig ? "Signature" : "Ciphertext", o.sig ? cur.sig : cur.ct, o.sig || o.ct]].filter((p) => p[2]);
      const mx = Math.max(...pairs.flatMap((p) => [p[1] || 0, p[2]]));
      pairs.forEach(([lab, a, b]) => {
        if (a) sizes.push(h("div", null, h("span", null, `${lab} today`), h("i", { class: "now", style: { width: `${(a / mx) * 100}%` } }), h("span", null, fmt.bytes(a))));
        sizes.push(h("div", null, h("span", null, `${lab} new`), h("i", { style: { width: `${(b / mx) * 100}%` } }), h("span", null, fmt.bytes(b))));
      });
      out.push(h("div", { class: `opt ${i === 0 ? "best" : ""}` },
        h("div", { class: "row" }, h("h4", null, o.name), i === 0 ? h("span", { class: "chip" }, "recommended") : null, h("span", { class: "faint small", style: "margin-left:auto" }, o.standard || "")),
        h("p", { class: "muted" }, o.why), o.use ? h("p", { class: "small" }, h("b", null, "For: "), o.use) : null,
        sizes.length ? h("div", { class: "sizes" }, sizes) : null,
        o.compat ? h("p", { class: "small note ok" }, o.compat) : null,
        (o.constraints || []).length ? h("ul", null, o.constraints.map((c) => h("li", null, c))) : null));
    });
    if (rec.patchable) out.push(h("div", { class: "row", style: "margin-top:16px" }, h("button", { class: "btn primary", onclick: () => { closeDrawer(); go("fix", { id: f.id }); } }, icon("wrench"), "Generate and verify a fix"),
      h("span", { class: "faint small" }, "Works on a copy; your files are not changed.")));
    return out;
  },
  cost(f) {
    const c = f.recommendation.tls_cost || f.extra.tls_cost;
    return [h("p", { class: "muted", style: "margin-bottom:12px" }, `Server's first handshake flight for this certificate chain (${c.chain_certs} certificates, ${fmt.bytes(c.chain_bytes_today)} today${c.assumed_intermediate ? ", intermediate assumed the same size" : ""}). Bars past the line need an extra round trip on a new connection.`),
      h("div", { class: "chart" }, costChart(c)),
      h("p", { class: "small muted", style: "margin-top:12px" }, `Real ClientHello sizes: ${c.client_hello.classical_median} B classical, ${c.client_hello.pq_median} B with X25519MLKEM768 (median of current clients). ${c.client_hello.pq_clients.length} of ${c.client_hello.current_clients} current clients already send the hybrid group.`),
      h("p", { class: "srcline" }, `${c.limits.tcp_source}. QUIC: ${c.limits.quic_source}. Clients: ${c.client_hello.source}.`)];
  },
  adv(f) {
    const a = f.extra.advisories;
    return [h("p", { class: "muted", style: "margin-bottom:12px" }, `${a.length} published advisories affect ${f.name}. Upgrade to ${f.extra.upgrade_to || "the latest release"} to clear them.`),
      h("table", { class: "t" }, h("thead", null, h("tr", null, h("th", null, "Advisory"), h("th", null, "Severity"), h("th", null, "Published"), h("th", null, "Summary"))),
        h("tbody", null, a.map((x) => h("tr", { style: "cursor:default" }, h("td", { class: "mono small" }, x.id, x.cve.length ? h("div", { class: "faint" }, x.cve.join(", ")) : null), h("td", null, x.severity.toLowerCase()), h("td", null, x.published), h("td", { class: "small" }, x.summary))))),
      h("p", { class: "srcline" }, `${f.extra.advisory_source}; snapshot ${(f.extra.advisory_snapshot || "").split(" ").slice(1).join(" ")}`)];
  },
  tls(f) {
    const p = f.extra.tls_profile;
    return [h("dl", { class: "kv" },
      h("dt", null, "Verdict"), h("dd", null, h("b", null, p.verdict), `  (Mozilla guidelines ${p.mozilla_version})`),
      h("dt", null, "Protocols"), h("dd", null, p.protocols.join(", ") || "not set"),
      h("dt", null, "Key exchange groups"), h("dd", null, p.groups.join(", ") || "library default", p.pq_groups.length ? h("span", { class: "st safe", style: "margin-left:8px" }, icon("safe"), "post-quantum hybrid offered") : h("span", { class: "faint" }, `  · Mozilla recommends ${p.mozilla_intermediate_groups.slice(0, 2).join(", ")}`)),
      h("dt", null, "Static RSA suites"), h("dd", null, p.static_rsa.join(", ") || "none"),
      h("dt", null, "Outside Mozilla intermediate"), h("dd", null, p.outside_mozilla_intermediate.join(", ") || "none")),
      p.suites.length ? h("table", { class: "t", style: "margin-top:16px" }, h("thead", null, h("tr", null, h("th", null, "Suite (IANA)"), h("th", null, "Key exchange"), h("th", null, "Cipher"))),
        h("tbody", null, p.suites.map((c) => h("tr", { style: "cursor:default" }, h("td", { class: "mono small" }, c.iana || c.openssl, h("div", { class: "faint" }, c.hex)), h("td", null, c.kx.replace("kx-", "")), h("td", null, c.enc))))) : null,
      h("p", { class: "srcline" }, "Suites expanded with this machine's TLS library and named from the IANA registry (testssl.sh data).")];
  },
};

/* ---- boot ---- */
async function boot() {
  try { const t = localStorage.getItem("aegis-theme"); if (t) document.documentElement.dataset.theme = t; } catch (e) { /* default light */ }
  try { const g = localStorage.getItem("aegis-guide"); if (g === "off") S.guide = false; } catch (e) { /* default on */ }
  document.body.classList.toggle("guide-on", S.guide);
  S.brand = await api("/api/brand").catch(() => S.brand);
  document.title = S.brand.name;
  $("#guideBtn").setAttribute("aria-pressed", S.guide);
  $("#guideBtn").onclick = () => {
    S.guide = !S.guide;
    document.body.classList.toggle("guide-on", S.guide);
    $("#guideBtn").setAttribute("aria-pressed", S.guide);
    try { localStorage.setItem("aegis-guide", S.guide ? "on" : "off"); } catch (e) { /* ignore */ }
    $$(".guide").forEach((g) => (g.hidden = !S.guide));
  };
  $("#searchBtn").onclick = openPalette;
  $("#scrim").onclick = closeDrawer;
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); openPalette(); }
    if (e.key === "Escape" && $("#drawer").classList.contains("on")) closeDrawer();
  });
  const last = (() => { try { return localStorage.getItem("aegis-last-scan"); } catch (e) { return null; } })();
  if (last) { try { await loadScan(last); } catch (e) { /* not available any more */ } }
  buildRail();
  render();
}
document.addEventListener("DOMContentLoaded", boot);
