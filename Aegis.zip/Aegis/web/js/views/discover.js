/* Start (scan / live check / history), Overview, Inventory. */
"use strict";

/* ================= START ================= */
VIEWS.start = function (v, params = {}) {
  const left = h("div", null);
  const right = h("div", { class: "stack" });
  v.append(h("div", { class: "hero-q" },
    h("h1", null, "Which of your encryption breaks first, and when?"),
    h("p", null, `${S.brand.name} finds every algorithm, key, certificate and protocol in code, binaries, containers and configs, traces the data each one protects, and dates its quantum risk from published expert data. It runs entirely on this machine.`)));
  v.append(h("div", { class: "start" }, left, right));

  const tabs = [["samples", "Sample projects"], ["path", "Folder or Git repository"], ["upload", "Upload a file"], ["probe", "Live endpoint"]];
  const tabBar = h("div", { class: "tabs", role: "tablist" });
  const pane = h("div");
  const panel = h("div", { class: "panel" }, tabBar, pane);
  const prog = h("div", { class: "panel", hidden: true });
  left.append(panel, prog);
  tabs.forEach(([k, t]) => tabBar.append(h("button", { role: "tab", "data-k": k, onclick: () => show(k) }, t)));
  function show(k) {
    $$("button", tabBar).forEach((b) => b.setAttribute("aria-selected", b.dataset.k === k));
    pane.innerHTML = "";
    PANES[k]();
  }
  const PANES = {
    async samples() {
      const list = h("div", { class: "targets" }, h("p", { class: "muted" }, "Loading samples…"));
      pane.append(list);
      const ss = await api("/api/samples");
      list.innerHTML = "";
      const meta = {
        "digibank-kyc": ["folder", "DigiBank KYC (sample bank)", "Python, Java, JS, C, Go, a firmware binary, certificates, keystores, nginx / HAProxy / SSH / Kubernetes / Terraform configs"],
        "digibank-image.tar": ["box", "DigiBank container image", "A docker-save archive, read layer by layer without Docker"],
        "trap-only": ["file", "False-alarm trap", "Crypto words in names, comments and strings only. A correct scanner reports nothing."],
      };
      ss.forEach((x) => {
        const [ic, name, desc] = meta[x.name] || ["folder", x.name, x.desc];
        list.append(h("button", { class: "target", "data-id": x.id, onclick: () => start({ target: x.id, label: name }) },
          icon(ic), h("div", null, h("b", null, name), h("span", null, desc)), icon("play")));
      });
    },
    path() {
      const inp = h("input", { class: "input", placeholder: "/path/to/project  or  https://github.com/org/repo", id: "pathIn" });
      pane.append(h("div", { class: "stack", style: "gap:12px" },
        h("label", { class: "field" }, "Folder on this machine, or a public Git URL", inp),
        h("div", { class: "row" }, h("button", { class: "btn primary", onclick: () => inp.value.trim() ? start({ target: inp.value.trim() }) : toast("Enter a folder path or Git URL") }, icon("scan"), "Scan"),
          h("span", { class: "faint small" }, "Git URLs are cloned once (shallow); everything else stays local."))));
      inp.addEventListener("keydown", (e) => e.key === "Enter" && inp.value.trim() && start({ target: inp.value.trim() }));
      setTimeout(() => inp.focus(), 30);
    },
    upload() {
      const fi = h("input", { type: "file", hidden: true, onchange: () => fi.files[0] && upload(fi.files[0]) });
      const drop = h("div", { class: "drop", tabindex: 0, role: "button", onclick: () => fi.click(), onkeydown: (e) => e.key === "Enter" && fi.click() },
        icon("upload"), h("p", null, h("b", null, "Drop a file here"), " or choose one"),
        h("p", { class: "small" }, "A zip of source code, a container image (.tar), a compiled binary, a certificate, a keystore (.p12 / .jks) or a config file."));
      drop.querySelector("svg").style.cssText = "width:28px;height:28px";
      ["dragenter", "dragover"].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.add("over"); }));
      ["dragleave", "drop"].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.remove("over"); }));
      drop.addEventListener("drop", (e) => e.dataTransfer.files[0] && upload(e.dataTransfer.files[0]));
      pane.append(drop, fi);
    },
    probe() {
      const ta = h("textarea", { class: "input", rows: 3, placeholder: "netbanking.example.in\napi.example.in:8443", id: "probeIn" });
      pane.append(h("div", { class: "stack", style: "gap:12px" },
        h("p", { class: "muted" }, "Checks whether a server already offers post-quantum key exchange (X25519MLKEM768), and records its TLS version, cipher and certificate chain."),
        h("label", { class: "field" }, "Hosts, one per line (host or host:port)", ta),
        h("div", { class: "row" }, h("button", { class: "btn primary", onclick: () => probeStart(ta.value) }, icon("globe"), "Check endpoints")),
        h("p", { class: "note warn" }, "This is the only feature that uses the network. Only check servers you are allowed to test.")));
    },
  };
  show("samples");
  if (params.rescan) setTimeout(() => start({ target: params.rescan.startsWith("/") && params.rescan.includes("/samples/") ? "sample:" + params.rescan.split("/samples/")[1] : params.rescan, label: params.label }), 50);

  async function upload(file) {
    const fd = new FormData();
    fd.append("file", file);
    try { const r = await api("/api/upload", { method: "POST", body: fd }); follow(r.id, file.name); } catch (e) { toast(e.message); }
  }
  async function start(body) {
    try { const r = await api("/api/scan", { method: "POST", body }); follow(r.id, body.label || body.target); } catch (e) { toast(e.message); }
  }
  async function probeStart(text) {
    const targets = text.split(/[\s,]+/).map((x) => x.trim()).filter(Boolean);
    if (!targets.length) return toast("Enter at least one host");
    try { const r = await api("/api/probe", { method: "POST", body: { targets } }); follow(r.id, targets.join(", ")); } catch (e) { toast(e.message); }
  }

  /* live pipeline: real progress from the engine */
  function follow(id, label) {
    panel.hidden = true; prog.hidden = false; prog.innerHTML = "";
    const steps = [["collect", "Collect files", "folders, archives, image layers"], ["detect", "Detect crypto", "7 detectors"], ["link", "Trace data", "which data reaches which key"],
      ["assess", "Assess risk", "Mosca, survey curve, qubit ladder"], ["done", "Ready", ""]];
    const els = {};
    prog.append(h("header", null, h("h3", null, "Scanning ", label)), h("div", { class: "pipe" }, steps.map(([k, t, w]) => {
      els[k] = { row: h("div", { class: "pipe-step" }, h("div", { class: "pipe-dot" }, icon("check")), h("div", null, h("b", null, t), h("div", { class: "what" }, w), h("div", { class: "ticker" })), h("div", { class: "num" })) };
      return els[k].row;
    })));
    const set = (k, st) => { els[k].row.className = `pipe-step ${st}`; };
    const tick = async () => {
      let st;
      try { st = await api(`/api/scan/${id}/status`); } catch (e) { prog.append(h("p", { class: "note bad" }, e.message)); return; }
      const p = st.progress;
      if (st.status === "scanning") {
        set("collect", "doing"); set("detect", "doing");
        $(".num", els.collect.row).textContent = fmt.n(p.files) + " files";
        $(".num", els.detect.row).textContent = fmt.n(p.findings) + " found";
        $(".ticker", els.collect.row).textContent = p.current || "";
      }
      if (st.status === "analysing") { set("collect", "done"); set("detect", "done"); set("link", "doing"); set("assess", "doing"); }
      if (st.status === "error") { prog.append(h("p", { class: "note bad", style: "margin-top:12px" }, `The scan stopped: ${st.error}`), h("button", { class: "btn", onclick: () => render() }, "Try again")); return; }
      if (st.status === "done") {
        ["collect", "detect", "link", "assess", "done"].forEach((k) => set(k, "done"));
        $(".num", els.collect.row).textContent = fmt.n(p.files) + (label.includes(".") && !label.includes("/") && p.files === 1 ? " file" : " files");
        $(".num", els.detect.row).textContent = fmt.n(p.findings) + " found";
        $(".ticker", els.collect.row).textContent = "";
        $(".what", els.done.row).textContent = `${st.elapsed}s`;
        await loadScan(id);
        try { localStorage.setItem("aegis-last-scan", id); } catch (e) { /* ignore */ }
        setTimeout(() => go("overview"), 650);
        return;
      }
      setTimeout(tick, 250);
    };
    tick();
  }

  /* history */
  const hist = h("div", { class: "hist" }, h("p", { class: "muted" }, "Loading…"));
  right.append(h("div", { class: "panel" }, h("header", null, h("h3", null, "Recent scans"), h("p", null, "Kept on this machine")), hist));
  api("/api/history").then((rows) => {
    S.history = rows;
    hist.innerHTML = "";
    if (!rows.length) { hist.append(h("p", { class: "faint" }, "Nothing yet. Your scans will be listed here, and you can compare any two.")); return; }
    rows.slice(0, 8).forEach((r) => {
      const sm = r.summary || {};
      hist.append(h("div", { class: "hist-row" },
        h("button", { class: "link", onclick: async () => { await loadScan(r.id); try { localStorage.setItem("aegis-last-scan", r.id); } catch (e) { /* ignore */ } go("overview"); } }, r.label),
        h("span", { class: "faint small" }, fmt.date(r.started)),
        h("span", { class: "small muted" }, `${fmt.plural(sm.total || 0, "asset")} · ${(sm.classes || {}).broken || 0} broken · ${(sm.classes || {}).vulnerable || 0} vulnerable`),
        h("span", null)));
    });
    if (rows.length > 1) hist.append(h("button", { class: "btn s", style: "margin-top:10px;justify-self:start", onclick: () => go("compare") }, icon("compare"), "Compare two scans"));
  }).catch(() => { hist.innerHTML = ""; hist.append(h("p", { class: "faint" }, "History is not available.")); });

  right.append(h("div", { class: "panel" }, h("header", null, h("h3", null, "What it looks at")),
    h("dl", { class: "kv" },
      h("dt", null, "Source code"), h("dd", null, "Python (with data-flow), Java, JavaScript / TypeScript, C / C++, Go"),
      h("dt", null, "Binaries"), h("dd", null, "Linux ELF: linked crypto libraries, symbols, algorithm constants"),
      h("dt", null, "Containers"), h("dd", null, "docker-save / OCI archives, every layer"),
      h("dt", null, "Keys and certificates"), h("dd", null, "PEM, DER, OpenSSH, PKCS#12, Java keystores, Kubernetes secrets"),
      h("dt", null, "Configuration"), h("dd", null, "nginx, Apache, HAProxy, OpenSSL, SSH, Kubernetes ingress, Terraform / cloud KMS"),
      h("dt", null, "Dependencies"), h("dd", null, "pip, npm, Maven, Gradle, Go, Cargo, RubyGems, NuGet, checked against 458 advisories"))));
};

/* ================= OVERVIEW ================= */
VIEWS.overview = function (v) {
  const F = S.findings, sm = S.summary, q = S.quantum, now = F[0] ? F[0].risk.now : 2026.75;
  const vul = F.filter((f) => f.risk.class === "vulnerable");
  // per data class: highest exposure probability and longest window
  const dc = {};
  // only data a quantum computer could actually expose: encrypted data (harvest now, decrypt later) and signatures that
  // cannot be re-issued; broken crypto only where the data lives longer than a year
  const counts = (f) => (f.risk.usage !== "authentic" || f.risk.resignable === false);
  vul.filter(counts).concat(F.filter((f) => f.risk.class === "broken" && counts(f))).forEach((f) => f.data_links.forEach((d) => {
    if (f.risk.class === "broken" && d.lifetime_years < 1) return;
    const e = dc[d.label] || (dc[d.label] = { label: d.label, n: 0, p: 0, end: now, why: "", cls: f.risk.class, life: d.lifetime_years });
    e.n++;
    const p = f.risk.class === "broken" ? 1 : f.risk.p_exposure;
    if (p >= e.p) { e.p = p; e.cls = f.risk.class === "broken" ? "broken" : "vulnerable"; }
    const end = now + f.risk.Y + d.lifetime_years;
    if (end > e.end) { e.end = end; e.why = `${fmt.yrs(d.lifetime_years)} ${f.risk.usage === "authentic" ? "signature validity" : "secrecy"} + ${fmt.yrs(f.risk.Y)} migration`; }
  }));
  const rows = Object.values(dc).sort((a, b) => b.end - a.end).map((r) => ({ ...r, onclick: () => go("inventory", { data: r.label }) }));
  const unl = vul.filter((f) => !f.data_links.length && f.risk.usage === "confidential");
  if (unl.length) {
    const p = Math.max(...unl.map((f) => f.risk.p_exposure));
    rows.push({ label: "Other encrypted data", n: unl.length, p, end: now + Math.max(...unl.map((f) => f.risk.X + f.risk.Y)), why: "no data type traced; policy default", cls: "vulnerable", onclick: () => go("inventory", { status: "vulnerable" }) });
  }
  const top = rows[0];
  const advLibs = F.filter((f) => (f.extra.advisories || []).length);
  const advCount = advLibs.reduce((a, f) => a + f.extra.advisories.length, 0);

  v.append(guide("This is the whole picture on one screen. The curve is the chance a quantum computer exists by each year; each bar below is how long a kind of data must stay secret. The darker part of a bar is the time it would stay sensitive after the planning year.",
    { to: "inventory", label: "See every asset" }));
  v.append(h("div", { class: "verdict" },
    h("div", null,
      h("h1", null, top ? `${top.label} encrypted today has a ${Math.round(top.p * 100)}% chance of being readable while it still matters.` : sm.total ? "No sensitive data was traced to quantum-vulnerable crypto." : "No cryptography was found in this target."),
      h("p", { class: "sub" }, `Planning year ${q.scenarios.planning}: a 1-in-4 chance a quantum computer can break RSA-2048 by then, from the curve fitted to the `, term("Z", "Global Risk Institute 2025 survey"), `. Elliptic-curve crypto is expected about ${Math.abs(q.ladder[0].shift).toFixed(1)} years earlier (`, term("ladder", "qubit ladder"), ").")),
    h("div", { class: "bigyear" }, h("b", null, q.scenarios.planning), h("span", null, "planning year"))));
  if (rows.length) v.append(h("div", { class: "horizon chart" }, horizonChart(q, rows, now)));

  const fig = (n, cls, word, d, to) => h("button", { class: "figure", onclick: () => go("inventory", to) }, h("b", null, fmt.n(n)), status(cls), h("span", { class: "d" }, d));
  v.append(h("div", { class: "figures" },
    fig((sm.classes || {}).broken || 0, "broken", "", "exploitable with ordinary computers now", { status: "broken" }),
    fig((sm.classes || {}).vulnerable || 0, "vulnerable", "", "RSA, ECC and DH that Shor's algorithm breaks", { status: "vulnerable" }),
    h("button", { class: "figure", onclick: () => go("data") }, h("b", null, sm.data_linked), h("span", { class: "st" }, icon("flow"), "Traced to sensitive data"), h("span", { class: "d" }, "crypto calls whose data Aegis followed")),
    h("button", { class: "figure", onclick: () => go("inventory", { type: "library" }) }, h("b", null, advCount), h("span", { class: "st broken" }, icon("broken"), "Library advisories"), h("span", { class: "d" }, `${advLibs.length} libraries with published fixes pending`))));

  const fix = h("div", { class: "fixlist" });
  F.slice(0, 7).forEach((f) => fix.append(h("div", { class: "fixrow", tabindex: 0, role: "button", onclick: () => openFinding(f.id), onkeydown: (e) => e.key === "Enter" && openFinding(f.id) },
    prio(f.risk.priority),
    h("div", { class: "t" }, h("div", null, h("b", null, f.name), " ", h("span", { class: "muted" }, f.operation), f.data_links.length ? h("span", { class: "chip data", style: "margin-left:8px" }, f.data_links[0].label) : null),
      h("div", { class: "where" }, fmt.where(f)), h("div", { class: "why" }, f.recommendation.summary ? `Fix: ${f.recommendation.summary}` : f.risk.reason)),
    status(f.risk.class, true))));
  const safe = F.filter((f) => f.risk.class === "safe");
  const side = h("div", { class: "stack" });
  const dl = h("div");
  Object.values(dc).sort((a, b) => b.life - a.life).forEach((d) => dl.append(h("div", { class: "datarow" },
    h("b", null, d.label), h("span", { class: "small muted" }, `${d.n} use${d.n === 1 ? "" : "s"} · secret for ${fmt.yrs(d.life)}`),
    h("div", { class: "meter", title: `${Math.round(d.p * 100)}% chance of exposure` }, h("i", { style: { width: `${Math.round(d.p * 100)}%`, background: `var(--${d.cls})` } })))));
  side.append(h("div", { class: "panel" }, h("header", null, h("h3", null, "Sensitive data at quantum risk"), h("p", null, "bar = chance of exposure")), dl.childNodes.length ? dl : h("p", { class: "faint" }, "No data types traced.")));
  side.append(h("div", { class: "panel" }, h("header", null, h("h3", null, "Already quantum-safe")),
    safe.length ? h("div", null, safe.slice(0, 5).map((f) => h("div", { class: "datarow", style: "cursor:pointer", onclick: () => openFinding(f.id) }, h("span", null, f.name), status("safe", true), h("span", { class: "where", style: "grid-column:1/-1" }, fmt.where(f)))))
      : h("p", { class: "faint" }, "Nothing yet. A TLS server with X25519MLKEM768, or AES-256 / SHA-256, would show here.")));
  v.append(h("div", { class: "grid-main" }, h("div", { class: "panel" }, h("header", null, h("h3", null, "Fix first"), h("p", null, "highest priority; click for the reasoning")), fix,
    h("button", { class: "btn s", style: "margin-top:12px", onclick: () => go("plan") }, icon("plan"), "Open the migration plan")), side));
  v.append(h("p", { class: "srcline" }, `${fmt.plural(sm.files, "file")} scanned in ${sm.duration}s${sm.cache_hits ? ` (${sm.cache_hits} unchanged files reused)` : ""}. `,
    h("a", { href: "#/sources" }, "Data sources and snapshot dates")));
};

/* ================= INVENTORY ================= */
VIEWS.inventory = function (v, params) {
  const F = S.findings;
  const st = { q: params.q || "", sort: "priority", dir: -1, sel: {} };
  if (params.status) st.sel.status = new Set([params.status]);
  if (params.data) st.sel.data = new Set([params.data]);
  if (params.type) st.sel.type = new Set([params.type]);
  const facetDefs = [
    ["status", "Status", (f) => [STATUS[f.risk.class].word]],
    ["data", "Protects", (f) => f.data_links.length ? f.data_links.map((d) => d.label) : ["Nothing traced"]],
    ["type", "Asset type", (f) => [f.asset_type]],
    ["src", "Found in", (f) => [({ "python-ast": "Python code", "lexer-java": "Java code", "lexer-js": "JS / TS code", "lexer-c": "C / C++ code", "lexer-go": "Go code", binary: "Binaries", cert: "Certificates and keys", keystore: "Keystores", config: "Configuration", deps: "Dependencies", probe: "Live endpoints" })[f.detector] || f.detector]],
    ["evidence", "Evidence", (f) => [f.evidence_strength || "–"]],
    ["crit", "Criticality", (f) => [f.risk.criticality || "normal"]],
  ];
  if (params.status) st.sel.status = new Set([STATUS[params.status] ? STATUS[params.status].word : params.status]);
  v.append(guide("Every cryptographic asset found, highest priority first. Filter on the left, search by algorithm, file or data type, and click a row for the full reasoning, the data flow, the evidence and the fix.", { to: "data", label: "Trace the data" }));
  v.append(head("Inventory", `${fmt.plural(F.length, "asset")} in ${fmt.plural(S.summary.files, "file")}.`,
    h("button", { class: "btn", onclick: () => download(`/api/scan/${S.scanId}/cbom`) }, icon("export"), "Download CBOM")));
  const facets = h("div", { class: "facets", "aria-label": "Filters" });
  const tbody = h("tbody");
  const search = h("input", { class: "input", placeholder: "Search: RSA, aadhaar, nginx.conf…", value: st.q, "aria-label": "Search assets" });
  const count = h("span", { class: "faint small" });
  const clear = h("button", { class: "btn ghost s", onclick: () => { st.sel = {}; st.q = ""; search.value = ""; drawFacets(); draw(); } }, "Clear filters");
  const cols = [["priority", "Priority"], ["name", "Asset"], ["where", "Where"], ["data", "Protects"], ["status", "Status"], ["p", "Exposure"], ["evidence", "Evidence"]];
  const thead = h("thead", null, h("tr", null, cols.map(([k, t]) => h("th", null, ["priority", "name", "where", "p"].includes(k)
    ? h("button", { onclick: () => { st.dir = st.sort === k ? -st.dir : (k === "name" || k === "where" ? 1 : -1); st.sort = k; draw(); }, "data-k": k }, t) : t))));
  v.append(h("div", { class: "inv" }, facets, h("div", { class: "tablewrap" }, h("div", { class: "toolbar" }, search, count, h("div", { class: "grow" }), clear),
    h("div", { style: "overflow-x:auto" }, h("table", { class: "t" }, thead, tbody)))));
  search.addEventListener("input", () => { st.q = search.value; draw(); });

  function pass(f, skip) {
    for (const [k, , fn] of facetDefs) {
      if (k === skip || !st.sel[k] || !st.sel[k].size) continue;
      if (!fn(f).some((x) => st.sel[k].has(x))) return false;
    }
    if (st.q) {
      const hay = `${f.name} ${f.algorithm} ${f.params} ${f.operation} ${f.location} ${f.data_links.map((d) => d.label + " " + d.source).join(" ")} ${f.risk.class}`.toLowerCase();
      if (!st.q.toLowerCase().split(/\s+/).every((w) => hay.includes(w))) return false;
    }
    return true;
  }
  function drawFacets() {
    facets.innerHTML = "";
    for (const [k, title, fn] of facetDefs) {
      const counts = {};
      F.filter((f) => pass(f, k)).forEach((f) => fn(f).forEach((x) => (counts[x] = (counts[x] || 0) + 1)));
      const all = new Set(F.flatMap(fn));
      const box = h("div", null, h("h5", null, title));
      [...all].sort((a, b) => (counts[b] || 0) - (counts[a] || 0)).forEach((x) => {
        const cb = h("input", { type: "checkbox", checked: st.sel[k] && st.sel[k].has(x) });
        cb.onchange = () => { st.sel[k] = st.sel[k] || new Set(); cb.checked ? st.sel[k].add(x) : st.sel[k].delete(x); draw(); drawFacets(); };
        box.append(h("label", { class: "check" }, cb, h("span", null, x), h("span", { class: "n" }, counts[x] || 0)));
      });
      facets.append(box);
    }
  }
  function draw() {
    const key = { priority: (f) => f.risk.priority, name: (f) => f.name.toLowerCase(), where: (f) => fmt.where(f), p: (f) => (f.risk.class === "broken" ? 2 : f.risk.p_exposure || 0) };
    const rows = F.filter((f) => pass(f)).sort((a, b) => { const x = key[st.sort](a), y = key[st.sort](b); return (x > y ? 1 : x < y ? -1 : 0) * st.dir; });
    $$("th button", thead).forEach((b) => b.dataset.k === st.sort ? b.setAttribute("aria-sort", st.dir > 0 ? "ascending" : "descending") : b.removeAttribute("aria-sort"));
    count.textContent = rows.length === F.length ? `${rows.length} assets` : `${rows.length} of ${F.length}`;
    clear.disabled = !st.q && !Object.values(st.sel).some((x) => x.size);
    tbody.innerHTML = "";
    if (!rows.length) { tbody.append(h("tr", null, h("td", { colspan: 7 }, h("div", { class: "empty" }, "No assets match these filters.", h("button", { class: "btn s", onclick: () => clear.click() }, "Clear filters"))))); return; }
    rows.forEach((f) => {
      const p = f.risk.class === "vulnerable" ? f.risk.p_exposure : f.risk.class === "broken" ? 1 : null;
      tbody.append(h("tr", { tabindex: 0, onclick: () => openFinding(f.id), onkeydown: (e) => e.key === "Enter" && openFinding(f.id) },
        h("td", null, prio(f.risk.priority)),
        h("td", null, h("b", null, f.name), " ", h("span", { class: "muted" }, f.operation)),
        h("td", null, h("span", { class: "where" }, fmt.where(f))),
        h("td", null, f.data_links.map((d) => h("span", { class: "chip data", style: "margin:0 4px 4px 0" }, d.label))),
        h("td", null, status(f.risk.class, true)),
        h("td", null, p == null ? h("span", { class: "faint" }, "–") : h("div", { class: "pbar" }, h("span", null, f.risk.class === "broken" ? "now" : fmt.pct(p)), h("i", { style: `--p:${Math.round(p * 100)}%` }))),
        h("td", { class: "small muted" }, f.evidence_strength)));
    });
  }
  drawFacets();
  draw();
};
