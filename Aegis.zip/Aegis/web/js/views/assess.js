/* Data at risk, Quantum timeline, Systems (criticality + agility). */
"use strict";

VIEWS.data = function (v) {
  const F = S.findings;
  const linked = F.filter((f) => f.data_links.length);
  v.append(guide("Left: the kinds of sensitive data Aegis followed through the code. Right: the crypto calls that protect them, coloured by status. A line means the data really reaches that call; names alone never create a link.",
    { to: "quantum", label: "See the quantum timeline" }));
  v.append(head("Data at risk", `${linked.length} crypto ${linked.length === 1 ? "use is" : "uses are"} linked to sensitive data. Lifetimes follow DPDP data categories and can be changed in Policy.`));
  if (!linked.length) {
    v.append(h("div", { class: "panel empty" }, icon("flow"), h("p", null, "No sensitive data was traced in this scan."),
      h("p", { class: "small" }, "Deep data-flow tracing works on Python code; other languages, binaries and configs still get full inventory and risk.")));
    return;
  }
  v.append(h("div", { class: "panel chart" }, dataMap(F, (f) => openFinding(f.id, "flow")),
    h("div", { class: "legend", style: "margin-top:12px" }, ["broken", "vulnerable", "weakened", "safe"].map((c) => h("span", null, h("i", { style: { background: `var(--${c})` } }), STATUS[c].word)))));
  const kinds = { direct: "the variable flows straight into the call", "inter-procedural": "passed in from another function", "shared-key": "same key protects it elsewhere", "value-validated": "a real value passed a format check (e.g. Aadhaar Verhoeff)" };
  const counts = {};
  linked.forEach((f) => f.data_links.forEach((d) => (counts[d.kind] = (counts[d.kind] || 0) + 1)));
  v.append(h("div", { class: "panel", style: "margin-top:20px" }, h("header", null, h("h3", null, "How each link was established")),
    h("dl", { class: "kv" }, Object.entries(counts).map(([k, n]) => [h("dt", null, `${n} × ${k.replace("-", " ")}`), h("dd", null, kinds[k] || k)]))));
};

VIEWS.quantum = function (v) {
  const q = S.quantum, pol = S.summary.policy, F = S.findings;
  v.append(guide("When could a quantum computer break today's public-key crypto? Nobody knows, so Aegis uses what experts actually said: the Global Risk Institute's 2025 survey. Pick a reading of the survey; every risk score updates.",
    { to: "systems", label: "Set system criticality" }));
  v.append(head("Quantum timeline", null));
  const src = q.source === "custom" ? "custom" : q.band;
  const seg = h("div", { class: "seg", role: "group", "aria-label": "Which reading of the survey" },
    [["optimistic", "Upper end"], ["mid", "Midpoint"], ["pessimistic", "Lower end"], ["custom", "My own years"]].map(([k, t]) =>
      h("button", { "aria-pressed": src === k ? "true" : "false", onclick: () => k === "custom" ? custom.hidden = false : applyPolicy({ quantum: { source: "survey", band: k } }) }, t)));
  const p10 = h("input", { class: "input", type: "number", min: 2026, max: 2100, value: (pol.quantum || {}).p10 || q.scenarios.early, style: "width:110px" });
  const p50 = h("input", { class: "input", type: "number", min: 2027, max: 2100, value: (pol.quantum || {}).p50 || q.scenarios.median, style: "width:110px" });
  const custom = h("div", { class: "row", hidden: src !== "custom", style: "margin-top:12px" },
    h("label", { class: "field" }, "10% chance by", p10), h("label", { class: "field" }, "50% chance by", p50),
    h("button", { class: "btn primary", style: "align-self:end", onclick: () => applyPolicy({ quantum: { source: "custom", p10: +p10.value, p50: +p50.value } }) }, "Apply my years"));
  const scen = q.scenarios;
  v.append(h("div", { class: "grid-main" },
    h("div", { class: "panel" }, h("header", null, h("h3", null, "Chance a quantum computer can break RSA-2048, by year")), h("div", { class: "chart" }, arrivalChart(q)),
      h("div", { class: "legend", style: "margin-top:8px" }, h("span", null, h("i", { style: { background: "var(--curve)", height: "3px" } }), "midpoint of each published range"), h("span", null, h("i", { style: { background: "var(--band)", border: "1px dashed var(--ink-3)" } }), "between the low and high ends"), h("span", null, h("i", { style: { background: "var(--ink)", width: "3px" } }), "the survey's two answers")),
      h("p", { class: "srcline" }, `${q.survey.title}, ${q.survey.authors}, published ${q.survey.published}, ${q.survey.experts} experts. ${q.survey.method}`)),
    h("div", { class: "stack" },
      h("div", { class: "panel" }, h("header", null, h("h3", null, "Reading of the survey")), seg, custom,
        h("div", { class: "figures", style: "grid-template-columns:repeat(3,1fr);margin:16px 0 0" },
          [["10% chance", scen.early], ["25% chance (planning)", scen.planning], ["50% chance", scen.median]].map(([t, y]) => h("div", { class: "figure", style: "cursor:default" }, h("b", null, y), h("span", { class: "d" }, t))))),
      h("div", { class: "panel" }, h("header", null, h("h3", null, "Why one year is not enough")),
        h("p", { class: "muted" }, "Mosca's rule compares X + Y with Z. Instead of one guessed Z, Aegis uses the whole curve: the chance of exposure is the probability the arrival comes before your data stops mattering. That is why an Aadhaar vault (70 years) scores near 100% while a session token scores near 0%.")))));

  const dbl = h("input", { type: "range", min: 0, max: 5, step: 0.5, value: q.doubling_years });
  const dv = h("b", null, `${q.doubling_years} years`);
  dbl.oninput = () => (dv.textContent = `${dbl.value} years`);
  dbl.onchange = () => applyPolicy({ quantum: { doubling_years: +dbl.value } });
  v.append(h("div", { class: "panel", style: "margin-top:20px" },
    h("header", null, h("h3", null, "Which algorithms fall first: the ", term("ladder", "qubit ladder"))),
    h("div", { class: "chart" }, ladderChart(q)),
    h("div", { class: "row", style: "margin-top:14px;max-width:560px" }, h("label", { class: "field", style: "flex:1" }, h("span", null, "Time for usable qubits to double: ", dv), dbl)),
    h("p", { class: "small muted", style: "margin-top:8px" }, q.doubling_note),
    h("p", { class: "srcline" }, `${q.sources.rsa.source}. ${q.sources.ecc.source}. Context: ${q.context.map((c) => c.claim + " (" + c.source + ")").join("; ")}.`)));

  const due = F.filter((f) => f.risk.class === "vulnerable").sort((a, b) => a.risk.migrate_by - b.risk.migrate_by).slice(0, 14);
  v.append(h("div", { class: "panel", style: "margin-top:20px" }, h("header", null, h("h3", null, "Latest safe start date"), h("p", null, "planning year − X − Y, earliest first")),
    h("table", { class: "t" }, h("thead", null, h("tr", null, ["Asset", "Protects", "X", "Y", "Start migrating by", "Exposure"].map((t) => h("th", null, t)))),
      h("tbody", null, due.map((f) => h("tr", { tabindex: 0, onclick: () => openFinding(f.id), onkeydown: (e) => e.key === "Enter" && openFinding(f.id) },
        h("td", null, h("b", null, f.name), " ", h("span", { class: "muted" }, f.operation), h("div", { class: "where" }, fmt.where(f))),
        h("td", null, f.data_links.map((d) => h("span", { class: "chip data" }, d.label))),
        h("td", null, fmt.yrs(f.risk.X)), h("td", null, fmt.yrs(f.risk.Y)),
        h("td", null, h("b", null, f.risk.migrate_by < f.risk.now ? "overdue" : Math.floor(f.risk.migrate_by)), f.risk.migrate_by < f.risk.now ? h("span", { class: "faint small" }, ` (${Math.floor(f.risk.migrate_by)})`) : null),
        h("td", null, fmt.pct(f.risk.p_exposure))))))));
};

VIEWS.systems = function (v) {
  const F = S.findings, rules = (S.summary.policy.criticality || []).slice();
  v.append(guide("Tell Aegis which parts of the estate matter most. A critical system gains 10 priority points and can be marked internet-facing. Crypto-agility shows how hard each area is to migrate; it lengthens or shortens Y.",
    { to: "recommend", label: "See replacements" }));
  v.append(head("Systems", "Grouped by folder. Changes apply immediately and are saved with the scan's policy.",
    rules.length ? h("button", { class: "btn", onclick: () => applyPolicy({ criticality: [] }) }, "Reset all rules") : null));
  const groups = {};
  F.forEach((f) => {
    const parts = f.location.split(/[\/!]/);
    const key = parts.length > 2 ? parts.slice(0, 2).join("/") : parts.length === 2 ? parts[0] : "(top level)";
    (groups[key] = groups[key] || []).push(f);
  });
  const tree = h("div", { class: "tree" }, h("div", { class: "tree-row head" }, h("span", null, "Area"), h("span", null, "Risk mix"), h("span", null, term("agility", "Agility")), h("span", null, term("criticality", "Criticality")), h("span", null, "Exposure")));
  Object.entries(groups).sort((a, b) => Math.max(...b[1].map((f) => f.risk.priority)) - Math.max(...a[1].map((f) => f.risk.priority))).forEach(([g, fs]) => {
    const pat = g === "(top level)" ? null : `${g}/*`;
    const rule = rules.find((r) => r.pattern === pat);
    const mix = ["broken", "vulnerable", "weakened", "safe", "inventory"].map((c) => [c, fs.filter((f) => f.risk.class === c).length]).filter((x) => x[1]);
    const ag = fs.filter((f) => f.risk.agility).map((f) => f.risk.agility.score);
    const tiers = fs.map((f) => f.risk.criticality);
    const auto = tiers.includes("critical") ? "critical" : tiers.includes("high") ? "high" : "normal";
    const tierSel = h("select", { class: "input", style: "height:30px", disabled: !pat, "aria-label": `Criticality for ${g}` },
      h("option", { value: "" }, `Auto: ${auto}`), ["critical", "high", "normal", "low"].map((t) => h("option", { value: t, selected: rule && rule.tier === t }, t)));
    const expSel = h("select", { class: "input", style: "height:30px", disabled: !pat, "aria-label": `Exposure for ${g}` },
      h("option", { value: "" }, "As detected"), h("option", { value: "external", selected: rule && rule.exposure === "external" }, "Internet-facing"), h("option", { value: "internal", selected: rule && rule.exposure === "internal" }, "Internal"));
    const apply = () => {
      const next = rules.filter((r) => r.pattern !== pat);
      if (tierSel.value || expSel.value) next.push({ pattern: pat, tier: tierSel.value || "normal", exposure: expSel.value || null });
      applyPolicy({ criticality: next });
    };
    tierSel.onchange = apply; expSel.onchange = apply;
    tree.append(h("div", { class: "tree-row" },
      h("div", { class: "nm" }, icon("folder"), h("span", null, h("b", null, g), h("span", { class: "faint small" }, `  ${fs.length} assets`))),
      h("div", { class: "mini", title: mix.map(([c, n]) => `${n} ${STATUS[c].short}`).join(", ") }, mix.map(([c, n]) => h("i", { style: { width: `${(n / fs.length) * 100}%`, background: `var(--${c})` } }))),
      h("span", null, ag.length ? `${Math.round(ag.reduce((a, b) => a + b, 0) / ag.length)}/100` : h("span", { class: "faint" }, "–")),
      tierSel, expSel));
  });
  v.append(h("div", { class: "tablewrap" }, tree));
  v.append(h("div", { class: "legend", style: "margin-top:12px" }, ["broken", "vulnerable", "weakened", "safe", "inventory"].map((c) => h("span", null, h("i", { style: { background: `var(--${c})` } }), STATUS[c].word))));
};
