/* Replacements, Fix and verify, Migration plan, Reports, Compare, Data sources, Policy. */
"use strict";

VIEWS.recommend = function (v) {
  const F = S.findings.filter((f) => f.recommendation.options.length && ["broken", "vulnerable", "weakened"].includes(f.risk.class));
  v.append(guide("Replacements are chosen by how each key is used: ML-KEM for encryption and key exchange, ML-DSA or SLH-DSA for signatures and certificates, hybrid during the transition. Sizes, latency and client support are shown so the trade-off is visible.",
    { to: "fix", label: "Fix one automatically" }));
  v.append(head("Replacements", `${F.length} assets need a change, grouped by what replaces them.`));
  const groups = {};
  F.forEach((f) => {
    let o = f.recommendation.options[0], k = o.name;
    if (o.id === "upgrade") { k = "upgrade"; o = { name: "Upgrade libraries with published advisories", standard: "GitHub Advisory Database", id: "upgrade",
      why: "These library versions have published security advisories. Each one's details panel lists the advisories and the version that fixes them." }; }
    (groups[k] = groups[k] || { o, items: [] }).items.push(f);
  });
  Object.values(groups).sort((a, b) => Math.max(...b.items.map((f) => f.risk.priority)) - Math.max(...a.items.map((f) => f.risk.priority))).forEach(({ o, items }) => {
    const withCost = items.find((f) => f.recommendation.tls_cost || f.extra.tls_cost);
    const panel = h("div", { class: "panel", style: "margin-bottom:16px" },
      h("header", null, h("h3", null, o.name), h("p", null, `${items.length} asset${items.length === 1 ? "" : "s"} · ${o.standard || ""}`)),
      h("p", { class: "muted", style: "max-width:80ch" }, o.why),
      o.use ? h("p", { class: "small", style: "margin-top:6px" }, h("b", null, "Use for: "), o.use) : null,
      o.compat ? h("p", { class: "note ok small", style: "margin-top:10px" }, o.compat) : null,
      (o.constraints || []).length ? h("ul", { class: "small muted", style: "margin:10px 0 0;padding-left:18px" }, o.constraints.map((c) => h("li", null, c))) : null,
      withCost ? h("details", { style: "margin-top:12px" }, h("summary", { class: "small", style: "cursor:pointer" }, "Handshake cost for ", fmt.where(withCost)), h("div", { class: "chart", style: "margin-top:10px" }, costChart(withCost.recommendation.tls_cost || withCost.extra.tls_cost))) : null,
      h("div", { class: "fixlist", style: "margin-top:12px" }, items.slice(0, 8).map((f) => h("div", { class: "fixrow", tabindex: 0, onclick: () => openFinding(f.id, "fix"), onkeydown: (e) => e.key === "Enter" && openFinding(f.id, "fix") },
        prio(f.risk.priority), h("div", { class: "t" }, h("div", null, h("b", null, f.name), " ", h("span", { class: "muted" }, f.operation), f.data_links.map((d) => h("span", { class: "chip data", style: "margin-left:6px" }, d.label))), h("div", { class: "where" }, fmt.where(f)),
          o.id === "upgrade" ? h("div", { class: "why" }, f.recommendation.options[0].name, ` (${(f.extra.advisories || []).length} advisories)`) : null),
        status(f.risk.class, true)))),
      items.length > 8 ? h("button", { class: "btn s", style: "margin-top:8px", onclick: () => go("inventory", { q: items[0].algorithm }) }, `All ${items.length} in the inventory`) : null);
    v.append(panel);
  });
};

VIEWS.fix = function (v, params) {
  const P = S.findings.filter((f) => f.recommendation.patchable);
  v.append(guide("Aegis can rewrite two kinds of code for you: Python RSA encryption (to a hybrid X25519 + ML-KEM envelope) and MD5 / SHA-1 hashing. It works on a copy, runs the project's own tests before and after, and scans the copy again to prove the change.",
    { to: "plan", label: "See the migration plan" }));
  v.append(head("Fix and verify", `${P.length} asset${P.length === 1 ? "" : "s"} can be fixed automatically. Everything else gets step-by-step guidance in its details panel.`));
  if (S.summary.archived) { v.append(h("p", { class: "note warn" }, "This scan is from an earlier session. Scan the project again to generate fixes.")); }
  if (!P.length) { v.append(h("div", { class: "panel empty" }, icon("wrench"), h("p", null, "Nothing in this scan can be patched automatically."), h("button", { class: "btn s", onclick: () => go("recommend") }, "See replacement guidance"))); return; }
  const sel = byId(params.id) || P[0];
  const list = h("div", { class: "fixlist" }, P.map((f) => h("div", { class: "fixrow", tabindex: 0, style: f.id === sel.id ? "background:var(--act-soft)" : "", onclick: () => go("fix", { id: f.id }), onkeydown: (e) => e.key === "Enter" && go("fix", { id: f.id }) },
    prio(f.risk.priority), h("div", { class: "t" }, h("div", null, h("b", null, f.name), " ", h("span", { class: "muted" }, f.operation)), h("div", { class: "where" }, fmt.where(f))), status(f.risk.class, true))));
  const out = h("div", { class: "stack" });
  const run = h("button", { class: "btn primary", disabled: S.summary.archived, onclick: async () => {
    run.classList.add("busy"); run.textContent = "Patching a copy and running tests";
    try { S.lastPatch = await api(`/api/scan/${S.scanId}/finding/${sel.id}/patch`, { method: "POST" }); S.lastPatch._for = sel.id; drawResult(); }
    catch (e) { out.append(h("p", { class: "note bad" }, `The fix could not be applied: ${e.message}`)); }
    run.classList.remove("busy"); run.textContent = "Generate the fix again";
  } }, icon("wrench"), "Generate and verify the fix");
  const opt = sel.recommendation.options[0];
  v.append(h("div", { class: "grid-main" }, h("div", { class: "stack" },
    h("div", { class: "panel" }, h("header", null, h("h3", null, sel.name, " ", h("span", { class: "muted", style: "font-weight:400" }, sel.operation))),
      h("div", { class: "where", style: "margin-bottom:10px" }, fmt.where(sel)),
      h("p", { class: "muted" }, sel.operation === "hash" ? `Replaces ${sel.name} with SHA-256.` : `Replaces RSA-OAEP with ${opt ? opt.name : "a hybrid ML-KEM envelope"}: new data is encrypted with X25519 + ML-KEM → HKDF → AES-256-GCM; existing ciphertext still decrypts with the old key (dual-read).`),
      h("div", { class: "row", style: "margin-top:14px" }, run, h("span", { class: "faint small" }, "Your files are not changed."))), out),
    h("div", { class: "panel" }, h("header", null, h("h3", null, "Fixable assets")), list)));
  const lines = (txt) => h("pre", { class: "code", style: "max-height:420px" }, (txt || "").split("\n").map((l) => h("div", { style: l.startsWith("+") && !l.startsWith("+++") ? "background:var(--safe-soft)" : l.startsWith("-") && !l.startsWith("---") ? "background:var(--broken-soft)" : "" }, l || " ")));
  function drawResult() {
    const r = S.lastPatch;
    out.innerHTML = "";
    if (!r || r._for !== sel.id) return;
    const tb = r.tests_before, ta = r.tests_after;
    const now = (r.now_protecting || []).filter((x) => x.location !== r.finding.location || x.risk.class === "safe");
    out.append(h("div", { class: "panel" }, h("header", null, h("h3", null, r.fixed ? "Fixed and verified" : "Patched, but the tests did not pass")),
      h("div", { class: "figures", style: "grid-template-columns:repeat(3,1fr);margin:0" },
        h("div", { class: "figure", style: "cursor:default" }, h("b", null, tb.ok ? "pass" : "fail"), h("span", { class: "d" }, `tests before (${tb.seconds}s)`)),
        h("div", { class: "figure", style: "cursor:default" }, h("b", null, ta.ok ? "pass" : "fail"), h("span", { class: "d" }, `tests after (${ta.seconds}s)`)),
        h("div", { class: "figure", style: "cursor:default" }, h("b", null, `${r.delta.before.exposed} → ${r.delta.after.exposed}`), h("span", { class: "d" }, "assets exposed, re-scanned"))),
      h("p", { class: "muted", style: "margin-top:12px" }, r.description),
      now.length ? h("p", { class: "note ok small", style: "margin-top:10px" }, "Now protecting the same data: ", now.slice(0, 3).map((x) => `${x.name} (${STATUS[x.risk.class].short.toLowerCase()}) at ${x.location}:${x.line}`).join("; ")) : null,
      h("p", { class: "note warn small", style: "margin-top:10px" }, "Prototype: the envelope uses a pure-Python reference ML-KEM and a simple HKDF combiner. Production deployments use liboqs, OpenSSL 3.5+ or the HSM vendor's implementation after a security review.")),
      h("div", { class: "panel" }, h("header", null, h("h3", null, "Change to ", h("span", { class: "mono" }, r.file))), lines(r.diff)),
      r.shim ? h("details", { class: "panel" }, h("summary", { style: "cursor:pointer" }, h("b", null, "Generated module "), h("span", { class: "mono" }, r.shim_path)), h("div", { style: "margin-top:12px" }, lines(r.shim))) : null,
      h("details", { class: "panel" }, h("summary", { style: "cursor:pointer" }, h("b", null, "Test output")), h("pre", { class: "code", style: "margin-top:12px" }, h("div", null, `$ ${ta.cmd}\n${ta.output}`))));
  }
  drawResult();
};

VIEWS.plan = async function (v) {
  v.append(guide("The plan puts every asset into a phase with an owner and a deadline aligned to India's quantum-safe roadmap for critical infrastructure: inventory by Dec 2027, high-priority systems by Dec 2028, everything by Dec 2029.",
    { to: "exports", label: "Export reports" }));
  v.append(head("Migration plan", null,
    h("button", { class: "btn", onclick: () => download(`/api/scan/${S.scanId}/plan?format=csv`) }, icon("export"), "CSV"),
    h("button", { class: "btn", onclick: () => download(`/api/scan/${S.scanId}/plan?format=md`) }, icon("export"), "Markdown")));
  if (S.summary.archived) { v.append(h("p", { class: "note warn" }, "This scan is from an earlier session. Scan again to build its plan.")); return; }
  const box = h("div", null, h("p", { class: "muted" }, "Building the plan…"));
  v.append(box);
  const p = S.plan || (S.plan = await api(`/api/scan/${S.scanId}/plan`));
  box.innerHTML = "";
  const now = S.findings[0] ? S.findings[0].risk.now : 2026.75;
  box.append(h("div", { class: "panel chart" }, planChart(p, now), h("p", { class: "srcline" }, p.note)));
  const ph = h("div", { class: "panel", style: "margin-top:20px" });
  p.phases.forEach((x) => ph.append(h("div", { class: "phase" },
    h("div", null, h("h3", null, `${x.id} · ${x.name}`), h("div", { class: "due" }, `${x.due_label} · due ${x.due}`), h("p", { class: "small muted", style: "margin-top:6px" }, x.goal),
      h("div", { class: "row", style: "margin-top:8px" }, Object.entries(x.owners).map(([o, n]) => h("span", { class: "chip" }, `${o}: ${n}`)))),
    x.items.length ? h("div", { class: "fixlist" }, x.items.slice(0, 10).map((i) => h("div", { class: "fixrow", tabindex: 0, onclick: () => openFinding(i.id, "fix"), onkeydown: (e) => e.key === "Enter" && openFinding(i.id, "fix") },
      prio(i.priority), h("div", { class: "t" }, h("div", null, h("b", null, i.name), " ", h("span", { class: "muted" }, i.operation), i.patchable ? h("span", { class: "chip", style: "margin-left:6px" }, "auto-fix") : null),
        h("div", { class: "where" }, `${i.location}:${i.line}`), h("div", { class: "why" }, i.action)), h("span", { class: "small muted" }, i.owner))),
      x.items.length > 10 ? h("p", { class: "faint small", style: "padding:8px 6px" }, `and ${x.items.length - 10} more in the CSV`) : null) : h("p", { class: "faint" }, "Nothing in this phase."))));
  box.append(ph);
};

VIEWS.exports = function (v) {
  v.append(guide("Everything here is a standard file other tools understand: the CBOM (CycloneDX 1.6) for inventories and regulators, SARIF for GitHub / GitLab code scanning, and the plan as CSV or Markdown.", null));
  v.append(head("Reports and CBOM", null));
  const valid = h("div", { class: "row" }, h("span", { class: "muted" }, "Checking against the official schema…"));
  api(`/api/scan/${S.scanId}/cbom?check=1`).then((r) => {
    valid.innerHTML = "";
    valid.append(r.valid ? h("span", { class: "st safe" }, icon("safe"), `Valid ${r.spec}`) : h("span", { class: "st broken" }, icon("broken"), `${r.errors.length} schema errors`), h("span", { class: "faint small" }, `${r.components} components, checked offline against the bundled schema`));
    if (!r.valid) valid.append(h("pre", { class: "code" }, r.errors.map((e) => h("div", null, e))));
  }).catch((e) => { valid.innerHTML = ""; valid.append(h("span", { class: "note bad" }, e.message)); });
  const card = (title, desc, ...btns) => h("div", { class: "panel" }, h("header", null, h("h3", null, title)), h("p", { class: "muted", style: "margin-bottom:14px" }, desc), h("div", { class: "row" }, ...btns));
  v.append(h("div", { class: "grid2" },
    card("Cryptography Bill of Materials", "Every asset with algorithm, mode, key size, OID, library version, relationships, and Aegis's risk properties (Mosca X/Y, chance of exposure, criticality, evidence).",
      h("button", { class: "btn primary", onclick: () => download(`/api/scan/${S.scanId}/cbom`) }, icon("export"), "Download CBOM (.cdx.json)"), valid),
    card("Code-scanning results (SARIF 2.1)", "Upload to GitHub or GitLab to show findings inline on pull requests. The command line can fail a build on critical findings.",
      h("button", { class: "btn", onclick: () => download(`/api/scan/${S.scanId}/sarif`) }, icon("export"), "Download SARIF")),
    card("Migration plan", "Phases, owners, deadlines and actions for every asset.",
      h("button", { class: "btn", onclick: () => download(`/api/scan/${S.scanId}/plan?format=csv`) }, icon("export"), "CSV"),
      h("button", { class: "btn", onclick: () => download(`/api/scan/${S.scanId}/plan?format=md`) }, icon("export"), "Markdown")),
    card("Board report", "A printable one-page summary for leadership: verdict, key numbers, top risks and the plan.",
      h("a", { class: "btn", href: `/report/${S.scanId}`, target: "_blank", rel: "noopener" }, icon("file"), "Open printable report"))));
  v.append(h("div", { class: "panel", style: "margin-top:20px" }, h("header", null, h("h3", null, "Use it in a pipeline")),
    h("pre", { class: "code" }, h("div", null, "python run.py scan ./my-service --cbom cbom.json --sarif aegis.sarif --fail-on critical")),
    h("p", { class: "small muted", style: "margin-top:8px" }, "Exits non-zero when a finding at or above the chosen severity is present, so a release with broken crypto can be stopped automatically.")));
};

VIEWS.compare = async function (v) {
  v.append(guide("Pick two scans of the same project to see what changed: new crypto that appeared, assets that were fixed, and risks that moved. Use it to track migration progress over time.", null));
  v.append(head("Compare scans", null));
  const rows = S.history.length ? S.history : await api("/api/history").catch(() => []);
  S.history = rows;
  if (rows.length < 2) { v.append(h("div", { class: "panel empty" }, icon("compare"), h("p", null, "You need at least two scans to compare."), h("button", { class: "btn s", onclick: () => go("start") }, "Run another scan"))); return; }
  const opt = (sel) => rows.map((r, i) => h("option", { value: r.id, selected: i === sel }, `${r.label} · ${fmt.date(r.started)} · ${(r.summary || {}).total || 0} assets`));
  const a = h("select", { class: "input" }, opt(1)), b = h("select", { class: "input" }, opt(0));
  const out = h("div", { style: "margin-top:20px" });
  const runCmp = async () => {
    out.innerHTML = "";
    try {
      const d = await api(`/api/scan/${a.value}/diff/${b.value}`);
      const sec = (title, list, cls) => h("div", { class: "panel" }, h("header", null, h("h3", null, title), h("p", null, list.length)),
        list.length ? h("div", { class: "fixlist" }, list.slice(0, 30).map((f) => h("div", { class: "fixrow", style: "cursor:default" }, prio(f.risk.priority), h("div", { class: "t" }, h("b", null, f.name), " ", h("span", { class: "muted" }, f.operation), h("div", { class: "where" }, fmt.where(f))), status(cls || f.risk.class, true)))) : h("p", { class: "faint" }, "None."));
      out.append(h("div", { class: "figures", style: "grid-template-columns:repeat(4,1fr)" },
        [["New", d.new.length], ["Fixed or removed", d.fixed.length], ["Priority changed", d.changed.length], ["Unchanged", d.unchanged]].map(([t, n]) => h("div", { class: "figure", style: "cursor:default" }, h("b", null, n), h("span", { class: "d" }, t)))));
      out.append(h("div", { class: "grid2" }, sec("New since the earlier scan", d.new), sec("Fixed or removed", d.fixed, "safe")));
      if (d.changed.length) out.append(h("div", { class: "panel", style: "margin-top:20px" }, h("header", null, h("h3", null, "Priority changed")),
        h("div", { class: "fixlist" }, d.changed.slice(0, 30).map((c) => h("div", { class: "fixrow", style: "cursor:default" }, h("span", null, prio(c.before.risk.priority), " → ", prio(c.after.risk.priority)), h("div", { class: "t" }, h("b", null, c.after.name), h("div", { class: "where" }, fmt.where(c.after))), status(c.after.risk.class, true))))));
    } catch (e) { out.append(h("p", { class: "note bad" }, e.message)); }
  };
  a.onchange = runCmp; b.onchange = runCmp;
  v.append(h("div", { class: "panel" }, h("div", { class: "row", style: "align-items:end" }, h("label", { class: "field", style: "flex:1" }, "Earlier scan", a), h("label", { class: "field", style: "flex:1" }, "Later scan", b), h("button", { class: "btn", onclick: () => { const t = a.value; a.value = b.value; b.value = t; runCmp(); } }, icon("swap"), "Swap"))), out);
  runCmp();
};

VIEWS.sources = async function (v) {
  v.append(guide("Every number Aegis shows comes from code it parsed or from a public source bundled with it. Nothing is fetched while you work; each source carries the date of its snapshot.", null));
  v.append(head("Data sources", "Bundled for offline use and refreshed with the scripts in tools/."));
  const rows = S.sources || (S.sources = await api("/api/data/sources"));
  v.append(h("div", { class: "tablewrap" }, h("table", { class: "t" }, h("thead", null, h("tr", null, ["Source", "What is bundled", "Used for", "Snapshot", "Licence"].map((t) => h("th", null, t)))),
    h("tbody", null, rows.map((r) => h("tr", { style: "cursor:default" }, h("td", null, h("b", null, r.name), r.url ? h("div", { class: "small" }, h("a", { href: r.url, target: "_blank", rel: "noopener" }, "publisher page")) : null,
      (r.refs || []).map((x) => h("div", { class: "faint xs" }, x))), h("td", { class: "small" }, r.what), h("td", { class: "small" }, r.used_for), h("td", { class: "small mono" }, (r.snapshot || "").replace(/\b([0-9a-f]{40})\b/g, (m) => m.slice(0, 8)).replace("github.com/", "")), h("td", { class: "small" }, r.license || "–")))))));
  v.append(h("p", { class: "srcline" }, "The live endpoint check is the only feature that uses the network, and only for hosts you type in."));
};

VIEWS.policy = async function (v) {
  v.append(guide("These are the assumptions behind every score. Change them to match your organisation; the current scan is re-assessed instantly without scanning again.", null));
  v.append(head("Policy", S.scanId ? `Applies to the open scan (${S.summary.label}).` : "Open a scan to apply changes."));
  const defs = await api("/api/policy/defaults");
  const pol = S.scanId ? S.summary.policy : defs.policy;
  const inputs = {};
  const life = h("div", { class: "tablewrap" }, h("table", { class: "t" }, h("thead", null, h("tr", null, ["Data type", "Category", "Keep secret for (years)"].map((t) => h("th", null, t)))),
    h("tbody", null, defs.data_classes.map((d) => {
      const inp = h("input", { class: "input", type: "number", min: 0, max: 150, step: 1, value: (pol.lifetimes || {})[d.id] ?? d.lifetime, style: "width:110px;height:30px" });
      inputs[d.id] = inp;
      return h("tr", { style: "cursor:default" }, h("td", null, h("b", null, d.label)), h("td", { class: "small muted" }, d.category), h("td", null, inp));
    }))));
  const mf = h("input", { type: "range", min: 0.25, max: 3, step: 0.25, value: pol.migration_factor || 1 });
  const mfv = h("b", null, `×${pol.migration_factor || 1}`);
  mf.oninput = () => (mfv.textContent = `×${mf.value}`);
  const save = h("button", { class: "btn primary", disabled: !S.scanId, onclick: () => {
    const lt = {};
    for (const [k, i] of Object.entries(inputs)) lt[k] = +i.value;
    applyPolicy({ lifetimes: lt, migration_factor: +mf.value });
  } }, "Apply to this scan");
  v.append(h("div", { class: "grid-main" }, h("div", { class: "panel" }, h("header", null, h("h3", null, "How long data must stay secret"), h("p", null, "X in Mosca's rule")), life),
    h("div", { class: "stack" },
      h("div", { class: "panel" }, h("header", null, h("h3", null, "Migration speed")), h("p", { class: "small muted", style: "margin-bottom:10px" }, "Multiplies every migration time (Y). Above 1 for a slow-moving organisation, below 1 for a fast one."),
        h("label", { class: "field" }, h("span", null, "Organisation factor ", mfv), mf)),
      h("div", { class: "panel" }, h("header", null, h("h3", null, "Quantum arrival")), h("p", { class: "small muted" }, "Set on the Quantum timeline page: which reading of the expert survey, your own years, and the qubit doubling time."),
        S.scanId ? h("button", { class: "btn s", style: "margin-top:10px", onclick: () => go("quantum") }, "Open the quantum timeline") : null),
      h("div", { class: "panel" }, h("header", null, h("h3", null, "Scan cache")), h("p", { class: "small muted", style: "margin-bottom:10px" }, "Unchanged files are not analysed twice. Clear the cache to force a full re-analysis."),
        h("button", { class: "btn s", onclick: async () => { await api("/api/cache", { method: "DELETE" }); toast("Cache cleared"); } }, "Clear cache")),
      h("div", { class: "row" }, save))));
};
