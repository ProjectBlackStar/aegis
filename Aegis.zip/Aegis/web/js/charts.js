/* Hand-built SVG charts. Every mark has a tooltip; colour always comes with a word or label. */
"use strict";

const CSSV = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const scaleX = (d0, d1, r0, r1) => (v) => r0 + ((v - d0) / (d1 - d0)) * (r1 - r0);
const tw = (str, px = 12) => String(str).length * px * 0.6;

function tip(el, html) {
  el.addEventListener("pointermove", (e) => TT.show(typeof html === "function" ? html() : html, e));
  el.addEventListener("pointerleave", () => TT.hide());
  return el;
}

/* ---- 1. Quantum horizon: arrival curve on top, data exposure windows below ---- */
function horizonChart(q, rows, now) {
  const W = 1000, L = 190, R = 70, top = 34, curveH = 92, rowH = 30;
  const end = Math.min(2100, Math.max(2072, ...rows.map((r) => Math.ceil(r.end + 2))));
  const x = scaleX(Math.floor(now), end, L, W - R);
  const H = top + curveH + 30 + rows.length * rowH + 30;
  const svg = s("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Quantum arrival curve and how long each kind of data must stay secret" });
  const yc = (p) => top + curveH - p * curveH;
  // grid + axis
  const ax = s("g", { class: "axis" });
  for (let yr = Math.ceil(now / 10) * 10; yr <= end; yr += 10) {
    if (yr - now < 4) continue;
    ax.append(s("line", { x1: x(yr), x2: x(yr), y1: top - 6, y2: H - 26, class: "gridl" }));
    ax.append(s("text", { x: x(yr), y: H - 8, "text-anchor": "middle" }, yr));
  }
  ax.append(s("text", { x: x(now), y: H - 8, "text-anchor": "middle", "font-weight": 600, fill: CSSV("--ink") }, "today"));
  ax.append(s("line", { x1: x(now), x2: x(now), y1: top - 6, y2: H - 26, stroke: CSSV("--ink"), "stroke-width": 1.5 }));
  svg.append(ax);
  // curve
  const pts = q.curve.filter((c) => c.year <= end);
  const extra = pts.length && pts[pts.length - 1].year < end ? [{ year: end, p: pts[pts.length - 1].p }] : [];
  const all = [{ year: now, p: 0 }, ...pts.filter((c) => c.year > now), ...extra];
  const line = all.map((c, i) => `${i ? "L" : "M"}${x(c.year).toFixed(1)} ${yc(c.p).toFixed(1)}`).join(" ");
  svg.append(s("path", { d: `${line} L${x(end)} ${yc(0)} L${x(now)} ${yc(0)} Z`, fill: CSSV("--curve-fill") }));
  svg.append(s("path", { d: line, fill: "none", stroke: CSSV("--curve"), "stroke-width": 2 }));
  svg.append(s("text", { x: L - 14, y: top + 4, "text-anchor": "end" }, "Chance a quantum"));
  svg.append(s("text", { x: L - 14, y: top + 20, "text-anchor": "end" }, "computer exists"));
  svg.append(s("text", { x: L - 14, y: top + curveH + 4, "text-anchor": "end", fill: CSSV("--ink-3") }, "0%"));
  const lab = { early: "10%", planning: "25%", median: "50%" };
  for (const k of ["early", "planning", "median"]) {
    const yr = q.scenarios[k];
    const p = { early: 0.1, planning: 0.25, median: 0.5 }[k];
    const g = s("g", null,
      s("line", { x1: x(yr), x2: x(yr), y1: yc(p), y2: H - 26, stroke: CSSV("--ink-3"), "stroke-dasharray": "3 4", class: "noptr" }),
      s("circle", { cx: x(yr), cy: yc(p), r: 4.5, fill: CSSV("--surface"), stroke: CSSV("--curve"), "stroke-width": 2 }),
      k === "planning" ? s("text", { x: x(yr) - 6, y: yc(p) - 12, "text-anchor": "end", "font-weight": 600, fill: CSSV("--ink") }, `25% by ${yr}`) : null);
    tip(g, `<b>${lab[k]} chance by ${yr}</b><br>From the curve fitted to the Global Risk Institute 2025 expert survey.${k === "planning" ? "<br>Aegis plans against this year." : ""}`);
    svg.append(g);
  }
  // rows
  const y0 = top + curveH + 30;
  rows.forEach((r, i) => {
    const y = y0 + i * rowH;
    const col = CSSV(`--${r.cls}`);
    const g = s("g", { class: "hrow", tabindex: 0, role: "button", "aria-label": `${r.label}: ${Math.round(r.p * 100)}% chance of exposure` });
    g.append(s("rect", { class: "hit", x: 0, y: y + 1, width: W, height: rowH - 2, rx: 6, fill: "transparent" }));  // whole row is the target
    g.append(s("text", { x: L - 14, y: y + 15, "text-anchor": "end", fill: CSSV("--ink"), "font-weight": 500 }, r.label));
    g.append(s("rect", { x: x(now), y: y + 5, width: Math.max(2, x(Math.min(r.end, end)) - x(now)), height: 14, rx: 4, fill: col, opacity: 0.22 }));
    const ex0 = Math.max(now, q.scenarios.planning);
    if (r.end > ex0) g.append(s("rect", { x: x(ex0), y: y + 5, width: Math.max(2, x(Math.min(r.end, end)) - x(ex0)), height: 14, rx: 4, fill: col }));
    g.append(s("text", { x: W - R + 10, y: y + 16, "font-weight": 600, fill: CSSV("--ink") }, `${Math.round(r.p * 100)}%`));
    tip(g, () => `<b>${esc(r.label)}</b><br>Must stay secret until about ${Math.round(r.end)} (${esc(r.why)})<br>${r.n} crypto asset${r.n === 1 ? "" : "s"} protect it<br><b>${Math.round(r.p * 100)}%</b> chance a quantum computer arrives first`);
    if (r.onclick) { g.style.cursor = "pointer"; g.addEventListener("click", r.onclick); g.addEventListener("keydown", (e) => e.key === "Enter" && r.onclick()); }
    svg.append(g);
  });
  svg.append(s("text", { x: W - R + 10, y: y0 - 10, fill: CSSV("--ink-3") }, "exposed"));
  svg.append(s("text", { x: W - R, y: top - 14, "text-anchor": "end", fill: CSSV("--ink-3") },
    `points: 10% by ${q.scenarios.early} · 25% by ${q.scenarios.planning} · 50% by ${q.scenarios.median}`));
  return svg;
}

/* ---- 2. Arrival curves for the three survey bands ---- */
function arrivalChart(q) {
  const W = 640, H = 300, L = 46, R = 16, T = 16, B = 34;
  const x = scaleX(2026, 2070, L, W - R), y = (p) => T + (1 - p) * (H - T - B);
  const svg = s("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Probability a quantum computer exists, by year" });
  for (let p = 0; p <= 1.001; p += 0.25) {
    svg.append(s("line", { x1: L, x2: W - R, y1: y(p), y2: y(p), class: "gridl" }));
    svg.append(s("text", { x: L - 8, y: y(p) + 4, "text-anchor": "end" }, `${Math.round(p * 100)}%`));
  }
  for (let yr = 2030; yr <= 2070; yr += 10) svg.append(s("text", { x: x(yr), y: H - 10, "text-anchor": "middle" }, yr));
  const path = (c) => c.map((p, i) => `${i ? "L" : "M"}${x(p.year).toFixed(1)} ${y(p.p).toFixed(1)}`).join(" ");
  const o = q.bands.optimistic.curve, pe = q.bands.pessimistic.curve;
  svg.append(s("path", { d: path(o) + " " + pe.slice().reverse().map((p) => `L${x(p.year).toFixed(1)} ${y(p.p).toFixed(1)}`).join(" ") + " Z", fill: CSSV("--band") }));
  const sel = q.source === "custom" ? null : q.band;
  for (const b of ["optimistic", "mid", "pessimistic"]) {
    const c = q.bands[b].curve;
    svg.append(s("path", { d: path(c), fill: "none", stroke: CSSV("--curve"), "stroke-width": b === sel ? 2.5 : 1, "stroke-dasharray": b === "mid" ? null : "4 4", opacity: b === sel ? 1 : 0.55 }));
  }
  if (q.source === "custom") svg.append(s("path", { d: path(q.curve), fill: "none", stroke: CSSV("--act"), "stroke-width": 2.5 }));
  // survey points
  [[2035, 0.28, 0.49, "10 years: 28–49%"], [2040, 0.51, 0.7, "15 years: 51–70%"]].forEach(([yr, lo, hi, t]) => {
    const g = s("g", null, s("line", { x1: x(yr), x2: x(yr), y1: y(lo), y2: y(hi), stroke: CSSV("--ink"), "stroke-width": 3, "stroke-linecap": "round" }),
      s("text", { x: x(yr) + 10, y: y(lo) + 16, fill: CSSV("--ink"), "font-weight": 600, "paint-order": "stroke", stroke: CSSV("--surface"), "stroke-width": 4 }, t));
    tip(g, `<b>Published survey answer</b><br>${t} chance that RSA-2048 can be broken within 24 hours (26 experts, GRI 2025).`);
    svg.append(g);
  });
  // hover crosshair
  const hit = s("rect", { x: L, y: T, width: W - L - R, height: H - T - B, fill: "transparent" });
  const cross = s("line", { y1: T, y2: H - B, stroke: CSSV("--ink-3"), "stroke-width": 1, opacity: 0 });
  svg.append(cross, hit);
  hit.addEventListener("pointermove", (e) => {
    const bb = svg.getBoundingClientRect(), vx = ((e.clientX - bb.left) / bb.width) * W;
    const yr = Math.round(2026 + ((vx - L) / (W - L - R)) * 44);
    const pick = (c) => (c.find((p) => p.year === yr) || {}).p;
    cross.setAttribute("x1", x(yr)); cross.setAttribute("x2", x(yr)); cross.setAttribute("opacity", 1);
    TT.show(`<b>By ${yr}</b><br>midpoint ${fmt.pct(pick(q.bands.mid.curve))}<br>range ${fmt.pct(pick(pe))} – ${fmt.pct(pick(o))}${q.source === "custom" ? `<br>your curve ${fmt.pct(pick(q.curve))}` : ""}`, e);
  });
  hit.addEventListener("pointerleave", () => { cross.setAttribute("opacity", 0); TT.hide(); });
  return svg;
}

/* ---- 3. Qubit ladder ---- */
function ladderChart(q) {
  const rows = q.ladder;
  const W = 1000, L = 230, R = 40, T = 26, rowH = 34, H = T + rows.length * rowH + 30;
  const lo = Math.floor(Math.min(...rows.map((r) => r.p25_year)) - 1), hi = Math.ceil(Math.max(...rows.map((r) => r.p50_year)) + 1);
  const x = scaleX(lo, hi, L, W - R);
  const svg = s("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "When each algorithm is expected to fall" });
  for (let yr = lo; yr <= hi; yr++) {
    svg.append(s("line", { x1: x(yr), x2: x(yr), y1: T - 8, y2: H - 26, class: "gridl" }));
    if (yr % 2 === 0) svg.append(s("text", { x: x(yr), y: H - 8, "text-anchor": "middle" }, yr));
  }
  svg.append(s("text", { x: x(lo), y: 12, fill: CSSV("--ink-3") }, "● 25% chance   ○ 50% chance"));
  rows.forEach((r, i) => {
    const y = T + i * rowH + 12;
    const g = s("g", null,
      s("text", { x: L - 14, y: y + 4, "text-anchor": "end", fill: CSSV("--ink"), "font-weight": 500 }, r.label),
      s("text", { x: L - 14, y: y + 18, "text-anchor": "end", fill: CSSV("--ink-3"), "font-size": 11 }, `${fmt.n(r.qubits)} logical qubits`),
      s("line", { x1: x(r.p25_year), x2: x(r.p50_year), y1: y, y2: y, stroke: CSSV("--ink-3"), "stroke-width": 2 }),
      s("circle", { cx: x(r.p25_year), cy: y, r: 6, fill: CSSV("--ink") }),
      s("circle", { cx: x(r.p50_year), cy: y, r: 6, fill: CSSV("--surface"), stroke: CSSV("--ink"), "stroke-width": 2 }));
    tip(g, `<b>${esc(r.label)}</b><br>${fmt.n(r.qubits)} logical qubits (${r.family === "ecc" ? "9n+2⌈log₂n⌉+10" : "2n+2"})<br>${r.shift > 0 ? "+" : ""}${r.shift} years vs RSA-2048<br>25%: ${r.p25_year.toFixed(1)} · 50%: ${r.p50_year.toFixed(1)}`);
    svg.append(g);
  });
  return svg;
}

/* ---- 4. Data-flow path (drawer) ---- */
function flowPath(path, f) {
  const nodes = [];
  path.forEach((h0) => nodes.push({ t: (h0.text || "").replace(/^.*?:\s*/, ""), kind: h0.hop || "step", line: h0.line }));
  const lastN = nodes[nodes.length - 1];
  if (lastN && lastN.kind === "key" && lastN.line === f.line) { lastN.kind = "crypto"; lastN.t = `${f.name} ${f.operation}: ${lastN.t}`; }
  else nodes.push({ t: `${f.name} ${f.operation}`, kind: "crypto", line: f.line });
  const W = 660, nodeH = 40, gap = 16;
  const svg = s("svg", { viewBox: `0 0 ${W} ${nodes.length * (nodeH + gap) + 8}`, role: "img", "aria-label": "How the data reaches the crypto call" });
  svg.append(s("defs", null, s("marker", { id: "fa", viewBox: "0 0 10 10", refX: 9, refY: 5, markerWidth: 6, markerHeight: 6, orient: "auto" }, s("path", { d: "M0 0L10 5L0 10z", fill: CSSV("--ink-3") }))));
  nodes.forEach((n, i) => {
    const y = i * (nodeH + gap) + 4;
    const crypto = n.kind === "crypto";
    const label = n.t.length > 86 ? n.t.slice(0, 84) + "…" : n.t;
    svg.append(s("rect", { x: 0, y, width: W, height: nodeH, rx: 8, fill: crypto ? CSSV("--vulnerable-soft") : CSSV("--surface-2"), stroke: crypto ? CSSV("--vulnerable") : CSSV("--line") }));
    svg.append(s("text", { x: 14, y: y + 25, fill: CSSV("--ink"), "font-size": 13, "font-weight": crypto ? 600 : 400 }, label));
    if (n.line) svg.append(s("text", { x: W - 12, y: y + 25, "text-anchor": "end", fill: CSSV("--ink-3"), "font-size": 11 }, `line ${n.line}`));
    if (i < nodes.length - 1) svg.append(s("line", { x1: 30, x2: 30, y1: y + nodeH, y2: y + nodeH + gap - 1, stroke: CSSV("--ink-3"), "marker-end": "url(#fa)" }));
  });
  return svg;
}

/* ---- 5. Data → crypto → status map ---- */
function dataMap(findings, onPick) {
  const linked = findings.filter((f) => f.data_links.length);
  const classes = {};
  linked.forEach((f) => f.data_links.forEach((d) => { (classes[d.label] = classes[d.label] || { life: d.lifetime_years, items: [] }).items.push(f); }));
  const cls = Object.entries(classes).sort((a, b) => b[1].life - a[1].life);
  const assets = [...new Map(linked.map((f) => [f.id, f])).values()].sort((a, b) => b.risk.priority - a.risk.priority);
  const W = 1000, rowH = 34, H = Math.max(cls.length, assets.length) * rowH + 30;
  const svg = s("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Which crypto protects which data" });
  const ly = (i, n) => 20 + i * rowH + ((Math.max(cls.length, assets.length) - n) * rowH) / 2;
  const Lx = 210, Mx = 470;
  const apos = {};
  assets.forEach((f, i) => { apos[f.id] = ly(i, assets.length); });
  cls.forEach(([name, c], i) => {
    const y = ly(i, cls.length);
    c.items.forEach((f) => {
      const ay = apos[f.id];
      const p = s("path", { d: `M${Lx} ${y} C${(Lx + Mx) / 2} ${y}, ${(Lx + Mx) / 2} ${ay}, ${Mx} ${ay}`, fill: "none", stroke: CSSV(`--${f.risk.class}`), "stroke-width": 1.6, opacity: 0.55 });
      svg.append(p);
    });
    const g = s("g", null, s("rect", { x: 0, y: y - 13, width: Lx, height: 26, rx: 6, fill: CSSV("--act-soft") }),
      s("text", { x: 10, y: y + 4, fill: CSSV("--ink"), "font-weight": 600 }, name),
      s("text", { x: Lx - 10, y: y + 4, "text-anchor": "end", fill: CSSV("--ink-2") }, fmt.yrs(c.life)));
    tip(g, `<b>${esc(name)}</b><br>must stay secret for ${fmt.yrs(c.life)}<br>${c.items.length} crypto use${c.items.length === 1 ? "" : "s"}`);
    svg.append(g);
  });
  assets.forEach((f) => {
    const y = apos[f.id];
    const g = s("g", { class: "hrow", tabindex: 0, role: "button", style: "cursor:pointer", "aria-label": `${f.name} ${f.operation}, ${f.location} line ${f.line}: ${STATUS[f.risk.class].word}` },
      s("rect", { class: "hit", x: Mx - 12, y: y - rowH / 2 + 1, width: W - Mx + 12, height: rowH - 2, rx: 6, fill: "transparent" }),
      s("circle", { cx: Mx, cy: y, r: 5, fill: CSSV(`--${f.risk.class}`) }),
      s("text", { x: Mx + 14, y: y + 4, fill: CSSV("--ink"), "font-weight": 500 }, `${f.name} ${f.operation}`),
      s("text", { x: Mx + 14 + tw(`${f.name} ${f.operation}`, 12.6) + 14, y: y + 4, fill: CSSV("--ink-3"), "font-size": 11 }, `${f.location}:${f.line}`),
      s("text", { x: W - 4, y: y + 4, "text-anchor": "end", fill: CSSV("--ink"), "font-weight": 600 }, f.risk.class === "vulnerable" ? fmt.pct(f.risk.p_exposure) : STATUS[f.risk.class].short));
    tip(g, `<b>${esc(f.name)} ${esc(f.operation)}</b><br>${esc(f.location)}:${f.line}<br>${STATUS[f.risk.class].word} · priority ${f.risk.priority}`);
    g.addEventListener("click", () => onPick(f));
    g.addEventListener("keydown", (e) => e.key === "Enter" && onPick(f));
    svg.append(g);
  });
  return svg;
}

/* ---- 6. TLS handshake cost ---- */
function costChart(cost) {
  const opts = cost.options;
  const W = 720, L = 300, R = 70, rowH = 40, T = 30, H = T + opts.length * rowH + 20;
  const max = Math.max(cost.limits.tcp * 1.15, ...opts.map((o) => o.bytes)) * 1.05;
  const x = scaleX(0, max, L, W - R);
  const svg = s("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Server handshake size for each option" });
  const lim = (v, t) => svg.append(s("line", { x1: x(v), x2: x(v), y1: T - 12, y2: H - 10, stroke: CSSV("--ink"), "stroke-dasharray": "4 4" }),
    s("text", { x: x(v) + 6, y: T - 16, fill: CSSV("--ink"), "font-size": 11 }, t));
  lim(cost.limits.tcp, "TCP initial window 14.6 KB");
  opts.forEach((o, i) => {
    const y = T + i * rowH;
    const over = o.tcp_extra_rtt;
    const g = s("g", null,
      s("text", { x: L - 14, y: y + 18, "text-anchor": "end", fill: CSSV("--ink"), "font-size": 12 }, o.name.replace("Hybrid key exchange", "Hybrid KEX").replace(" (X25519MLKEM768), classical certificates", ", classical certs").replace(" certificates", " certs")),
      s("rect", { x: L, y: y + 6, width: Math.max(2, x(o.bytes) - L), height: 18, rx: 4, fill: over ? CSSV("--vulnerable") : CSSV("--ink-3") }),
      s("text", { x: x(o.bytes) + 8, y: y + 20, fill: CSSV("--ink"), "font-weight": 600, "font-size": 12 }, fmt.bytes(o.bytes)));
    tip(g, `<b>${esc(o.name)}</b><br>${fmt.n(o.bytes)} bytes, ${o.tcp_segments} TCP segments<br>TCP: ${o.tcp_extra_rtt ? "<b>one extra round trip</b>" : "fits the first window"}<br>QUIC (limit ${fmt.n(o.quic_limit)} B before address validation): ${o.quic_extra_rtt ? "<b>extra round trip</b>" : "fits"}`);
    svg.append(g);
  });
  return svg;
}

/* ---- 7. Migration plan timeline ---- */
function planChart(plan, now) {
  const W = 1000, L = 230, R = 30, rowH = 44, T = 26;
  const ph = plan.phases;
  const end = 2030.2, x = scaleX(Math.floor(now * 4) / 4, end, L, W - R);
  const H = T + ph.length * rowH + 26;
  const svg = s("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Migration phases and deadlines" });
  for (let yr = Math.ceil(now); yr <= 2030; yr++) {
    svg.append(s("line", { x1: x(yr), x2: x(yr), y1: T - 10, y2: H - 22, class: "gridl" }));
    svg.append(s("text", { x: x(yr), y: H - 6, "text-anchor": "middle" }, yr));
  }
  const yrOf = (d) => { const t = new Date(d); return t.getFullYear() + (t.getMonth() + (t.getDate() - 1) / 31) / 12; };
  ph.forEach((p, i) => {
    const y = T + i * rowH;
    const due = yrOf(p.due);
    const g = s("g", null,
      s("text", { x: L - 14, y: y + 14, "text-anchor": "end", fill: CSSV("--ink"), "font-weight": 600 }, `${p.id} ${p.name}`),
      s("text", { x: L - 14, y: y + 30, "text-anchor": "end", fill: CSSV("--ink-3"), "font-size": 11 }, `${p.count} assets · ${p.due_label}`),
      s("rect", { x: x(now), y: y + 6, width: Math.max(4, x(due) - x(now)), height: 20, rx: 5, fill: p.count ? CSSV("--ink") : CSSV("--line"), opacity: p.count ? 0.85 - i * 0.15 : 1 }),
      s("path", { d: `M${x(due)} ${y + 2} l6 14 l-6 14 l-6 -14 z`, fill: CSSV("--vulnerable") }));
    tip(g, `<b>${esc(p.name)}</b><br>Due ${esc(p.due)} (${esc(p.due_label)})<br>${p.count} assets, ${p.auto_fixable} auto-fixable<br>${esc(p.goal)}`);
    svg.append(g);
  });
  return svg;
}
