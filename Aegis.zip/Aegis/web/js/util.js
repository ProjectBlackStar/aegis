/* Aegis UI helpers: DOM builder, API, icons, formatting, tooltip, toast, glossary. No dependencies. */
"use strict";

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k === "html") el.innerHTML = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "style" && typeof v === "object") Object.assign(el.style, v);
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const k of kids.flat(Infinity)) {
    if (k == null || k === false) continue;
    el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
  return el;
}
const svgNS = "http://www.w3.org/2000/svg";
function s(tag, attrs, ...kids) {
  const el = document.createElementNS(svgNS, tag);
  if (attrs) for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v);
  }
  for (const k of kids.flat(Infinity)) if (k != null && k !== false) el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  return el;
}

async function api(path, opts = {}) {
  const o = { headers: {}, ...opts };
  if (o.body && !(o.body instanceof FormData)) { o.headers["Content-Type"] = "application/json"; o.body = JSON.stringify(o.body); }
  const r = await fetch(path, o);
  if (!r.ok) {
    let msg = r.statusText;
    try { const t = await r.text(); const m = t.match(/<p>(.*?)<\/p>/); msg = m ? m[1] : (JSON.parse(t).error || t.slice(0, 200)); } catch (e) { /* keep status text */ }
    throw new Error(msg || `Request failed (${r.status})`);
  }
  return r.status === 202 ? { pending: true } : r.json();
}

/* Icons: 24px grid, 1.75 stroke, drawn for this product. */
const IC = {
  scan: '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3M7 12h10"/>',
  overview: '<circle cx="12" cy="12" r="8"/><path d="M12 7v5l3.5 2"/>',
  list: '<path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.5" cy="6" r="1"/><circle cx="4.5" cy="12" r="1"/><circle cx="4.5" cy="18" r="1"/>',
  flow: '<circle cx="5" cy="6" r="2"/><circle cx="5" cy="18" r="2"/><circle cx="19" cy="12" r="2"/><path d="M7 6c5 0 6 6 10 6M7 18c5 0 6-6 10-6"/>',
  horizon: '<path d="M3 17c4 0 5-10 9-10s5 10 9 10"/><path d="M3 20h18"/>',
  systems: '<rect x="3" y="4" width="7" height="7" rx="1.5"/><rect x="14" y="4" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="6" rx="1.5"/><rect x="14" y="14" width="7" height="6" rx="1.5"/>',
  swap: '<path d="M7 7h11l-3-3M17 17H6l3 3"/>',
  wrench: '<path d="M14.5 6.5a4 4 0 0 0 5 5L12 19a2.1 2.1 0 0 1-3-3l7.5-7.5a4 4 0 0 0-2-2z"/>',
  plan: '<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M7 14h4"/>',
  export: '<path d="M12 4v11M7.5 10.5 12 15l4.5-4.5M5 19h14"/>',
  compare: '<path d="M8 4v16M16 4v16M3 9h5M16 15h5"/>',
  source: '<ellipse cx="12" cy="6" rx="7" ry="2.5"/><path d="M5 6v6c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5V6M5 12v6c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5v-6"/>',
  sliders: '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4 4"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4 7 17M17 7l1.4-1.4"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
  info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5M12 8h.01"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  broken: '<path d="M12 3 2.5 20h19z"/><path d="M12 10v4M12 17h.01"/>',
  vulnerable: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5v5.5M12 16.5h.01"/>',
  weakened: '<circle cx="12" cy="12" r="8.5"/><path d="M8 12h8"/>',
  safe: '<path d="M12 3 4.5 6v5.5c0 4.6 3.2 8.2 7.5 9.5 4.3-1.3 7.5-4.9 7.5-9.5V6z"/><path d="m8.5 12 2.5 2.5 4.5-5"/>',
  inventory: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="1.5"/>',
  folder: '<path d="M3.5 7.5a2 2 0 0 1 2-2h4l2 2h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/>',
  git: '<circle cx="6" cy="6" r="2"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="9" r="2"/><path d="M6 8v8M18 11c0 4-6 3-11 6"/>',
  upload: '<path d="M12 16V5M7.5 9.5 12 5l4.5 4.5M5 19h14"/>',
  globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.4 3.5 5.3 3.5 8.5s-1 6.1-3.5 8.5c-2.5-2.4-3.5-5.3-3.5-8.5s1-6.1 3.5-8.5z"/>',
  box: '<path d="M12 3 4 7v10l8 4 8-4V7z"/><path d="m4 7 8 4 8-4M12 11v10"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 8-8M16 7l2.5 2.5"/>',
  lock: '<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
  play: '<path d="M7 5v14l11-7z"/>',
};
function icon(name, cls) {
  const sp = document.createElement("span");
  sp.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[name] || ""}</svg>`;
  const el = sp.firstChild;
  el.setAttribute("width", "16"); el.setAttribute("height", "16");
  if (cls) el.setAttribute("class", cls);
  return el;
}

const STATUS = {
  broken: { word: "Broken today", short: "Broken", note: "Exploitable with ordinary computers now" },
  vulnerable: { word: "Quantum-vulnerable", short: "Vulnerable", note: "Broken by Shor's algorithm on a quantum computer" },
  weakened: { word: "Weakened", short: "Weakened", note: "Security margin reduced (Grover); low priority" },
  safe: { word: "Quantum-safe", short: "Safe", note: "Adequate against quantum attacks" },
  inventory: { word: "Inventory only", short: "Inventory", note: "Recorded for completeness; review" },
};
function status(cls, short) {
  const st = STATUS[cls] || STATUS.inventory;
  return h("span", { class: `st ${cls}`, title: st.note }, icon(cls in STATUS ? cls : "inventory"), short ? st.short : st.word);
}
function prio(n) {
  const c = n >= 85 ? "critical" : n >= 65 ? "high" : n >= 40 ? "medium" : "";
  return h("span", { class: `prio ${c}`, title: `Priority ${n} of 100` }, n);
}
const fmt = {
  n: (v) => (v == null ? "–" : Number(v).toLocaleString("en-IN")),
  pct: (p) => (p == null ? "–" : `${Math.round(p * 100)}%`),
  yrs: (y) => { if (y == null) return "–"; if (y < 0.02) return "minutes"; if (y < 1) return `${Math.round(y * 12)} months`; const n = +(+y).toFixed(y < 10 ? 1 : 0); return `${n} year${n === 1 ? "" : "s"}`; },
  bytes: (b) => (b == null ? "–" : b >= 1024 ? `${(b / 1024).toFixed(1)} KB` : `${b} B`),
  date: (t) => new Date(t * 1000).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }),
  where: (f) => (f.line ? `${f.location}:${f.line}` : f.location),
  plural: (n, w, p) => `${fmt.n(n)} ${n === 1 ? w : p || w + "s"}`,
};

/* Tooltip that follows the pointer (charts) */
const TT = (() => {
  let el;
  return {
    show(html, ev) {
      if (!el) { el = h("div", { class: "tt", role: "tooltip" }); document.body.append(el); }
      el.innerHTML = html; el.classList.add("on");
      const x = Math.min(ev.clientX + 14, innerWidth - el.offsetWidth - 8), y = Math.min(ev.clientY + 14, innerHeight - el.offsetHeight - 8);
      el.style.left = x + "px"; el.style.top = y + "px";
    },
    hide() { el && el.classList.remove("on"); },
  };
})();
function toast(msg) {
  const t = $("#toast");
  t.textContent = msg; t.classList.add("on");
  clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove("on"), 2600);
}
const esc = (x) => String(x ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

/* Plain-language glossary used by <dfn data-term> anywhere in the UI */
const TERMS = {
  mosca: ["Mosca's rule", "If the years your data must stay secret (X) plus the years you need to migrate (Y) are more than the years until a quantum computer exists (Z), that data is already at risk."],
  X: ["X: keep secret", "How long the protected data must stay confidential (or a signature must stay trusted). Aegis reads this from the data that reaches the crypto call, e.g. Aadhaar numbers stay sensitive for life."],
  Y: ["Y: migration time", "How long moving this asset to post-quantum crypto takes. Starts from the asset type and is adjusted for exposure and for how scattered or hard-coded the crypto is (crypto-agility)."],
  Z: ["Z: quantum arrival", "When a quantum computer able to break RSA-2048 may exist. Aegis fits a curve to the Global Risk Institute 2025 expert survey: 10% chance by 2030, 25% by 2033, 50% by 2037."],
  hndl: ["Harvest now, decrypt later", "An attacker records encrypted traffic or steals encrypted backups today and decrypts them once a quantum computer exists. Signatures are not affected this way."],
  pexp: ["Chance of exposure", "The probability, from the expert-survey curve, that a quantum computer able to break this algorithm arrives before migration ends and the data stops mattering."],
  ladder: ["Qubit ladder", "Breaking elliptic curves needs fewer logical qubits than breaking RSA-2048 (2,330 vs 4,098 for P-256), so they are expected to fall earlier. Each algorithm's arrival year is shifted by its qubit requirement."],
  agility: ["Crypto-agility", "How easily the crypto can be swapped: one central module set by configuration is quick; the same algorithm hard-coded across many files is slow. It lengthens or shortens Y."],
  cbom: ["CBOM", "Cryptography Bill of Materials: a standard (CycloneDX 1.6) list of every algorithm, key, certificate and protocol in a system."],
  kem: ["ML-KEM", "NIST FIPS 203 post-quantum key encapsulation. Used to set up encryption keys; replaces RSA encryption and ECDH."],
  dsa: ["ML-DSA / SLH-DSA", "NIST FIPS 204 and 205 post-quantum signatures. Replace RSA and ECDSA signatures and certificates."],
  hybrid: ["Hybrid", "Classical and post-quantum combined (e.g. X25519 + ML-KEM-768). Stays secure as long as either part holds; the safe default during transition."],
  evidence: ["Evidence strength", "Confirmed: parsed code, config or certificate. Strong: an API pattern or linked library. Indicative: a byte signature, version string or declared dependency."],
  criticality: ["Business criticality", "How important the system is to the organisation. Set rules on the Systems page; critical systems rise in priority."],
  initcwnd: ["Initial window", "A new TCP connection can send about 14.6 KB before waiting for a reply (RFC 6928). A larger TLS handshake costs an extra round trip."],
};
function term(key, text) {
  return h("dfn", { "data-term": key, tabindex: 0 }, text || TERMS[key][0]);
}
document.addEventListener("click", (e) => {
  const d = e.target.closest("dfn[data-term]");
  $$(".term-pop").forEach((p) => p.remove());
  if (!d) return;
  const [t, body] = TERMS[d.dataset.term] || [];
  if (!t) return;
  const pop = h("div", { class: "term-pop", role: "note" }, h("b", null, t), body);
  document.body.append(pop);
  const r = d.getBoundingClientRect();
  pop.style.left = Math.min(r.left, innerWidth - pop.offsetWidth - 12) + "px";
  pop.style.top = (r.bottom + 8 + pop.offsetHeight > innerHeight ? r.top - pop.offsetHeight - 8 : r.bottom + 8) + "px";
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && e.target.matches && e.target.matches("dfn[data-term]")) e.target.click();
});

function download(url) {
  const a = h("a", { href: url, download: "" });
  document.body.append(a); a.click(); a.remove();
}
