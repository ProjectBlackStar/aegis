"""Self-tests: python -m unittest discover -s tests -v   (run from the project folder)"""
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path[:0] = [ROOT, os.path.join(ROOT, "vendor")]

from core.engine import Scan  # noqa: E402
from core.export.cbom import build_cbom, validate  # noqa: E402
from core.patch.patcher import apply_to_copy  # noqa: E402

SAMPLES = os.path.join(ROOT, "samples")


class EngineTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scan = Scan(os.path.join(SAMPLES, "digibank-kyc")).run()

    def test_trap_has_zero_findings(self):
        s = Scan(os.path.join(SAMPLES, "trap-only")).run()
        self.assertEqual(len(s.findings), 0)
        self.assertFalse([f for f in self.scan.findings if "trap_not_crypto" in f.location])

    def test_aadhaar_link_and_exposure(self):
        f = next(f for f in self.scan.findings if f.location.endswith("aadhaar_vault.py") and f.operation == "encrypt")
        self.assertEqual(f.data_links[0]["data_class"], "AADHAAR")
        self.assertEqual(f.exposure, "external")        # reached from a Flask route
        self.assertTrue(f.risk["exposed"])

    def test_signature_is_not_harvest_risk(self):
        f = next(f for f in self.scan.findings if f.location.endswith("upi.py") and f.operation == "sign")
        self.assertEqual(f.risk["usage"], "authentic")
        self.assertFalse(f.risk["hndl"])

    def test_every_input_type_detected(self):
        det = {f.detector for f in self.scan.findings}
        for d in ("python-ast", "lexer-java", "lexer-js", "lexer-c", "lexer-go", "binary", "cert", "config", "deps"):
            self.assertIn(d, det)

    def test_container_image(self):
        s = Scan(os.path.join(SAMPLES, "digibank-image.tar")).run()
        self.assertTrue(any("!layer2/app/server.py" in f.location for f in s.findings))

    def test_cbom_schema_valid(self):
        ok, errs = validate(build_cbom(self.scan))
        self.assertIn(ok, (True, None), errs)

    def test_patch_passes_tests_and_protects_aadhaar(self):
        f = next(f for f in self.scan.findings if f.location.endswith("aadhaar_vault.py") and f.operation == "encrypt")
        res = apply_to_copy(os.path.join(SAMPLES, "digibank-kyc"), f.to_dict(), tempfile.gettempdir())
        self.assertTrue(res["tests_after"]["ok"], res["tests_after"]["output"])
        s2 = Scan(res["patched_root"]).run()
        safe = [x for x in s2.findings if any(d["data_class"] == "AADHAAR" for d in x.data_links) and x.risk["class"] == "safe"]
        self.assertTrue(safe)


if __name__ == "__main__":
    unittest.main()
