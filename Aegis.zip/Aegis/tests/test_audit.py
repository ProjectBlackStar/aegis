"""Audit tests: one test per requirement in the requirements-to-test matrix (IDs R1..R12).
Run:  python -m unittest discover -s tests -v"""
import io
import json
import os
import re
import shutil
import sys
import tarfile
import tempfile
import unittest
import zipfile
from pathlib import Path

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path[:0] = [ROOT, os.path.join(ROOT, "vendor")]

from core.engine import Scan  # noqa: E402
from core.export.cbom import build_cbom, validate  # noqa: E402
from core.plan import build_plan  # noqa: E402

SAMPLES = os.path.join(ROOT, "samples")
KYC = os.path.join(SAMPLES, "digibank-kyc")


def find(scan, path_end, op=None, algo=None):
    for f in scan.findings:
        if f.location.endswith(path_end) and (op is None or f.operation == op) and (algo is None or f.algorithm == algo):
            return f
    raise AssertionError(f"no finding for {path_end} {op} {algo}")


class Audit(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.s = Scan(KYC).run()

    # R1 catalogue every input type the PS names
    def test_R1_all_input_types(self):
        det = {f.detector for f in self.s.findings}
        for d in ("python-ast", "lexer-java", "lexer-js", "lexer-c", "lexer-go", "binary", "cert", "config", "deps"):
            self.assertIn(d, det)
        assets = {f.asset_type for f in self.s.findings}
        for a in ("algorithm", "certificate", "key", "protocol", "library", "cloud-kms"):
            self.assertIn(a, assets)
        img = Scan(os.path.join(SAMPLES, "digibank-image.tar")).run()
        self.assertTrue(any("!layer2/app/server.py" in f.location for f in img.findings))

    # R2 evidence is separated from inference
    def test_R2_evidence_types(self):
        for f in self.s.findings:
            self.assertIn(f.evidence_strength, ("confirmed", "strong", "indicative"), f.display_name)
        sig = [f for f in self.s.findings if f.detector == "binary" and "code signature" in f.evidence_type]
        for f in sig:
            self.assertEqual(f.evidence_strength, "indicative")
        self.assertEqual(find(self.s, "aadhaar_vault.py", "encrypt").evidence_strength, "confirmed")

    # R3 the data path is explicit, hop by hop
    def test_R3_data_flow_path(self):
        f = find(self.s, "aadhaar_vault.py", "encrypt")
        link = next(d for d in f.data_links if d["data_class"] == "AADHAAR")
        hops = [h["hop"] for h in link["path"]]
        self.assertEqual(hops[0], "caller")            # routes.py enroll() -> store_citizen()
        self.assertIn("parameter", hops)
        self.assertIn("assignment", hops)              # blob = aadhaar_number.encode()
        self.assertEqual(hops[-1], "crypto call")
        self.assertIn(link["kind"], ("direct", "inter-procedural"))
        dec = find(self.s, "aadhaar_vault.py", "decrypt")
        self.assertEqual(dec.data_links[0]["kind"], "shared-key")   # inherited, and labelled as such

    # R4 no data link without a flow: a key whose data never reaches it gets none
    def test_R4_no_link_without_flow(self):
        self.assertEqual(find(self.s, "PaymentGateway.java", "keygen").data_links, [])
        self.assertEqual(find(self.s, "legacy/reports.py", "hash").data_links, [])

    # R5 Mosca uses explicit, editable assumptions and shows uncertainty
    def test_R5_mosca_assumptions(self):
        f = find(self.s, "aadhaar_vault.py", "encrypt")
        r = f.risk
        for k in ("X", "Y", "crqc", "x_reason", "x_confidence"):
            self.assertIn(k, r)
        self.assertEqual(set(r["crqc"]), {"early", "planning", "median"})
        self.assertIn("y_reason", r)
        self.assertTrue(0 < r["p_exposure"] <= 1)
        before = self.s.summary()["exposed"]
        pol = json.loads(json.dumps(self.s.policy))
        pol["quantum"] = {"source": "custom", "p10": 2045, "p50": 2060, "doubling_years": 2.0}
        s2 = Scan(KYC).run().reassess(pol)
        self.assertLess(s2.summary()["exposed"], before)

    # R6 recommendations follow how the key is used (ML-KEM vs ML-DSA)
    def test_R6_usage_aware_recommendations(self):
        enc = find(self.s, "aadhaar_vault.py", "encrypt").recommendation["options"][0]["id"]
        self.assertIn(enc, ("ml-kem-1024", "ml-kem-768", "hybrid-kem"))
        for path, op in (("esign/signer.py", "sign"), ("upi.py", "sign")):
            self.assertIn(find(self.s, path, op).recommendation["options"][0]["id"], ("ml-dsa-65", "ml-dsa-44", "slh-dsa"))
        kms = [f for f in self.s.findings if f.asset_type == "cloud-kms" and f.algorithm == "RSA"][0]
        self.assertEqual(kms.extra["key_usage"], "encryption")
        self.assertTrue(kms.recommendation["options"][0]["id"].startswith(("ml-kem", "hybrid")))
        unk = find(self.s, "PaymentGateway.java", "keygen")
        ids = {o["id"] for o in unk.recommendation["options"]}
        self.assertTrue({"ml-dsa-65", "hybrid-kem"} <= ids and unk.recommendation["note"])
        for f in self.s.findings:
            if f.asset_type == "certificate":
                self.assertNotIn("hybrid-kem", {o["id"] for o in f.recommendation["options"]})

    # R7 every recommendation states constraints
    def test_R7_constraints(self):
        for f in self.s.findings:
            for o in f.recommendation["options"]:
                if o["id"].startswith(("ml-", "hybrid", "slh", "tls13", "ssh")):
                    self.assertTrue(o.get("constraints"), o["id"])

    # R8 CBOM: schema-valid on real findings, unique refs, valid relationships, nothing dropped
    def test_R8_cbom_complete(self):
        bom = build_cbom(self.s)
        ok, errs = validate(bom)
        self.assertIn(ok, (True, None), errs)
        refs = [c["bom-ref"] for c in bom["components"]]
        self.assertEqual(len(refs), len(set(refs)))
        self.assertEqual(len(refs), len(self.s.findings))
        for d in bom.get("dependencies", []):
            self.assertIn(d["ref"], refs)
            for x in d["dependsOn"]:
                self.assertIn(x, refs)
        self.assertTrue(bom.get("dependencies"))

    # R9 repeat scans are stable
    def test_R9_deterministic(self):
        a, b = Scan(KYC).run(), Scan(KYC).run()
        self.assertEqual([f.fid for f in a.findings], [f.fid for f in b.findings])
        strip = lambda bom: [{k: v for k, v in c.items()} for c in bom["components"]]
        self.assertEqual(strip(build_cbom(a)), strip(build_cbom(b)))

    # R10 malformed and hostile inputs never crash the scan
    def test_R10_malformed_inputs(self):
        d = tempfile.mkdtemp()
        try:
            Path(d, "broken.py").write_text("def x(:\n  import hashlib\n")
            Path(d, "binary.py").write_bytes(bytes(range(256)) * 4)
            Path(d, "trunc.so").write_bytes(b"\x7fELF\x02\x01\x01" + b"\x00" * 40)
            Path(d, "latin1.java").write_bytes('// caf\xe9\nclass A { }'.encode("latin-1"))
            Path(d, "empty.pem").write_bytes(b"")
            Path(d, "bad.pem").write_bytes(b"-----BEGIN CERTIFICATE-----\nnot base64\n-----END CERTIFICATE-----\n")
            Path(d, "corrupt.zip").write_bytes(b"PK\x03\x04garbage")
            buf = io.BytesIO()
            with tarfile.open(fileobj=buf, mode="w") as t:
                info = tarfile.TarInfo("manifest.json"); data = b"{not json"; info.size = len(data); t.addfile(info, io.BytesIO(data))
            Path(d, "badimage.tar").write_bytes(buf.getvalue())
            s = Scan(d).run()
            self.assertEqual(s.status, "done", s.error)
            zs = os.path.join(d, "slip.zip")
            with zipfile.ZipFile(zs, "w") as z:
                z.writestr("../../evil.py", "import hashlib\nhashlib.md5(b'x')\n")
                z.writestr("ok.py", "import hashlib\nhashlib.sha1(b'x')\n")
            s2 = Scan(zs).run()
            locs = [f.location for f in s2.findings]
            self.assertEqual(s2.status, "done")
            self.assertTrue(any(l.endswith("ok.py") for l in locs))
            self.assertFalse(any("evil" in l for l in locs))      # path traversal member skipped
            s3 = Scan(os.path.join(d, "does-not-exist")).run()
            self.assertEqual(s3.status, "error")
            self.assertIn("not found", s3.error)
        finally:
            shutil.rmtree(d)

    # R11 the migration plan covers every risky finding exactly once
    def test_R11_plan_coverage(self):
        p = build_plan(self.s)
        ids = [i["id"] for ph in p["phases"] for i in ph["items"]]
        self.assertEqual(len(ids), len(set(ids)))
        risky = {f.fid for f in self.s.findings if f.risk["class"] in ("broken", "vulnerable", "weakened")}
        self.assertTrue(risky <= set(ids))

    # R13 hardware security modules and cloud key services are inventoried
    def test_R13_hsm_and_cloud(self):
        d = tempfile.mkdtemp()
        try:
            Path(d, "hsm.py").write_text("import pkcs11\nlib = pkcs11.lib('/usr/lib/softhsm/libsofthsm2.so')\n")
            Path(d, "hsm.c").write_text("#include <pkcs11.h>\nint main(){ C_Initialize(NULL); return 0; }\n")
            Path(d, "kms.py").write_text("import boto3\nkms = boto3.client('kms')\n"
                                                       "def seal(aadhaar_number):\n    return kms.encrypt(KeyId='k', Plaintext=aadhaar_number, EncryptionAlgorithm='RSAES_OAEP_SHA_256')\n")
            s = Scan(d).run()
            kinds = {(f.location, f.asset_type) for f in s.findings}
            self.assertIn(("hsm.py", "hsm"), kinds)
            self.assertIn(("hsm.c", "hsm"), kinds)
            k = next(f for f in s.findings if f.location == "kms.py" and f.operation == "encrypt")
            self.assertEqual(k.algorithm, "RSA")
            self.assertEqual(k.data_links[0]["data_class"], "AADHAAR")
        finally:
            shutil.rmtree(d)
        self.assertTrue(any(f.asset_type == "cloud-kms" for f in self.s.findings))

    # R12 the UI loads nothing from the internet
    def test_R12_no_external_assets(self):
        files = [p for p in Path(ROOT, "web").rglob("*") if p.suffix in (".html", ".css", ".js")]
        self.assertGreater(len(files), 5)
        for p in files:
            fn = str(p)
            txt = p.read_text(encoding="utf-8")
            # links the user clicks deliberately (publisher pages) are allowed; nothing may load automatically
            txt = re.sub(r'href:\s*r\.url', "", txt)
            self.assertFalse(re.search(r"(src|href)\s*=\s*[\"']https?://", txt), fn)
            self.assertFalse(re.search(r"url\(\s*[\"']?https?://", txt), fn)
            self.assertNotIn("@import", txt)


if __name__ == "__main__":
    unittest.main()
