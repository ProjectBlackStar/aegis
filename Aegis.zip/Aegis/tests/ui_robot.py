"""Click-through robot: opens every screen, clicks every control one at a time from a fresh state, and fails if a
control does nothing visible, a script error occurs, or any request fails. Usage: python tests/ui_robot.py [base_url]
Needs Playwright with Chromium."""
import hashlib
import sys
from playwright.sync_api import sync_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8765"
ROUTES = ["start", "overview", "inventory", "data", "quantum", "systems", "recommend", "fix", "plan", "exports", "compare", "sources", "policy"]
CLICKABLE = ("button:visible:not([disabled]), [role=button]:visible, a[href]:visible, tbody tr[tabindex]:visible, input[type=checkbox]:visible, "
             "dfn[data-term]:visible, summary:visible, select:visible:not([disabled]), input[type=range]:visible")
SKIP_TEXT = ("Generate and verify the fix", "Generate the fix again")  # exercised once, separately (slow: runs test suites)


def state(pg):
    js = "document.body.innerHTML + '|' + [...document.querySelectorAll('select, input')].map(e => e.type === 'checkbox' ? e.checked : e.value).join(',')"
    return hashlib.md5((pg.url + pg.evaluate(js)).encode()).hexdigest()


def ensure_demo(pg):
    """Clicks on the start screen load other samples; put the DigiBank scan back before testing the next screen."""
    ok = pg.evaluate(r"() => !!(S.summary && String(S.summary.target).replace(/\/+$/, '').endsWith('digibank-kyc') && !S.summary.archived)")
    if not ok:
        pg.goto(BASE + "/#/start")
        pg.reload()  # same-hash navigation keeps whatever tab the start screen was on
        pg.wait_for_timeout(700)
        pg.click('.target[data-id="sample:digibank-kyc"]')
        pg.wait_for_url("**/#/overview", timeout=60000)
        pg.wait_for_timeout(500)


def main():
    errors, failed, dead, clicks = [], [], [], 0
    with sync_playwright() as p:
        b = p.chromium.launch()
        ctx = b.new_context(viewport={"width": 1440, "height": 900}, accept_downloads=True)
        pg = ctx.new_page()
        pg.on("pageerror", lambda e: (errors.append(f"{pg.url}: {e}"), print("   ERROR:", e, flush=True)))
        pg.on("console", lambda m: errors.append(f"{pg.url}: console {m.text}") if m.type == "error" else None)
        pg.on("response", lambda r: failed.append(f"{r.status} {r.url}") if r.status >= 400 else None)
        downloads = []
        pg.on("download", lambda d: downloads.append(d.suggested_filename))
        ctx.on("page", lambda newp: downloads.append("new tab " + newp.url))
        # fresh scan so every screen has data
        pg.goto(BASE + "/#/start")
        pg.evaluate("localStorage.clear()")
        pg.goto(BASE + "/#/start")
        pg.wait_for_timeout(600)
        pg.click('.target[data-id="sample:digibank-kyc"]')
        pg.wait_for_url("**/#/overview", timeout=60000)
        pg.wait_for_timeout(800)
        for route in ROUTES:
            seen = {}
            ensure_demo(pg)
            pg.goto(f"{BASE}/#/{route}")
            pg.wait_for_timeout(900)
            n = pg.locator(CLICKABLE).count()
            for i in range(n):
                pg.keyboard.press("Escape")
                # same-hash navigation does not re-render, so reset the screen explicitly
                pg.evaluate(f"""() => {{ document.querySelectorAll('.term-pop').forEach(p => p.remove());
                    document.querySelector('#palette').hidden = true;
                    if (location.hash === '#/{route}') render(); else location.hash = '#/{route}'; }}""")
                pg.wait_for_timeout(350)
                loc = pg.locator(CLICKABLE)
                if i >= loc.count():
                    break
                el = loc.nth(i)
                if i % 10 == 0:
                    print(f"  {route} {i + 1}/{n}", flush=True)
                try:
                    label = (el.inner_text(timeout=500) or el.get_attribute("aria-label") or el.get_attribute("placeholder") or "")[:50].strip()
                except Exception:
                    label = ""
                if any(t in label for t in SKIP_TEXT):
                    continue
                if el.evaluate("e => e.getAttribute('aria-current') === 'page' || e.getAttribute('aria-selected') === 'true' || e.getAttribute('aria-pressed') === 'true'"):
                    continue  # already the active page / tab / option: clicking it correctly changes nothing
                tag = el.evaluate("e => e.tagName.toLowerCase() + (e.type ? ':' + e.type : '')")
                kind = el.evaluate("e => e.tagName + '.' + (e.className && e.className.baseVal === undefined ? e.className : '') + (e.closest('.facets') ? 'facet' : '')")
                if kind.startswith(("TR", "INPUT.facet")) or "fixrow" in kind or "hrow" in kind:
                    seen[kind] = seen.get(kind, 0) + 1
                    if seen[kind] > 6:
                        continue
                before, nd = state(pg), len(downloads)
                try:
                    if tag == "select:select-one":
                        opts = el.locator("option")
                        cur = el.input_value()
                        vals = [opts.nth(k).get_attribute("value") for k in range(opts.count())]
                        nxt = next((v for v in vals if v != cur), None)
                        if nxt is None:
                            continue
                        el.select_option(nxt)
                    elif tag == "input:range":
                        el.evaluate("e => { e.value = (+e.value === +e.max ? e.min : e.max); e.dispatchEvent(new Event('input')); e.dispatchEvent(new Event('change')); }")
                    else:
                        el.click(timeout=2500)
                except Exception as e:
                    dead.append(f"{route}: could not click '{label}' ({tag}): {str(e).splitlines()[0][:100]}")
                    continue
                clicks += 1
                pg.wait_for_timeout(450)
                if state(pg) == before and len(downloads) == nd and not pg.locator(".term-pop, .drawer.on, #palette:not([hidden])").count():
                    dead.append(f"{route}: '{label}' ({tag}) changed nothing")
                    print("   DEAD:", dead[-1], flush=True)
                ensure_demo(pg)
        # every control inside the details panel, for the top finding and a library finding
        for q in ("", "?type=library"):
            pg.goto(f"{BASE}/#/inventory{q}")
            pg.wait_for_timeout(700)
            pg.locator("tbody tr").first.click()
            pg.wait_for_timeout(500)
            tabs = pg.locator("#drawer button[role=tab]")
            for t in range(tabs.count()):
                before = state(pg)
                tabs.nth(t).click()
                clicks += 1
                pg.wait_for_timeout(500)
                if t and state(pg) == before:
                    dead.append(f"drawer tab {t} changed nothing")
            pg.keyboard.press("Escape")
        # the slow one: generate a fix on a fresh scan
        pg.goto(BASE + "/#/start")
        pg.wait_for_timeout(500)
        pg.click('.target[data-id="sample:digibank-kyc"]')
        pg.wait_for_url("**/#/overview", timeout=60000)
        pg.goto(f"{BASE}/#/fix")
        pg.wait_for_timeout(700)
        pg.get_by_role("button", name="Generate and verify the fix").click()
        pg.wait_for_selector("text=Fixed and verified", timeout=120000)
        clicks += 1
        # search palette and keyboard
        pg.keyboard.press("Control+k")
        pg.keyboard.type("aadhaar")
        pg.wait_for_timeout(300)
        if not pg.locator(".pal-item").count():
            dead.append("search: no results for 'aadhaar'")
        pg.keyboard.press("Enter")
        pg.wait_for_timeout(400)
        if not pg.locator(".drawer.on").count():
            dead.append("search: Enter did not open the asset")
        b.close()
    print(f"{clicks} controls clicked, {len(downloads)} downloads / new tabs")
    for title, lst in (("SCRIPT ERRORS", errors), ("FAILED REQUESTS", failed), ("DEAD CONTROLS", dead)):
        if lst:
            print(f"\n{title} ({len(lst)}):")
            for x in sorted(set(lst))[:60]:
                print("  ", x)
    ok = not errors and not failed and not dead
    print("\nRESULT:", "PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
