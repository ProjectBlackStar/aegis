"""Tests for the v1.0 features: published-data quantum model, qubit ladder, probabilistic Mosca,
criticality rules, crypto-agility, advisories, TLS profile + cost, keystores, Kubernetes, cache, diff, probe."""
import json
import os
import socket
import sys
import threading
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path[:0] = [ROOT, os.path.join(ROOT, "vendor")]

from core import quantum as Q
from core.engine import Scan
from core.detectors.deps import match
from core.tlscost import chain_cost

KYC = os.path.join(ROOT, "samples", "digibank-kyc")


def by(scan, path, algo=None):
    return [f for f in scan.findings if path in f.location and (algo is None or f.algorithm == algo)]


class V1(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.s = Scan(KYC).run()

    def test_survey_fit_reproduces_published_points(self):
        m = Q.fit_survey("mid")
        self.assertAlmostEqual(Q.cdf(m, 2035), (0.28 + 0.49) / 2, places=3)
        self.assertAlmostEqual(Q.cdf(m, 2040), (0.51 + 0.70) / 2, places=3)
        self.assertEqual(Q.scenarios(m), {"early": 2030, "planning": 2033, "median": 2037})

    def test_qubit_ladder_matches_literature(self):
        self.assertEqual(Q.logical_qubits("ECDSA", "P-256")[0], 2330)   # Roetteler et al. 2017
        self.assertEqual(Q.logical_qubits("RSA", "2048")[0], 4098)      # 2n+2, Haner et al. 2017
        ecc, _ = Q.shift_years("ECDSA", "P-256", 2.0)
        rsa4, _ = Q.shift_years("RSA", "4096", 2.0)
        self.assertLess(ecc, 0)
        self.assertGreater(rsa4, 0)

    def test_probabilistic_mosca(self):
        f = [x for x in by(self.s, "aadhaar_vault.py") if x.operation == "encrypt"][0]
        otp = [x for x in self.s.findings if x.risk.get("class") == "vulnerable" and not x.data_links]
        self.assertGreater(f.risk["p_exposure"], 0.9)
        self.assertTrue(all(x.risk["p_exposure"] < f.risk["p_exposure"] for x in otp))
        self.assertTrue(f.risk["priority_parts"])

    def test_criticality_rules_change_priority(self):
        f0 = [x for x in by(self.s, "kms.tf")][0]
        pol = json.loads(json.dumps(self.s.policy))
        pol["criticality"] = [{"pattern": "infra/kms.tf", "tier": "critical", "exposure": "external"}]
        s2 = Scan(KYC).run().reassess(pol)
        f1 = [x for x in s2.findings if x.fid == f0.fid][0]
        self.assertEqual(f1.risk["criticality"], "critical")
        self.assertEqual(f1.exposure, "external")
        self.assertGreater(f1.risk["priority"], f0.risk["priority"])

    def test_agility_feeds_migration_time(self):
        f = [x for x in self.s.findings if x.detector == "python-ast" and x.risk.get("agility")][0]
        self.assertIn("crypto-agility", f.risk["y_reason"])

    def test_advisories_from_github_database(self):
        hits, known, upgrade = match("npm", "node-forge", "0.10.0")
        self.assertGreater(len(hits), 5)
        self.assertTrue(all(h["id"].startswith("GHSA-") for h in hits))
        lib = by(self.s, "package.json", "node-forge")[0]
        self.assertEqual(lib.risk["class"], "broken")
        self.assertIn("Upgrade", lib.recommendation["options"][0]["name"])
        clean, _, _ = match("npm", "node-forge", "99.0.0")
        self.assertEqual(clean, [])

    def test_tls_profile_and_pq_group(self):
        legacy = [x for x in by(self.s, "infra/nginx.conf") if x.extra.get("tls_profile")][0].extra["tls_profile"]
        self.assertIn("DES-CBC3-SHA", legacy["static_rsa"])
        self.assertEqual(legacy["verdict"], "old / non-compliant")
        ready = [x for x in by(self.s, "nginx-pq-ready.conf") if x.algorithm == "TLS"][0]
        self.assertEqual(ready.risk["class"], "safe")
        hap = [x for x in by(self.s, "haproxy.cfg") if x.algorithm == "TLS" and x.params == "TLSv1.0"]
        self.assertTrue(hap and hap[0].risk["class"] == "broken")

    def test_tls_cost_from_real_chain(self):
        c = [x for x in self.s.findings if x.extra.get("tls_cost")][0].extra["tls_cost"]
        names = [o["name"] for o in c["options"]]
        self.assertTrue(any("ML-DSA-65" in n for n in names))
        slh = [o for o in c["options"] if "SLH-DSA" in o["sig"]][0]
        today = c["options"][0]
        self.assertGreater(slh["bytes"], today["bytes"])
        self.assertTrue(slh["tcp_extra_rtt"])
        self.assertFalse(today["tcp_extra_rtt"])

    def test_keystores_and_kubernetes(self):
        p12 = by(self.s, "payments-api.p12")
        self.assertTrue(any(x.asset_type == "key" and x.extra.get("unprotected_private_key") for x in p12))
        jks = by(self.s, "truststore.jks")
        self.assertEqual(len([x for x in jks if x.asset_type == "certificate"]), 2)
        k8s = by(self.s, "ingress.yaml")
        self.assertTrue(any(x.asset_type == "certificate" for x in k8s))
        self.assertTrue(any("static key transport" in x.params for x in k8s))

    def test_cache_makes_rescan_reuse_results(self):
        s2 = Scan(KYC).run()
        self.assertGreater(s2.cache_hits, 20)
        self.assertEqual(len(s2.findings), len(self.s.findings))

    def test_cbom_still_valid(self):
        from core.export.cbom import build_cbom, validate
        ok, errs = validate(build_cbom(self.s))
        self.assertTrue(ok, errs)


class Probe(unittest.TestCase):
    def test_client_hello_is_wellformed(self):
        from core.probe import client_hello
        ch = client_hello("example.com")
        self.assertEqual(ch[0], 0x16)
        self.assertEqual(int.from_bytes(ch[3:5], "big"), len(ch) - 5)
        self.assertGreater(len(ch), 1300)  # ML-KEM-768 key share makes it larger than one packet

    def test_probe_classical_local_server(self):
        import ssl, subprocess, tempfile
        d = tempfile.mkdtemp()
        cert, key = os.path.join(d, "c.pem"), os.path.join(d, "k.pem")
        subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", key, "-out", cert, "-days", "2",
                        "-subj", "/CN=localhost"], capture_output=True)
        if not os.path.exists(cert):
            self.skipTest("openssl CLI not available")
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(cert, key)
        srv = socket.socket()
        srv.bind(("127.0.0.1", 0))
        srv.listen(5)
        port = srv.getsockname()[1]

        def serve():
            for _ in range(3):
                try:
                    c, _ = srv.accept()
                    with ctx.wrap_socket(c, server_side=True) as t:
                        t.recv(10)
                except Exception:
                    pass
        threading.Thread(target=serve, daemon=True).start()
        from core.probe import probe
        fs, rep = probe(f"127.0.0.1:{port}")
        self.assertIn(rep["pq"]["result"], ("classical", "pq-hybrid"))
        self.assertTrue(any(f.asset_type == "certificate" for f in fs))


if __name__ == "__main__":
    unittest.main()
